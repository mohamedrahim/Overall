﻿using AutoMapper;
using DataLayer.Abstract;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Http;
using ServiceLayer.Mapping;

namespace ServiceLayer.Base
{
    public class BusinessBaseParameter<T> : IBusinessBaseParameter<T> where T : class
    {

        public BusinessBaseParameter(IUnitOfWork<T> unitOfWork, IRepositoryActionResult repositoryActionResult, IHttpContextAccessor httpContextAccessor)
        {
            UnitOfWork = unitOfWork;
            RepositoryActionResult = repositoryActionResult;
            HttpContextAccessor = httpContextAccessor;

            var config = new AutoMapperConfiguration().Configure(HttpContextAccessor);
            var iMapper = config.CreateMapper();
            Mapper = iMapper;
        }

        public IMapper Mapper { get; set; }
        public IUnitOfWork<T> UnitOfWork { get; set; }
        public IRepositoryActionResult RepositoryActionResult { get; set; }
        public IHttpContextAccessor HttpContextAccessor { get; set; }

    }

    public class AutoMapperConfiguration
    {
        public MapperConfiguration Configure(IHttpContextAccessor httpContextAccessor)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new MappingProfile(httpContextAccessor));
            });
            return config;
        }
    }

}