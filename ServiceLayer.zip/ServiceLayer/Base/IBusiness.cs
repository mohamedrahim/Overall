﻿using HelperLayer.Utilities;

namespace ServiceLayer.Base
{
    public interface IBaseBusiness
    {
        IRepositoryActionResult ValidationErrors();
        IRepositoryActionResult ServerError();
        IRepositoryActionResult UnAuthorized();
    }
}
