﻿using AutoMapper;
using DataLayer.Abstract;
using HelperLayer.Utilities;

namespace ServiceLayer.Base
{
    public interface IBusinessBaseParameter<T> where T : class
    {
        IMapper Mapper { get; set; }
        IUnitOfWork<T> UnitOfWork { get; set; }
        IRepositoryActionResult RepositoryActionResult { get; set; }
    }
}
