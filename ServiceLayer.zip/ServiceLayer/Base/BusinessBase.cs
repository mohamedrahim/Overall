﻿using AutoMapper;
using DataLayer.Abstract;
using HelperLayer.Utilities;

namespace ServiceLayer.Base
{
    public class BusinessBase<T> where T : class
    {
        protected readonly IUnitOfWork<T> _unitOfWork;
        protected readonly IMapper Mapper;
        protected readonly IRepositoryActionResult RepositoryActionResult;

        protected internal BusinessBase(IBusinessBaseParameter<T> businessBaseParameter)
        {
            _unitOfWork = businessBaseParameter.UnitOfWork;
            RepositoryActionResult = businessBaseParameter.RepositoryActionResult;
            Mapper = businessBaseParameter.Mapper;
        }

        public IRepositoryActionResult ValidationErrors()
        {
            return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.ValidationError));
        }

        public IRepositoryActionResult ServerError()
        {
            return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
        }

        public IRepositoryActionResult UnAuthorized()
        {
            return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
        }
    }
}
