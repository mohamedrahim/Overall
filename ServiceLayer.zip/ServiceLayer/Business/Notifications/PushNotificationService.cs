﻿using Business.Services.SettingsSer;
using HelperLayer.Dtos.Notifications;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Notifications
{
    public class PushNotificationService : IPushNotificationService
    {
        private readonly IAppSettings _AppSetting;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment _env;

        public PushNotificationService(
            IHostingEnvironment env,
            IAppSettings AppSetting,
            IHttpContextAccessor httpContextAccessor)
        {
            _AppSetting = AppSetting;
            _httpContextAccessor = httpContextAccessor;
            _env = env;
        }

        public async Task Send(string id, HashSet<DeviceTokenModel> dtList, int type, NotificationModel model)
        {
            try
            {
                AppContext.SetSwitch("System.Net.Http.UseSocketsHttpHandler", false);

                if (dtList != null && dtList.Count > 0)
                {
                    string wwwRootPath = _env.WebRootPath;
                    string path = Path.Combine(wwwRootPath, _AppSetting.P8FilePath);
                    var push = new PushNotification
                    {
                        GoogleAppID = _AppSetting.GoogleAppID,
                        BundleId = _AppSetting.BundleId,
                        KeyId = _AppSetting.KeyId,
                        TeamId = _AppSetting.TeamId,
                        P8FilePath = path,
                        PrintResult = _AppSetting.PrintResult,
                        Sandbox = _AppSetting.Sandbox,
                        //SenderID = _AppSetting.SenderID,
                        //AndroidNotificationType = _AppSetting.AndroidNotificationType
                    };

                    push.CurrentContext = _httpContextAccessor.HttpContext;

                    Dictionary<string, string> notificationParameters = new Dictionary<string, string>();

                    foreach (var item in dtList)
                    {
                        notificationParameters = new Dictionary<string, string>();

                        notificationParameters.Add("I", model.ReferenceId.ToString());
                        notificationParameters.Add("T", type.ToString());

                        Token _DeviceToken = new Token();
                        long tokenId = item.Id;
                        string token = item.Token;
                        int tokenType = (int)item.Type;

                        if (!token.Trim().Equals("") && tokenType > 0)
                        {
                            _DeviceToken.Id = tokenId.ToString();
                            _DeviceToken.Type = tokenType;
                            _DeviceToken.DToken = token;
                        }

                        await push.SendPushNotification(_DeviceToken, (item.Lang == "ar") ? model.TitleAr : model.TitleEn, (item.Lang == "ar") ? model.MessageAr : model.MessageEn, notificationParameters);
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogException(ex);
            }
        }

    }
}
