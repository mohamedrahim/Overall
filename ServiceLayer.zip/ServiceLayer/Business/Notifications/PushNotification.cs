﻿using dotAPNS;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using PushSharp.Apple;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using System.Net.Http;
using System.Threading.Tasks;
using HelperLayer.Utilities;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using FirebaseAdmin.Messaging;

namespace ServiceLayer.Business.Notifications
{
    public class PushNotification
    {
        public string GoogleAppID { get; set; }
        //public string SenderID { get; set; }
        public string BundleId { get; set; }
        public string KeyId { get; set; }
        public string TeamId { get; set; }
        public string P8FilePath { get; set; }
        public bool PrintResult { get; set; }
        public bool Sandbox { get; set; }
        //public int AndroidNotificationType { get; set; }

        public HttpContext CurrentContext { get; set; }

        public bool SendNotificationForAndroid(string token, string message, Dictionary<string, string> parameters = null)
        {
            try
            {
                string value = HttpUtility.UrlEncode(message);
                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.ContentType = " application/x-www-form-urlencoded;charset=UTF-8";
                tRequest.Headers.Add(string.Format("Authorization: key={0}", GoogleAppID));

                string postData = "collapse_key=score_update&time_to_live=108&delay_while_idle=1&data.message=" + value + "&data.time=" + System.DateTime.Now.ToString() + "&registration_id=" + token;

                if ((parameters != null && parameters.Count > 0))
                {
                    foreach (string key in parameters.Keys)
                    {
                        if (!string.IsNullOrEmpty(key) && !key.Trim().Equals(""))
                        {
                            postData += "&data." + key.Trim() + "=" + parameters[key];
                        }
                    }
                }

                Console.WriteLine(postData);
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                tRequest.ContentLength = byteArray.Length;

                Stream dataStream = tRequest.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();

                WebResponse tResponse = tRequest.GetResponse();

                dataStream = tResponse.GetResponseStream();

                StreamReader tReader = new StreamReader(dataStream);

                string sResponseFromServer = tReader.ReadToEnd();

                tReader.Close();
                dataStream.Close();
                tResponse.Close();

                bool result = (!string.IsNullOrEmpty(sResponseFromServer) ? true : false);

                if (PrintResult == true && CurrentContext != null)
                {
                    if (result == true)
                    {
                        LogHelper.LogPushInfo($"Android notification successfully to token: {token} and GoogleAppId {GoogleAppID}");
                        Console.WriteLine($"Android notification successfully to token: {token}");
                    }
                    else
                    {
                        LogHelper.LogPushInfo($"Android notification failed to token: {token} and GoogleAppId {GoogleAppID}");
                        Console.WriteLine($"Android notification failed to token: {token}");
                    }
                }
                else
                {
                    LogHelper.LogPushInfo($"Android notification failed to token: {token} and GoogleAppId {GoogleAppID}");
                    Console.WriteLine($"Android notification failed to token: {token}");
                }

                return result;
            }
            catch (Exception ex)
            {
                LogHelper.LogPushInfo($"Android notification failed to token: {token} and GoogleAppId {GoogleAppID} for some unknown reason: {ex.InnerException}");
                Console.WriteLine($"Android notification failed for some unknown reason: {ex.InnerException}");
                return false;
            }
        }

        //public async Task<bool> SendNotificationForAndroidNewMethod(string token, string title, string body, Dictionary<string, string> parameters = null)
        //{
        //    try
        //    {
        //        var message = new MulticastMessage()
        //        {
        //            Tokens = new List<string> { token },
        //            Data = parameters,
        //            Notification = new Notification
        //            {
        //                Title = title,
        //                Body = body
        //            }
        //        };

        //        var response = await FirebaseMessaging.DefaultInstance.SendMulticastAsync(message);
        //        if (response.SuccessCount > 0)
        //        {
        //            LogHelper.LogPushInfo($"Android notification successfully to token: {token} and GoogleAppId {GoogleAppID}");

        //            return true;
        //        }
        //        else
        //        {
        //            LogHelper.LogPushInfo($"Android notification failed to token: {token} and GoogleAppId {GoogleAppID}");

        //            return false;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.LogPushInfo($"Android notification failed to token: {token} and GoogleAppId {GoogleAppID} for some unknown reason: {ex.InnerException}");
        //        return false;
        //    }
        //}


        public bool SendPushNotificationForIphone(string token, string message, Dictionary<string, string> parameters = null)
        {
            var options = new ApnsJwtOptions()
            {
                BundleId = BundleId,
                CertFilePath = P8FilePath,
                KeyId = KeyId,
                TeamId = TeamId
            };

            var apns = ApnsClient.CreateUsingJwt(new HttpClient(), options);

            if (Sandbox)
            {
                apns.UseSandbox();
            }

            var push = new ApplePush(ApplePushType.Alert)
            .AddAlert(message)
            .AddSound("push.mp3")
            .AddCategory("DCCP")
            .AddMutableContent()
            .AddCustomProperty("I", parameters["I"], false)
            .AddCustomProperty("T", parameters["T"], false)
            //.AddCustomProperty("O", parameters["O"], false)
            .AddToken(token);

            try
            {
                var response = apns.SendAsync(push);
                if (response.Result.Reason == ApnsResponseReason.Success)
                {
                    LogHelper.LogPushInfo($"Apple notification successfully to token: {token} and P8Path {P8FilePath}");
                    Console.WriteLine("Apple notification has been successfully sent!");
                    return true;
                }
                else
                {
                    switch (response.Result.Reason)
                    {
                        case ApnsResponseReason.BadCertificateEnvironment:
                            // The client certificate is for the wrong environment.
                            // TODO: retry on another environment
                            break;
                        // TODO: process other reasons we might be interested in
                        default:
                            break;
                    }

                    LogHelper.LogPushInfo($"Apple notification failed to token: {token} and P8Path {P8FilePath} for reason: {response.Result.ReasonString}");
                    Console.WriteLine($"Failed to send a push, APNs reported an error: {response.Result.ReasonString}");
                    return true;
                }
            }
            catch (TaskCanceledException)
            {
                LogHelper.LogPushInfo($"Apple notification failed to token: {token} and P8Path {P8FilePath} for reason: HTTP request timed out.");
                Console.WriteLine($"Apple notification failed to send a push: HTTP request timed out.");
                return false;
            }
            catch (HttpRequestException ex)
            {
                LogHelper.LogPushInfo($"Apple notification failed to token: {token} and P8Path {P8FilePath} for reason: HTTP request failed: {ex}");
                Console.WriteLine($"Apple notification failed to send a push. HTTP request failed: {ex}");
                return false;
            }

        }

        public async Task<string> SendPushNotification(Token token, string title, string Message, Dictionary<string, string> parameters)
        {
            string tokenIds = "";
            if (token != null)
            {
                switch ((token.Type))
                {
                    //iphone
                    case (int)DeviceType.IPhone:
                        SendPushNotificationForIphone(token.DToken, Message, parameters);
                        break;

                    //android
                    case (int)DeviceType.Android:
                        {
                            //if (AndroidNotificationType == 1)
                            SendNotificationForAndroid(token.DToken, Message, parameters);
                            //else
                            // await SendNotificationForAndroidNewMethod(token.DToken, title, Message, parameters);
                        }
                        break;
                }

            }
            return tokenIds;
        }
    }

    public class Token
    {
        public string Id { get; set; }

        public string DToken { get; set; }

        public int Type { get; set; }
    }

    public delegate string AsyncSendPushNotification(Token token, string Message, Dictionary<string, string> parameters);
}
