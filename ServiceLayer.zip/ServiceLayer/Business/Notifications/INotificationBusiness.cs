﻿using HelperLayer.Dtos.Account;
using HelperLayer.Dtos.Notifications;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Parameters.Notifications;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Notifications
{
    public interface INotificationBusiness : IBaseBusiness
    {
        Task AddNotifictionLog(IEnumerable<string> userIds, NotificationModel model);
        Task<IRepositoryActionResult> AddOrEdit(TokenModel model, string userId);
        Task<List<DeviceTokenModel>> ClientsUserTokens(string userId, bool isAll = true);
        Task<List<string>> ClientsUserIds();
        Task<IRepositoryActionResult> GetNotificationDetails(Guid notificationId);
        Task<List<DeviceTokenModel>> GetUserDeviceTokens(string userId);
        Task<List<NotificationListVM>> GetNotificationsList();
        Task<IRepositoryActionResult> GetUserNotificationsCount(string userId);
        Task<List<DeviceTokenModel>> GetUsersDeviceTokens();
        Task<List<DeviceTokenModel>> UserTokens(string userid);
        Task<List<string>> AllUserIds();
        Task<IRepositoryActionResult> GetUserNotificationsList(string userId, int pageNum = 0);
    }
}
