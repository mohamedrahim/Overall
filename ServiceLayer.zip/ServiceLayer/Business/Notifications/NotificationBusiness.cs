﻿using DataLayer.Abstract;
using DataLayer.Models;
using DataLayer.Models.DB;
using HelperLayer.Dtos.Notifications;
using HelperLayer.Parameters.Notifications;
using HelperLayer.Utilities;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Notifications
{
    public class NotificationBusiness : BusinessBase<Notification>, INotificationBusiness
    {
        IUnitOfWork<NotificationUser> _unitOfWorkNotificationUser;
        IUnitOfWork<DeviceToken> _unitOfWorkDeviceToken;
        IUnitOfWork<AppUser> _unitOfWorkUser;

        public NotificationBusiness(IUnitOfWork<NotificationUser> unitOfWorkNotificationUser,
            IUnitOfWork<DeviceToken> unitOfWorkDeviceToken,
            IUnitOfWork<AppUser> unitOfWorkUser,
            IBusinessBaseParameter<Notification> businessBaseParameter) : base(businessBaseParameter)
        {
            _unitOfWorkNotificationUser = unitOfWorkNotificationUser;
            _unitOfWorkDeviceToken = unitOfWorkDeviceToken;
            _unitOfWorkUser = unitOfWorkUser;
        }

        public async Task AddNotifictionLog(IEnumerable<string> userIds, NotificationModel model)
        {
            var item = new Notification()
            {
                TitleAr = model.TitleAr,
                TitleEn = model.TitleEn,
                CreatedOn = DateTime.UtcNow,
                MessageAr = model.MessageAr,
                MessageEn = model.MessageEn,
                Url = model.Url,
                Type = model.Type,
                ReferenceId = model.ReferenceId,
            };

            item.NotificationUsers = userIds.Select(user => new NotificationUser
            {
                Id = Guid.NewGuid(),
                CreateDate = DateTime.UtcNow,
                IsRead = false,
                UserId = user
            }).ToList();

            _unitOfWork.Repository.Add(item);
            await _unitOfWork.SaveChanges();
        }

        public async Task<IRepositoryActionResult> AddOrEdit(TokenModel model, string userId)
        {
            var token = await _unitOfWorkDeviceToken.Repository.FirstOrDefault(x => x.DeviceId == model.DeviceId);
            if (token == null)
            {
                var bm = new DeviceToken
                {
                    UserId = userId,
                    DeviceId = model.DeviceId,
                    Token = model.Token,
                    Type = model.Type,
                    Lang = model.Lang,
                    Date = DateTime.UtcNow
                };

                _unitOfWorkDeviceToken.Repository.Add(bm);
                await _unitOfWorkDeviceToken.SaveChanges();

                return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Created));
            }
            else
            {
                token.Token = model.Token;
                token.Lang = model.Lang;
                token.Date = DateTime.UtcNow;
                token.UserId = userId;

                _unitOfWorkDeviceToken.Repository.UpdateCustomFields(token, x => x.Token, x => x.Lang, x => x.Date, x => x.UserId);
                await _unitOfWorkDeviceToken.SaveChanges();

                return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Updated));
            }
        }

        public async Task<List<DeviceTokenModel>> ClientsUserTokens(string userId, bool isAll = true)
        {
            var models = await _unitOfWorkDeviceToken.Repository.Find(x => x.User.Type == (byte)UserTypes.Client
                                             && x.User.IsActive == true
                                             && x.User.IsDeleted != true);

            if (isAll != true)
                models = models.Where(x => x.UserId == userId).ToList();

            var tokens = Mapper.Map<List<DeviceTokenModel>>(models);
            return tokens;
        }

        public async Task<List<string>> ClientsUserIds()
        {
            var models = await _unitOfWorkUser.Repository.Find(x => x.Type == (byte)UserTypes.Client
                                             && x.IsActive == true
                                             && x.IsDeleted != true);


            var ids = models.Select(x => x.Id).ToList();
            return ids;
        }

        public async Task<List<string>> AllUserIds()
        {
            var models = await _unitOfWorkUser.Repository.Find(x => x.IsActive == true
                                             && x.IsDeleted != true);

            var ids = models.Select(x => x.Id).ToList();
            return ids;
        }

        public async Task<IRepositoryActionResult> GetNotificationDetails(Guid notificationId)
        {
            var notification = await _unitOfWorkNotificationUser.Repository.FirstOrDefaultThenIncludeAsync(predicate: x => x.Id == notificationId,
                include: x => x.Include(a => a.Notification));

            if (notification != null)
            {
                notification.IsRead = true;
                _unitOfWorkNotificationUser.Repository.Update(notification);
                await _unitOfWorkNotificationUser.SaveChanges();

                var model = new NotificationDetails()
                {
                    Id = notification.Id,
                    IsRead = notification.IsRead,
                    Date = notification.CreateDate,
                    MessageAr = notification.Notification.MessageAr,
                    MessageEn = notification.Notification.MessageEn,
                    TitleAr = notification.Notification.TitleAr,
                    TitleEn = notification.Notification.TitleEn,
                    ReferenceId = notification.Notification.ReferenceId,
                    Type = notification.Notification.Type,
                    Url = notification.Notification.Url,
                    UserId = notification.UserId
                };

                return RepositoryActionResult.GetRepositoryActionResult(success: true, model, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
        }

        public async Task<List<DeviceTokenModel>> GetUserDeviceTokens(string userId)
        {
            var models = await _unitOfWorkDeviceToken.Repository.Find(x => x.UserId == userId);
            var tokens = Mapper.Map<List<DeviceTokenModel>>(models);
            return tokens;
        }

        //public PagedList<NotificationDetails> GetUserNotifications(PagingParams pagingParams, string userId)
        //{
        //    var notifications = _unitOfWorkNotificationUser.Repository.FindThenInclude(predicate: x => x.UserId == userId,
        //        include: x => x.Include(a => a.Notification));

        //    var models = Mapper.Map<IEnumerable<NotificationDetails>>(notifications);

        //    return new PagedList<NotificationDetails>(models, pagingParams.PageNumber, pagingParams.PageSize);
        //}

        public async Task<List<NotificationListVM>> GetNotificationsList()
        {
            var notifications = await _unitOfWork.Repository.Find(x => x.Type == (int)NotificationEnum.GeneralNotification);
            var models = Mapper.Map<List<NotificationListVM>>(notifications);

            return models;
        }

        public async Task<IRepositoryActionResult> GetUserNotificationsList(string userId, int pageNum = 0)
        {
            int skip = (pageNum > 0 ? pageNum - 1 : 0) * 10;
            int pageCount = 10;

            var notifications = _unitOfWorkNotificationUser.Repository.FindThenInclude(predicate: x => x.UserId == userId,
                include: x => x.Include(a => a.Notification));

            var list = notifications.OrderByDescending(x => x.CreateDate).Skip(skip).Take(pageCount).ToList();

            var models = list.Select(notification => new NotificationDetails()
            {
                Id = notification.Id,
                IsRead = notification.IsRead,
                Date = notification.CreateDate,
                MessageAr = notification.Notification.MessageAr,
                MessageEn = notification.Notification.MessageEn,
                TitleAr = notification.Notification.TitleAr,
                TitleEn = notification.Notification.TitleEn,
                ReferenceId = notification.Notification.ReferenceId,
                Type = notification.Notification.Type,
                Url = notification.Notification.Url,
                UserId = notification.UserId
            });

            return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> GetUserNotificationsCount(string userId)
        {
            var unReadNotifications = await _unitOfWorkNotificationUser.Repository.Find(x => x.UserId == userId && x.IsRead != true);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, unReadNotifications.Count(), message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<List<DeviceTokenModel>> GetUsersDeviceTokens()
        {
            var models = await _unitOfWorkDeviceToken.Repository.GetAll();
            var tokens = Mapper.Map<List<DeviceTokenModel>>(models);
            return tokens;
        }

        public async Task<List<DeviceTokenModel>> UserTokens(string userid)
        {
            var model = await _unitOfWorkDeviceToken.Repository.Find(x => x.UserId == userid);
            var tokens = Mapper.Map<List<DeviceTokenModel>>(model);
            return tokens;
        }

    }
}
