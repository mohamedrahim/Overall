﻿using HelperLayer.Dtos.Notifications;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Notifications
{
    public interface IPushNotificationService
    {
        Task Send(string id, HashSet<DeviceTokenModel> dtList, int type, NotificationModel model);
    }
}
