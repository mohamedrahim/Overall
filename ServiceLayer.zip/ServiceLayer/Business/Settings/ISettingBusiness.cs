﻿using HelperLayer.Dtos.Settings;
using HelperLayer.Parameters.Settings;
using HelperLayer.Utilities;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Settings
{
    public interface ISettingBusiness
    {
        Task<InfoVM> GetInfo();
        Task<IRepositoryActionResult> GetAppVersion();
        Task<int> EditAboutUS(AboutBM bM);
        Task<int> EditHomeInfo(HomeBM bM);
        Task<int> EditTermsAndConditions(TermsAndConditionsBM bM);
        Task<int> EditAppInfo(InfoBM bM);
        Task DeleteLogo();
        Task<IRepositoryActionResult> Aboutus();
        Task<IRepositoryActionResult> Terms();
        Task<IRepositoryActionResult> Contacts();
        Task<IRepositoryActionResult> Privacy();
        Task<int> EditPrivacyAndPolicy(PrivacyAndPolicyBM bM);
    }
}
