﻿using DataLayer.Models.DB;
using HelperLayer.Dtos.Settings;
using HelperLayer.Parameters.Settings;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Settings
{
    public class SettingBusiness : BusinessBase<Info>, ISettingBusiness
    {
        public SettingBusiness(IBusinessBaseParameter<Info> businessBaseParameter) : base(businessBaseParameter)
        {
        }

        public async Task<IRepositoryActionResult> Aboutus()
        {
            var model = await _unitOfWork.Repository.FirstOrDefault();
            var about = new AboutDetails { LogoUrl = "" };

            if (model != null)
            {
                about = Mapper.Map<AboutDetails>(model);
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, about, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> GetAppVersion()
        {
            var model = await _unitOfWork.Repository.FirstOrDefault();
            var version = new AppDetails { };

            if (model != null)
            {
                version = new AppDetails
                {
                    AndroidVersion = model.AndroidVersion != null ? (int)model.AndroidVersion : 0,
                    IosVersion = model.IosVersion != null ? (int)model.IosVersion : 0
                };
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, version, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }


        public async Task<IRepositoryActionResult> Contacts()
        {
            var model = await _unitOfWork.Repository.FirstOrDefault();
            var contact = new ContactDetails { LogoUrl = "" };

            if (model != null)
            {
                contact = Mapper.Map<ContactDetails>(model);
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, contact, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task DeleteLogo()
        {
            var model = await _unitOfWork.Repository.FirstOrDefault();

            if (model != null)
            {
                model.LogoUrl = null;

                _unitOfWork.Repository.Update(model);
                await _unitOfWork.SaveChanges();
            }
        }


        public async Task<int> EditAboutUS(AboutBM bM)
        {
            if (string.IsNullOrEmpty(bM.Lock))
            {
                _unitOfWork.Repository.Add(new Info
                {
                    Lock = "X",
                    AboutAr = bM.AboutAr,
                    AboutEn = bM.AboutEn
                });
            }
            else
            {
                var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Lock == bM.Lock);

                model.AboutAr = bM.AboutAr;
                model.AboutEn = bM.AboutEn;

                _unitOfWork.Repository.Update(model);
            }

            var res = await _unitOfWork.SaveChanges();
            return res;
        }

        public async Task<int> EditAppInfo(InfoBM bM)
        {
            if (string.IsNullOrEmpty(bM.Lock))
            {
                _unitOfWork.Repository.Add(new Info
                {
                    Lock = "X",
                    GooglePlay = bM.GooglePlay,
                    AppStore = bM.AppStore,
                    Email = bM.Email,
                    Phone = bM.Phone,
                    LogoUrl = bM.LogoUrl,
                    AndroidVersion = bM.AndroidVersion,
                    IosVersion = bM.IosVersion,
                    HomeTextEn = bM.HomeTextEn,
                    HomeTextAr = bM.HomeTextAr
                });
            }
            else
            {
                var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Lock == bM.Lock);

                model.GooglePlay = bM.GooglePlay;
                model.AppStore = bM.AppStore;
                model.Email = bM.Email;
                model.Phone = bM.Phone;
                model.LogoUrl = bM.LogoUrl;
                model.IosVersion = bM.IosVersion;
                model.AndroidVersion = bM.AndroidVersion;
                model.HomeTextAr = bM.HomeTextAr;
                model.HomeTextEn = bM.HomeTextEn;

                _unitOfWork.Repository.Update(model);
            }

            var res = await _unitOfWork.SaveChanges();
            return res;
        }

        public async Task<int> EditHomeInfo(HomeBM bM)
        {
            if (string.IsNullOrEmpty(bM.Lock))
            {
                _unitOfWork.Repository.Add(new Info
                {
                    Lock = "X",
                    FacebookPageLink = bM.FacebookPageLink,
                    TwiterAccountLink = bM.TwiterAccountLink,
                    InstagramPageLink = bM.InstagramPageLink,
                    WhatsAppLink = bM.WhatsAppLink,
                    HomeTextAr = bM.HomeTextAr,
                    HomeTextEn = bM.HomeTextEn
                });
            }
            else
            {
                var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Lock == bM.Lock);
                model.FacebookPageLink = bM.FacebookPageLink;
                model.TwiterAccountLink = bM.TwiterAccountLink;
                model.InstagramPageLink = bM.InstagramPageLink;
                model.WhatsAppLink = bM.WhatsAppLink;

                model.HomeTextAr = bM.HomeTextAr;
                model.HomeTextEn = bM.HomeTextEn;

                _unitOfWork.Repository.Update(model);
            }

            var res = await _unitOfWork.SaveChanges();
            return res;
        }

        public async Task<int> EditTermsAndConditions(TermsAndConditionsBM bM)
        {
            if (string.IsNullOrEmpty(bM.Lock))
            {
                _unitOfWork.Repository.Add(new Info
                {
                    Lock = "X",
                    TermsAndConditionsAr = bM.TermsAndConditionsAr,
                    TermsAndConditionsEn = bM.TermsAndConditionsEn
                });
            }
            else
            {
                var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Lock == bM.Lock);

                model.TermsAndConditionsAr = bM.TermsAndConditionsAr;
                model.TermsAndConditionsEn = bM.TermsAndConditionsEn;

                _unitOfWork.Repository.Update(model);
            }

            var res = await _unitOfWork.SaveChanges();
            return res;
        }

        public async Task<int> EditPrivacyAndPolicy(PrivacyAndPolicyBM bM)
        {
            if (string.IsNullOrEmpty(bM.Lock))
            {
                _unitOfWork.Repository.Add(new Info
                {
                    Lock = "X",
                    PrivacyAndPolicyAr = bM.PrivacyAndPolicyAr,
                    PrivacyAndPolicyEn = bM.PrivacyAndPolicyEn
                });
            }
            else
            {
                var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Lock == bM.Lock);

                model.PrivacyAndPolicyAr = bM.PrivacyAndPolicyAr;
                model.PrivacyAndPolicyEn = bM.PrivacyAndPolicyEn;

                _unitOfWork.Repository.Update(model);
            }

            var res = await _unitOfWork.SaveChanges();
            return res;
        }

        public async Task<InfoVM> GetInfo()
        {
            var model = await _unitOfWork.Repository.FirstOrDefault();

            if (model != null)
            {
                var res = Mapper.Map<InfoVM>(model);

                return res;
            }
            else
            {
                return new InfoVM { Lock = "" };
            }
        }

        public async Task<IRepositoryActionResult> Terms()
        {
            var model = await _unitOfWork.Repository.FirstOrDefault();
            var terms = new TermsDetails { LogoUrl = "" };

            if (model != null)
            {
                terms = Mapper.Map<TermsDetails>(model);
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, terms, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> Privacy()
        {
            var model = await _unitOfWork.Repository.FirstOrDefault();
            var terms = new PrivacyDetails { LogoUrl = "" };

            if (model != null)
            {
                terms = Mapper.Map<PrivacyDetails>(model);
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, terms, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

    }
}
