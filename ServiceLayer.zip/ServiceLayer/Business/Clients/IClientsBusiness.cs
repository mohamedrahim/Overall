﻿using DataLayer.Models;
using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Dtos.Clients;
using HelperLayer.Hesabe;
using HelperLayer.Parameters.Clients;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Clients
{
    public interface IClientsBusiness : IBaseBusiness
    {
        Task<List<ClientDto>> GetClientsDDL(int categoryId);
        Task<IQueryable<ClientDto>> GetAdminClients();
        Task<List<ClientDto>> GetClients();
        Task<IRepositoryActionResult> GetClientsApi(int? categoryId, string searchKey, string genders, string locations, int? sortBy, double? priceFrom, double? priceTo, string userId, int? packageTypeId, int pageNum);
        Task<IRepositoryActionResult> GetDetailsApi(long id, int? typeId, string userId);
        Task Add(AddClientParameters bM, AppUser user, string userId);
        Task Delete(long id);
        Task Edit(AddClientParameters bM, string logo, string cover, string userId);
        Task<AddClientParameters> GetBM(long id);
        Task<ClientDto> GetDetails(long id);
        Task<ClientApiDto> GetFullDetails(long clientId, int? typeId, string userId);
        Task<AddClientParameters> GetByUserId(string id);
        Task<ClientDto> GetDetailsByUserId(string id);
        Task DeleteImage(long id);
        Task DeleteLogo(long id);
        Task<List<PeriodIndicatorDto>> GetPeriodIndicators();
        Task<AddClientParameters> GetBMByUserId(string id);

        #region Packages

        Task AddPackage(AddPackageParameters bM, string userId);
        Task DeletePackage(long id);
        Task EditPackage(AddPackageParameters bM, string userId);
        Task<AddPackageParameters> GetPackageBM(long id);
        Task<IQueryable<PackageDto>> GetAdminPackages();
        Task<List<PackageDto>> GetPackages();
        Task<List<PackageDto>> GetPackagesDDL(int categoryId = 0);
        Task<List<PaymentMethodDto>> GetPaymentMethodsDDL();
        Task<IRepositoryActionResult> GetPaymentMethods();
        Task<IQueryable<PackageDto>> GetClientPackages(string userId);

        #endregion

        #region Subscriptions

        Task<IQueryable<SubscriptionDto>> GetAdminSubscriptions();
        Task<IQueryable<SubscriptionDto>> GetClientSubscriptions(string id);
        Task<List<SubscriptionDto>> GetSubscriptions();
        Task<SubscriptionDto> GetSubscriptionDetails(long id);
        Task<IRepositoryActionResult> GetUserSubscriptions(string userId, int pageNum = 0);
        Task<IRepositoryActionResult> Subscribe(SubscribePackageParameters model, string userId, string baseUrl);
        Task<IRepositoryActionResult> GenerateResponse(string fileUrl);
        Task<SubscriptionDto> GetSubscriptionDetails(string id);
        Task UpdateSubscriptionAsPaid(long id, HesabePaymentResponse paymentResponse, bool status);

        #endregion

        Task<List<AreaDetails>> GetLocationDDL();
        Task<List<GenderDto>> GetGenderDDL();
        Task<IRepositoryActionResult> GetGenders();
    }
}
