﻿using Business.Services.SettingsSer;
using DataLayer.Abstract;
using DataLayer.Models;
using DataLayer.Models.DB;
using HelperLayer.Dtos.Account;
using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Dtos.Clients;
using HelperLayer.Hesabe;
using HelperLayer.Parameters.Clients;
using HelperLayer.Utilities;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Clients
{
    public class ClientsBusiness : BusinessBase<Client>, IClientsBusiness
    {
        IUnitOfWork<AppUser> _unitOfWorkUser;
        IUnitOfWork<PeriodIndicator> _unitOfWorkPeriod;
        IUnitOfWork<Package> _unitOfWorkPackage;
        IUnitOfWork<Subscription> _unitOfWorkSubscription;
        IUnitOfWork<Gender> _unitOfWorkGender;
        IUnitOfWork<ClientGender> _unitOfWorkClientGender;
        IUnitOfWork<ClientLocation> _unitOfWorkLocation;
        IUnitOfWork<Area> _unitOfWorkArea;
        IUnitOfWork<ClientCategory> _unitOfWorkCategory;
        IUnitOfWork<DataLayer.Models.DB.PaymentMethod> _unitOfWorkPaymentMethods;
        IUnitOfWork<Favorite> _unitOfWorkFavorite;
        IHesabePaymentV2 _hesabePaymentV2;
        private readonly IAppSettings _appSettings;

        public ClientsBusiness(IBusinessBaseParameter<Client> businessBaseParameter,
            IUnitOfWork<AppUser> unitOfWorkUser,
            IUnitOfWork<PeriodIndicator> unitOfWorkPeriod,
            IUnitOfWork<Package> unitOfWorkPackage,
            IUnitOfWork<Subscription> unitOfWorkSubscription,
            IUnitOfWork<Favorite> unitOfWorkFavorite,
            IUnitOfWork<Gender> unitOfWorkGender,
            IUnitOfWork<ClientGender> unitOfWorkClientGender,
            IUnitOfWork<ClientLocation> unitOfWorkLocation,
            IUnitOfWork<Area> unitOfWorkArea,
            IUnitOfWork<ClientCategory> unitOfWorkCategory,
            IHesabePaymentV2 hesabePaymentV2,
            IAppSettings appSettings,
            IUnitOfWork<DataLayer.Models.DB.PaymentMethod> unitOfWorkPaymentMethods) : base(businessBaseParameter)
        {
            _unitOfWorkUser = unitOfWorkUser;
            _unitOfWorkPeriod = unitOfWorkPeriod;
            _unitOfWorkPackage = unitOfWorkPackage;
            _unitOfWorkSubscription = unitOfWorkSubscription;
            _unitOfWorkPaymentMethods = unitOfWorkPaymentMethods;
            _unitOfWorkFavorite = unitOfWorkFavorite;
            _hesabePaymentV2 = hesabePaymentV2;
            _appSettings = appSettings;
            _unitOfWorkGender = unitOfWorkGender;
            _unitOfWorkClientGender = unitOfWorkClientGender;
            _unitOfWorkLocation = unitOfWorkLocation;
            _unitOfWorkArea = unitOfWorkArea;
            _unitOfWorkCategory = unitOfWorkCategory;
        }

        #region Clients

        public async Task<List<ClientDto>> GetClients()
        {
            var model = _unitOfWork.Repository.FindThenInclude(predicate: x => x.IsActive == true && x.IsDeleted != true,
                include: i => i.Include(x => x.ClientCategory)
                .Include(x => x.User));

            var clients = Mapper.Map<List<ClientDto>>(model);

            return clients;
        }

        public async Task<IRepositoryActionResult> GetClientsApi(int? categoryId, string searchKey, string genders, string locations, int? sortBy, double? priceFrom, double? priceTo, string userId, int? packageTypeId, int pageNum)
        {
            int skip = (pageNum > 0 ? pageNum - 1 : 0) * 10;
            int pageCount = 10;

            var model = _unitOfWork.Repository.FindThenInclude(predicate: x => (categoryId == null || categoryId == 0 || x.CategoryId == categoryId)
                                && x.Packages.Any()
                                && x.IsActive == true && x.IsDeleted != true,
                include: i => i.Include(x => x.Packages)
                              .Include(x => x.ClientGenders).ThenInclude(x => x.Gender)
                              .Include(x => x.ClientLocations).ThenInclude(x => x.Area));

            if (!string.IsNullOrEmpty(searchKey))
            {
                model = model.Where(x => x.NameEn.ToLower().Contains(searchKey.Trim().ToLower()) ||
                                         x.NameAr.Contains(searchKey.Trim()));
            }

            if (priceFrom != null && priceTo != null)
            {
                model = from m in model
                        where m.Packages.Where(x => x.Price >= priceFrom && x.Price <= priceTo).Any()
                        select m;
            }

            if (sortBy != null)
            {
                switch (sortBy)
                {
                    case (int)SortByEnum.Name:
                        {
                            model = model.OrderBy(x => ResourcesReader.IsArabic ? x.NameAr : x.NameEn);
                        }
                        break;
                    case (int)SortByEnum.Date:
                        {
                            model = model.OrderByDescending(x => x.CreateDate);
                        }
                        break;
                    case (int)SortByEnum.LowToHighPrices:
                        {
                            model = from m in model
                                    orderby m.Packages.Min(x => x.Price)
                                    select m;
                        }
                        break;
                    case (int)SortByEnum.HighToLowPrices:
                        {
                            model = from m in model
                                    orderby m.Packages.Max(x => x.Price) descending
                                    select m;
                        }
                        break;
                    default:
                        {
                            model = model.OrderByDescending(x => x.CreateDate);
                        }
                        break;
                }
            }

            if (!string.IsNullOrEmpty(genders))
            {
                var gendersList = JsonConvert.DeserializeObject<List<int>>("[" + genders + "]");
                model = model.Where(x => x.ClientGenders.Where(g => gendersList.Contains(g.GenderId)).Any());
            }

            if (!string.IsNullOrEmpty(locations))
            {
                var locationsList = JsonConvert.DeserializeObject<List<long>>("[" + locations + "]");
                model = model.Where(x => x.ClientLocations.Where(g => locationsList.Contains(g.AreaId)).Any());
            }

            if (categoryId == (int)CategoryEnum.DietitianCenter)
            {
                if (packageTypeId != null && packageTypeId != 0)
                {
                    model = model.Where(x => x.Packages.Any(p => p.SubCategoryId == packageTypeId));
                }
            }

            var models = model.Skip(skip).Take(pageCount).ToList();

            var clients = Mapper.Map<List<ClientApiDto>>(models);

            var favorites = await _unitOfWorkFavorite.Repository.Find(x => x.UserId == userId);

            clients.ForEach(x => x.IsFavorite = favorites.Select(c => c.ClientId).Contains(x.Id));

            return RepositoryActionResult.GetRepositoryActionResult(success: true, clients, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> GetDetailsApi(long id, int? typeId, string userId)
        {
            var model = await GetFullDetails(id, typeId, userId);

            if (model == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, model, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<ClientApiDto> GetFullDetails(long clientId, int? typeId, string userId)
        {
            var model = await _unitOfWork.Repository.FirstOrDefaultThenIncludeAsync(predicate: x => x.Id == clientId && x.IsActive == true && x.IsDeleted != true,
                 include: i => i.Include(x => x.Packages)
                  .Include(x => x.ClientGenders).ThenInclude(x => x.Gender)
                  .Include(x => x.ClientLocations).ThenInclude(x => x.Area));

            if (model == null)
            {
                return null;
            }

            var dbModel = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == clientId);
            dbModel.Views += 1;
            _unitOfWork.Repository.Update(dbModel);
            await _unitOfWork.SaveChanges();

            var client = Mapper.Map<ClientApiDto>(model);

            if (client.CategoryId == (int)CategoryEnum.DietitianCenter)
            {
                if (typeId == null || typeId == 0)
                {
                    List<int> typeIds = client.Packages.Where(x => x.SubCategoryId != null).Select(x => (int)x.SubCategoryId).Distinct().ToList();
                    client.PackageType = await GetCategories(typeIds);
                }
                else
                {
                    client.PackageType = await GetCategories(new List<int> { (int)typeId });
                    client.Packages = client.Packages.Where(x => x.SubCategoryId == typeId).ToList();
                }
            }

            var favorites = await _unitOfWorkFavorite.Repository.Find(x => x.UserId == userId);

            client.IsFavorite = favorites.Select(c => c.ClientId).Contains(client.Id);

            return client;
        }

        private async Task<List<PackageCategoryDto>> GetCategories(List<int> typeIds)
        {
            var categories = await _unitOfWorkCategory.Repository.Find(x => typeIds.Contains(x.Id));
            var dtos = Mapper.Map<List<PackageCategoryDto>>(categories);

            return dtos;
        }

        public async Task<List<ClientDto>> GetClientsDDL(int categoryId)
        {
            var model = _unitOfWork.Repository.FindQueryable(predicate: x => x.IsActive == true && x.IsDeleted != true);

            if (categoryId != 0)
                model = model.Where(x => x.CategoryId == categoryId);

            var result = model.ToList();

            var clients = Mapper.Map<List<ClientDto>>(result);

            return clients;
        }

        public async Task<List<PeriodIndicatorDto>> GetPeriodIndicators()
        {
            var models = await _unitOfWorkPeriod.Repository.GetAll();

            var clients = models.Select(x => new PeriodIndicatorDto
            {
                Id = x.Id,
                NameAr = x.NameAr,
                NameEn = x.NameEn
            }).ToList();

            return clients;
        }


        public async Task<IQueryable<ClientDto>> GetAdminClients()
        {
            var query = _unitOfWork.Repository.FindQueryable(x => x.IsDeleted != true,
                    inc => inc.ClientCategory,
                    inc2 => inc2.User);

            var clients = _unitOfWork.Repository.FindSelectorQueryable(query, selector: q => new ClientDto()
            {
                Id = q.Id,
                NameAr = q.NameAr,
                NameEn = q.NameEn,
                DescriptionAr = q.DescriptionAr,
                DescriptionEn = q.DescriptionEn,
                CategoryId = q.CategoryId,
                Location = q.Location,
                Lat = q.Lat,
                Lng = q.Lng,
                CoverUrl = q.CoverUrl,
                LogoUrl = q.LogoUrl,
                UserId = q.UserId,
                Views = q.Views,
                CreateUserId = q.CreateUserId,
                IsActive = q.IsActive,
                IsDeleted = q.IsDeleted,
                CreateDate = q.CreateDate,
                ClientCategory = new ClientCategoryDto
                {
                    Id = q.ClientCategory.Id,
                    NameAr = q.ClientCategory.NameAr,
                    NameEn = q.ClientCategory.NameEn,
                    IsActive = q.ClientCategory.IsActive,
                    ImageUrl = q.ClientCategory.ImageUrl
                },
                User = new UserDto
                {
                    UserId = q.User.Id,
                    FirstName = q.User.FirstName,
                    LastName = q.User.LastName,
                    Type = q.User.Type,
                    FullName = q.User.FirstName + " " + q.User.LastName,
                    Email = q.User.Email,
                    UserName = q.User.UserName,
                    LastLogin = q.User.LastLogin
                }
            });

            return clients;
        }

        public async Task Add(AddClientParameters bM, AppUser user, string userId)
        {
            var model = new Client
            {
                NameAr = bM.NameAr,
                NameEn = bM.NameEn,
                DescriptionAr = bM.DescriptionAr,
                DescriptionEn = bM.DescriptionEn,
                IsActive = bM.IsActive,
                CategoryId = bM.CategoryId,
                LogoUrl = bM.LogoUrl,
                CoverUrl = bM.CoverUrl,
                Location = bM.Location,
                Lat = bM.Lat,
                Lng = bM.Lng,
                CreateUserId = userId,
                UserId = user.Id,
                CreateDate = DateTime.UtcNow,
                AddressAr = bM.AddressAr,
                AddressEn = bM.AddressEn,
            };

            var genderIds = bM.GenderIds != null ? bM.GenderIds : (new List<int>()).ToArray();
            var genders = new List<ClientGender>();
            foreach (var item in genderIds)
            {
                genders.Add(new ClientGender
                {
                    GenderId = item,
                });
            }

            var areaIds = bM.LocationIds != null ? bM.LocationIds : (new List<long>()).ToArray();

            var areas = new List<ClientLocation>();
            foreach (var item in areaIds)
            {
                areas.Add(new ClientLocation
                {
                    AreaId = item,
                });
            }

            model.ClientGenders = genders;
            model.ClientLocations = areas;

            _unitOfWork.Repository.Add(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task Delete(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);

            model.IsDeleted = true;
            model.IsActive = false;
            model.DeleteDate = DateTime.UtcNow;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();

            var user = await _unitOfWorkUser.Repository.FirstOrDefault(x => x.Id == model.UserId);

            if (user != null)
            {
                user.IsActive = false;
                user.IsDeleted = true;
                user.DeletedOn = DateTime.UtcNow;

                _unitOfWorkUser.Repository.UpdateCustomFields(user, x => x.IsActive, x => x.IsDeleted, x => x.DeletedOn);
                await _unitOfWorkUser.SaveChanges();
            }
        }

        public async Task Edit(AddClientParameters bM, string logo, string cover, string userId)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == bM.Id);
            var oldGenders = await _unitOfWorkClientGender.Repository.Find(x => x.ClientId == bM.Id);
            var oldAreas = await _unitOfWorkLocation.Repository.Find(x => x.ClientId == bM.Id);
            model.NameAr = bM.NameAr;
            model.NameEn = bM.NameEn;
            model.DescriptionAr = bM.DescriptionAr;
            model.DescriptionEn = bM.DescriptionEn;
            model.IsActive = bM.IsActive;
            model.CategoryId = bM.CategoryId;
            model.LogoUrl = string.IsNullOrEmpty(bM.LogoUrl) ? logo : bM.LogoUrl;
            model.CoverUrl = string.IsNullOrEmpty(bM.CoverUrl) ? cover : bM.CoverUrl;
            model.Location = bM.Location;
            model.Lat = bM.Lat;
            model.Lng = bM.Lng;
            model.ModifyUserId = userId;
            model.ModifyDate = DateTime.UtcNow;
            model.AddressEn = bM.AddressEn;
            model.AddressAr = bM.AddressAr;

            var user = await _unitOfWorkUser.Repository.FirstOrDefault(x => x.Id == model.UserId);
            user.IsActive = bM.IsActive;
            user.Email = bM.Email;
            user.UserName = bM.Email;
            user.DeletedOn = DateTime.UtcNow;

            var genderIds = bM.GenderIds != null ? bM.GenderIds : (new List<int>()).ToArray();
            var areaIds = bM.LocationIds != null ? bM.LocationIds : (new List<long>()).ToArray();

            var areasToDelete = oldAreas.Where(x => !areaIds.Contains(x.AreaId));
            var newAreas = areaIds.Where(x => !oldAreas.Select(a => a.AreaId).ToList().Contains(x));
            var areas = new List<ClientLocation>();
            foreach (var item in newAreas)
            {
                areas.Add(new ClientLocation
                {
                    AreaId = item,
                    ClientId = bM.Id
                });
            }

            var genderToDelete = oldGenders.Where(x => !genderIds.Contains(x.GenderId));
            var newGenders = genderIds.Where(x => !oldGenders.Select(a => a.GenderId).ToList().Contains(x));
            var genders = new List<ClientGender>();
            foreach (var item in newGenders)
            {
                genders.Add(new ClientGender
                {
                    GenderId = item,
                    ClientId = bM.Id
                });
            }

            _unitOfWork.StartTransaction();

            _unitOfWork.Repository.Update(model);
            bool isUpdated = await _unitOfWork.SaveChanges() > 0;

            _unitOfWorkUser.Repository.UpdateCustomFields(user, x => x.IsActive, x => x.Email, x => x.UserName, x => x.DeletedOn);
            bool isUserUpdated = await _unitOfWorkUser.SaveChanges() > 0;

            bool isOldGenderDeleted = true;
            bool isOldAreaDeleted = true;
            bool isNewAreaAdded = true;
            bool isNewGenderAdded = true;

            if (areasToDelete.Any())
            {
                _unitOfWorkLocation.Repository.RemoveRange(areasToDelete);
                isOldAreaDeleted = await _unitOfWorkLocation.SaveChanges() > 0;
            }

            if (genderToDelete.Any())
            {
                _unitOfWorkClientGender.Repository.RemoveRange(genderToDelete);
                isOldGenderDeleted = await _unitOfWorkClientGender.SaveChanges() > 0;
            }

            if (genders.Any())
            {
                _unitOfWorkClientGender.Repository.AddRange(genders);
                isNewGenderAdded = await _unitOfWorkClientGender.SaveChanges() > 0;
            }

            if (areas.Any())
            {
                _unitOfWorkLocation.Repository.AddRange(areas);
                isNewAreaAdded = await _unitOfWorkLocation.SaveChanges() > 0;
            }

            if (isUserUpdated && isUpdated && isOldGenderDeleted && isOldAreaDeleted && isNewAreaAdded && isNewGenderAdded)
            {
                _unitOfWork.CommitTransaction();
            }
            else
            {
                _unitOfWork.Rollback();
            }
        }

        public async Task<AddClientParameters> GetBM(long id)
        {
            var bM = await _unitOfWork.Repository.FirstOrDefaultThenIncludeAsync(predicate: x => x.Id == id,
                include: x => x.Include(x => x.User)
                .Include(x => x.ClientGenders)
                .Include(x => x.ClientLocations));

            if (bM == null)
                return null;

            var client = new AddClientParameters
            {
                NameAr = bM.NameAr,
                NameEn = bM.NameEn,
                DescriptionAr = bM.DescriptionAr,
                DescriptionEn = bM.DescriptionEn,
                IsActive = bM.IsActive,
                CategoryId = bM.CategoryId,
                LogoUrl = bM.LogoUrl,
                CoverUrl = bM.CoverUrl,
                Location = bM.Location,
                Lat = bM.Lat,
                Lng = bM.Lng,
                Id = bM.Id,
                UserId = bM.UserId,
                Password = "xxxxx",
                Email = bM.User.Email,
                AddressAr = bM.AddressAr,
                AddressEn = bM.AddressEn,
                GenderIds = bM.ClientGenders.Select(x => x.GenderId).ToArray(),
                LocationIds = bM.ClientLocations.Select(x => x.AreaId).ToArray()
            };

            return client;
        }

        public async Task<AddClientParameters> GetBMByUserId(string id)
        {
            var bM = await _unitOfWork.Repository.FirstOrDefaultThenIncludeAsync(predicate: x => x.UserId == id,
                include: x => x.Include(x => x.User));

            if (bM == null)
                return null;

            var client = new AddClientParameters
            {
                NameAr = bM.NameAr,
                NameEn = bM.NameEn,
                DescriptionAr = bM.DescriptionAr,
                DescriptionEn = bM.DescriptionEn,
                IsActive = bM.IsActive,
                CategoryId = bM.CategoryId,
                LogoUrl = bM.LogoUrl,
                CoverUrl = bM.CoverUrl,
                Location = bM.Location,
                Lat = bM.Lat,
                Lng = bM.Lng,
                Id = bM.Id,
                UserId = bM.UserId,
                Password = "xxxxx",
                Email = bM.User.Email
            };

            return client;
        }

        public async Task<ClientDto> GetDetails(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefaultThenIncludeAsync(predicate: x => x.Id == id,
                include: x => x.Include(x => x.ClientCategory)
                 .Include(x => x.User));

            var client = Mapper.Map<ClientDto>(model);

            return client;
        }

        public async Task<AddClientParameters> GetByUserId(string id)
        {
            var bM = await _unitOfWork.Repository.FirstOrDefault(x => x.UserId == id);

            if (bM == null)
                return null;

            var client = new AddClientParameters
            {
                NameAr = bM.NameAr,
                NameEn = bM.NameEn,
                DescriptionAr = bM.DescriptionAr,
                DescriptionEn = bM.DescriptionEn,
                IsActive = bM.IsActive,
                CategoryId = bM.CategoryId,
                LogoUrl = bM.LogoUrl,
                CoverUrl = bM.CoverUrl,
                Location = bM.Location,
                Lat = bM.Lat,
                Lng = bM.Lng,
                Id = bM.Id,
                UserId = bM.UserId
            };

            return client;
        }

        public async Task<ClientDto> GetDetailsByUserId(string id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefaultThenIncludeAsync(predicate: x => x.UserId == id,
               include: x => x.Include(x => x.ClientCategory)
                .Include(x => x.User));

            var client = Mapper.Map<ClientDto>(model);

            return client;
        }

        private async Task IncreaseViews(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            if (model != null)
            {
                model.Views += 1;

                _unitOfWork.Repository.UpdateCustomFields(model, x => x.Views);
                await _unitOfWork.SaveChanges();
            }
        }

        //public PagedList<GarageDetails> GetGaragesApi(int countryId, PagingParams pagingParams, GarageSearchModel model)
        //{
        //    var models = _unitOfWork.garageRepository.SearchGarages(countryId, model);

        //    var garages = Mapper.Map<IEnumerable<GarageDetails>>(models);

        //    //rate filter
        //    if (model.Rate != null)
        //    {
        //        garages = garages.Where(x => model.Rate.Contains((int)x.Rate));
        //    }

        //    if (!string.IsNullOrEmpty(model.SearchKey) && !string.IsNullOrWhiteSpace(model.SearchKey))
        //    {
        //        garages = garages.Where(x => x.Name.ToLower().Contains(model.SearchKey.ToLower()));
        //    }

        //    var garagesWithDiscount = garages.Where(x => x.Discount != null);
        //    var garagesWithoutDiscount = garages.Where(x => x.Discount == null);

        //    garagesWithDiscount = garagesWithDiscount.OrderByDescending(x => x.Discount.DateFrom);
        //    garagesWithDiscount.ToList().ForEach(x => x.IsDiscount = true);
        //    garagesWithoutDiscount = garagesWithoutDiscount.OrderByDescending(x => x.CreatedOn);

        //    var list = (garagesWithDiscount ?? Enumerable.Empty<GarageDetails>())
        //        .Concat(garagesWithoutDiscount ?? Enumerable.Empty<GarageDetails>());
        //    // garages = garages.OrderByDescending(x => x.Discount != null ? x.Discount.DateFrom : x.CreatedOn);
        //    return new PagedList<GarageDetails>(list.OrderByDescending(x => x.IsFeatured).ThenByDescending(x => x.IsDiscount), pagingParams.PageNumber, pagingParams.PageSize);
        //}

        public async Task DeleteImage(long id)
        {
            var client = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            client.CoverUrl = null;
            _unitOfWork.Repository.UpdateCustomFields(client, x => x.CoverUrl);
            await _unitOfWork.SaveChanges();
        }

        public async Task DeleteLogo(long id)
        {
            var client = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            client.LogoUrl = null;
            _unitOfWork.Repository.UpdateCustomFields(client, x => x.LogoUrl);
            await _unitOfWork.SaveChanges();
        }

        #endregion

        #region Packages

        public async Task AddPackage(AddPackageParameters bM, string userId)
        {
            var model = new Package
            {
                NameAr = bM.NameAr,
                NameEn = bM.NameEn,
                SubCategoryId = bM.CategoryId == (int)CategoryEnum.DietitianCenter ? bM.SubCategoryId : (int?)null,
                DescriptionAr = bM.DescriptionAr,
                DescriptionEn = bM.DescriptionEn,
                IsActive = bM.IsActive,
                CategoryId = bM.CategoryId,
                ClientId = bM.ClientId,
                Duration = bM.Duration,
                Meals = bM.Meals,
                OldPrice = bM.OldPrice,
                Price = bM.Price,
                PeriodIndicatorId = bM.PeriodIndicatorId,
                CreateUserId = userId,
                CreateDate = DateTime.UtcNow,
            };

            if (model.CategoryId == (int)CategoryEnum.Coache)
            {
                model.Days = bM.CoachDays;
                model.Sessions = bM.CoachSessions;
            }
            else if (model.CategoryId == (int)CategoryEnum.RecoveryCenter)
            {
                model.Sessions = bM.RecoverySessions;
            }
            else if (model.CategoryId == (int)CategoryEnum.DietitianCenter)
            {
                model.Days = bM.CenterDays;
            }

            _unitOfWorkPackage.Repository.Add(model);
            await _unitOfWorkPackage.SaveChanges();
        }

        public async Task DeletePackage(long id)
        {
            var model = await _unitOfWorkPackage.Repository.FirstOrDefault(x => x.Id == id);

            model.IsDeleted = true;
            model.IsActive = false;
            model.DeleteDate = DateTime.UtcNow;

            _unitOfWorkPackage.Repository.Update(model);
            await _unitOfWorkPackage.SaveChanges();
        }

        public async Task EditPackage(AddPackageParameters bM, string userId)
        {
            var model = await _unitOfWorkPackage.Repository.FirstOrDefault(x => x.Id == bM.Id);
            model.NameAr = bM.NameAr;
            model.NameEn = bM.NameEn;
            model.DescriptionAr = bM.DescriptionAr;
            model.DescriptionEn = bM.DescriptionEn;
            model.IsActive = bM.IsActive;
            model.CategoryId = bM.CategoryId;
            model.ModifyUserId = userId;
            model.ModifyDate = DateTime.UtcNow;
            model.ClientId = bM.ClientId;
            model.Duration = bM.Duration;
            model.Meals = bM.Meals;
            model.OldPrice = bM.OldPrice;
            model.Price = bM.Price;
            model.PeriodIndicatorId = bM.PeriodIndicatorId;
            model.SubCategoryId = bM.CategoryId == (int)CategoryEnum.DietitianCenter ? bM.SubCategoryId : (int?)null;

            if (model.CategoryId == (int)CategoryEnum.Coache)
            {
                model.Days = bM.CoachDays;
                model.Sessions = bM.CoachSessions;
            }
            else if (model.CategoryId == (int)CategoryEnum.RecoveryCenter)
            {
                model.Sessions = bM.RecoverySessions;
            }
            else if (model.CategoryId == (int)CategoryEnum.DietitianCenter)
            {
                model.Days = bM.CenterDays;
            }

            _unitOfWorkPackage.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task<AddPackageParameters> GetPackageBM(long id)
        {
            var bM = await _unitOfWorkPackage.Repository.FirstOrDefault(x => x.Id == id);

            if (bM == null)
                return null;

            var model = new AddPackageParameters
            {
                NameAr = bM.NameAr,
                NameEn = bM.NameEn,
                SubCategoryId = bM.SubCategoryId,
                DescriptionAr = bM.DescriptionAr,
                DescriptionEn = bM.DescriptionEn,
                IsActive = bM.IsActive,
                CategoryId = bM.CategoryId,
                Id = bM.Id,
                ClientId = bM.ClientId,
                PeriodIndicatorId = bM.PeriodIndicatorId,
                Duration = bM.Duration,
                Meals = bM.Meals,
                Price = bM.Price,
                OldPrice = bM.OldPrice,
            };

            if (model.CategoryId == (int)CategoryEnum.Coache)
            {
                model.CoachDays = bM.Days;
                model.CoachSessions = bM.Sessions;
            }
            else if (model.CategoryId == (int)CategoryEnum.RecoveryCenter)
            {
                model.RecoverySessions = bM.Sessions;
            }
            else if (model.CategoryId == (int)CategoryEnum.DietitianCenter)
            {
                model.CenterDays = bM.Days;
            }

            return model;
        }

        public async Task<List<PackageDto>> GetPackages()
        {
            var models = _unitOfWorkPackage.Repository
                .FindThenInclude(predicate: x => x.IsActive == true && x.IsDeleted != true,
                include: i => i.Include(x => x.ClientCategory)
                .Include(x => x.Client)
                .Include(x => x.PeriodIndicator));

            var packages = Mapper.Map<List<PackageDto>>(models);

            return packages;
        }

        public async Task<List<PackageDto>> GetPackagesDDL(int categoryId = 0)
        {
            var models = _unitOfWorkPackage.Repository.FindQueryable(x => x.IsActive == true && x.IsDeleted != true);
            if (categoryId != 0)
            {
                models = models.Where(x => x.CategoryId == categoryId);
            }

            var result = models.ToList();
            var packages = Mapper.Map<List<PackageDto>>(result);

            return packages;
        }


        public async Task<IQueryable<PackageDto>> GetAdminPackages()
        {
            var query = _unitOfWorkPackage.Repository.FindQueryable(x => x.IsDeleted != true,
                    inc => inc.ClientCategory,
                    inc2 => inc2.Client,
                    x => x.PeriodIndicator);

            var clients = _unitOfWorkPackage.Repository.FindSelectorQueryable(query, selector: q => new PackageDto()
            {
                Id = q.Id,
                NameAr = q.NameAr,
                NameEn = q.NameEn,
                DescriptionAr = q.DescriptionAr,
                DescriptionEn = q.DescriptionEn,
                CategoryId = q.CategoryId,
                CreateUserId = q.CreateUserId,
                IsActive = q.IsActive,
                IsDeleted = q.IsDeleted,
                CreateDate = q.CreateDate,
                Meals = q.Meals,
                PeriodIndicatorId = q.PeriodIndicatorId,
                Price = q.Price,
                Sessions = q.Sessions,
                OldPrice = q.OldPrice,
                Days = q.Days,
                Duration = q.Duration,
                ClientId = q.ClientId,
                ClientCategory = new ClientCategoryDto
                {
                    Id = q.ClientCategory.Id,
                    NameAr = q.ClientCategory.NameAr,
                    NameEn = q.ClientCategory.NameEn,
                    IsActive = q.ClientCategory.IsActive,
                    ImageUrl = q.ClientCategory.ImageUrl
                },
                Client = new ClientDto
                {
                    UserId = q.Client.UserId,
                    NameAr = q.Client.NameAr,
                    NameEn = q.Client.NameEn,
                }

            });

            return clients;
        }

        public async Task<IQueryable<PackageDto>> GetClientPackages(string userId)
        {
            var query = _unitOfWorkPackage.Repository.FindQueryable(x => x.IsDeleted != true && x.Client.UserId == userId,
                    inc => inc.ClientCategory,
                    inc2 => inc2.Client,
                    x => x.PeriodIndicator);

            var clients = _unitOfWorkPackage.Repository.FindSelectorQueryable(query, selector: q => new PackageDto()
            {
                Id = q.Id,
                NameAr = q.NameAr,
                NameEn = q.NameEn,
                DescriptionAr = q.DescriptionAr,
                DescriptionEn = q.DescriptionEn,
                CategoryId = q.CategoryId,
                CreateUserId = q.CreateUserId,
                IsActive = q.IsActive,
                IsDeleted = q.IsDeleted,
                CreateDate = q.CreateDate,
                Meals = q.Meals,
                PeriodIndicatorId = q.PeriodIndicatorId,
                Price = q.Price,
                Sessions = q.Sessions,
                OldPrice = q.OldPrice,
                Days = q.Days,
                Duration = q.Duration,
                ClientId = q.ClientId,
                ClientCategory = new ClientCategoryDto
                {
                    Id = q.ClientCategory.Id,
                    NameAr = q.ClientCategory.NameAr,
                    NameEn = q.ClientCategory.NameEn,
                    IsActive = q.ClientCategory.IsActive,
                    ImageUrl = q.ClientCategory.ImageUrl
                },
                Client = new ClientDto
                {
                    UserId = q.Client.UserId,
                    NameAr = q.Client.NameAr,
                    NameEn = q.Client.NameEn,
                }

            });

            return clients;
        }

        public async Task<List<PaymentMethodDto>> GetPaymentMethodsDDL()
        {
            var models = _unitOfWorkPaymentMethods.Repository.FindQueryable(x => x.IsActive == true);

            var packages = Mapper.Map<List<PaymentMethodDto>>(models);

            return packages;
        }

        public async Task<List<GenderDto>> GetGenderDDL()
        {
            var models = _unitOfWorkGender.Repository.FindQueryable(x => true);

            var packages = Mapper.Map<List<GenderDto>>(models);

            return packages;
        }

        public async Task<IRepositoryActionResult> GetGenders()
        {
            var models = _unitOfWorkGender.Repository.FindQueryable(x => true);

            var genders = Mapper.Map<List<GenderDto>>(models);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, genders, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<List<AreaDetails>> GetLocationDDL()
        {
            var models = _unitOfWorkArea.Repository.FindQueryable(x => x.IsActive == true);

            var packages = Mapper.Map<List<AreaDetails>>(models);

            return packages;
        }

        public async Task<IRepositoryActionResult> GetPaymentMethods()
        {
            var models = _unitOfWorkPaymentMethods.Repository.FindQueryable(x => x.IsActive == true);

            var packages = Mapper.Map<List<PaymentMethodDto>>(models);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, packages, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        #endregion

        #region Subscriptions

        public async Task<IQueryable<SubscriptionDto>> GetAdminSubscriptions()
        {
            var query = _unitOfWorkSubscription.Repository.FindQueryable(x => x.IsDeleted != true,
                    inc => inc.ClientCategory,
                    inc => inc.Client,
                    inc => inc.Address,
                    inc => inc.Package,
                    inc => inc.PaymentMethod);

            var subscriptions = _unitOfWorkSubscription.Repository.FindSelectorQueryable(query, selector: q => new SubscriptionDto()
            {
                Id = q.Id,
                CategoryId = q.CategoryId,
                CreateUserId = q.CreateUserId,
                IsActive = q.IsActive,
                IsDeleted = q.IsDeleted,
                CreateDate = q.CreateDate,
                Meals = q.Meals,
                PeriodIndicatorId = q.PeriodIndicatorId,
                Price = q.Price,
                Sessions = q.Sessions,
                Days = q.Days,
                Duration = q.Duration,
                ClientId = q.ClientId,
                PackageId = q.PackageId,
                PaymentMethodId = q.PaymentMethodId,
                IsPaid = q.IsPaid,
                TransactionId = q.TransactionId,
                StartDate = q.StartDate,
                AddressId = q.AddressId,
                UserId = q.UserId,
                Package = new PackageDto
                {
                    Id = q.Package.Id,
                    NameEn = q.Package.NameEn,
                    NameAr = q.Package.NameAr
                },
                ClientCategory = new ClientCategoryDto
                {
                    Id = q.ClientCategory.Id,
                    NameAr = q.ClientCategory.NameAr,
                    NameEn = q.ClientCategory.NameEn,
                    IsActive = q.ClientCategory.IsActive,
                    ImageUrl = q.ClientCategory.ImageUrl
                },
                Client = new ClientDto
                {
                    UserId = q.Client.UserId,
                    NameAr = q.Client.NameAr,
                    NameEn = q.Client.NameEn,
                },
                PaymentMethod = new PaymentMethodDto
                {
                    Id = q.PaymentMethod.Id,
                    NameAr = q.PaymentMethod.NameAr,
                    NameEn = q.PaymentMethod.NameEn
                },
                User = new UserDto
                {
                    UserId = q.UserId,
                    FirstName = q.UserId,
                    LastName = q.User.LastName,
                    FullName = q.User.FirstName + " " + q.User.LastName
                }
            });

            return subscriptions;
        }

        public async Task<List<SubscriptionDto>> GetSubscriptions()
        {
            var models = _unitOfWorkSubscription.Repository.FindThenInclude(predicate: x => x.IsDeleted != true,
                               include: inc => inc.Include(x => x.ClientCategory)
                               .Include(x => x.Client)
                               .Include(x => x.Address)
                               .Include(x => x.Package)
                               .Include(x => x.PaymentMethod));

            var packages = Mapper.Map<List<SubscriptionDto>>(models);

            return packages;
        }

        public async Task<IRepositoryActionResult> GetUserSubscriptions(string userId, int pageNum = 0)
        {
            int skip = (pageNum > 0 ? pageNum - 1 : 0) * 10;
            int pageCount = 10;

            var models = _unitOfWorkSubscription.Repository.FindThenInclude(predicate: x => x.UserId == userId && x.IsPaid == true,
                               include: inc => inc.Include(x => x.ClientCategory)
                               .Include(x => x.Client)
                               .Include(x => x.Address)
                               .Include(x => x.Package)
                               .Include(x => x.PeriodIndicator)
                               .Include(x => x.PaymentMethod))
                .OrderByDescending(x => x.CreateDate);

            var list = models.Skip(skip).Take(pageCount).ToList();

            var packages = Mapper.Map<List<SubscriptionApiDto>>(list);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, packages, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<SubscriptionDto> GetSubscriptionDetails(long id)
        {
            var models = _unitOfWorkSubscription.Repository.FindThenInclude(predicate: x => x.Id == id,
                            include: inc =>
                            inc.Include(x => x.ClientCategory)
                               .Include(x => x.Client)
                               .Include(x => x.Address)
                               .Include(x => x.User)
                               .Include(x => x.PaymentMethod)
                               .Include(x => x.Package)
                               .Include(x => x.PeriodIndicator));

            var packages = Mapper.Map<SubscriptionDto>(models.FirstOrDefault());

            return packages;
        }

        public async Task<SubscriptionDto> GetSubscriptionDetails(string id)
        {
            var models = _unitOfWorkSubscription.Repository.FindThenInclude(predicate: x => x.ResponseId.Trim() == id.Trim(),
                            include: inc =>
                            inc.Include(x => x.ClientCategory)
                               .Include(x => x.Client)
                               .Include(x => x.Address)
                               .Include(x => x.User)
                               .Include(x => x.PaymentMethod)
                               .Include(x => x.Package)
                               .Include(x => x.PeriodIndicator));

            var packages = Mapper.Map<SubscriptionDto>(models.FirstOrDefault());

            return packages;
        }
        public async Task<IQueryable<SubscriptionDto>> GetClientSubscriptions(string id)
        {
            var query = _unitOfWorkSubscription.Repository.FindQueryable(x => x.IsDeleted != true && x.Client.UserId == id,
                    inc => inc.ClientCategory,
                    inc => inc.Client,
                    inc => inc.Address,
                    inc => inc.Package,
                    inc => inc.PaymentMethod);

            var subscriptions = _unitOfWorkSubscription.Repository.FindSelectorQueryable(query, selector: q => new SubscriptionDto()
            {
                Id = q.Id,
                CategoryId = q.CategoryId,
                CreateUserId = q.CreateUserId,
                IsActive = q.IsActive,
                IsDeleted = q.IsDeleted,
                CreateDate = q.CreateDate,
                Meals = q.Meals,
                PeriodIndicatorId = q.PeriodIndicatorId,
                Price = q.Price,
                Sessions = q.Sessions,
                Days = q.Days,
                Duration = q.Duration,
                ClientId = q.ClientId,
                PackageId = q.PackageId,
                PaymentMethodId = q.PaymentMethodId,
                IsPaid = q.IsPaid,
                TransactionId = q.TransactionId,
                StartDate = q.StartDate,
                AddressId = q.AddressId,
                UserId = q.UserId,
                Package = new PackageDto
                {
                    Id = q.Package.Id,
                    NameEn = q.Package.NameEn,
                    NameAr = q.Package.NameAr
                },
                ClientCategory = new ClientCategoryDto
                {
                    Id = q.ClientCategory.Id,
                    NameAr = q.ClientCategory.NameAr,
                    NameEn = q.ClientCategory.NameEn,
                    IsActive = q.ClientCategory.IsActive,
                    ImageUrl = q.ClientCategory.ImageUrl
                },
                Client = new ClientDto
                {
                    UserId = q.Client.UserId,
                    NameAr = q.Client.NameAr,
                    NameEn = q.Client.NameEn,
                },
                PaymentMethod = new PaymentMethodDto
                {
                    Id = q.PaymentMethod.Id,
                    NameAr = q.PaymentMethod.NameAr,
                    NameEn = q.PaymentMethod.NameEn
                },
                User = new UserDto
                {
                    UserId = q.UserId,
                    FirstName = q.UserId,
                    LastName = q.User.LastName,
                    FullName = q.User.FirstName + " " + q.User.LastName
                }
            });

            return subscriptions;
        }

        public async Task<IRepositoryActionResult> Subscribe(SubscribePackageParameters model, string userId, string baseUrl)
        {
            var package = await _unitOfWorkPackage.Repository.FirstOrDefault(x => x.Id == model.PackageId);
            if (package == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
            }

            if (package.ClientId != model.ClientId)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
            }

            if (package.CategoryId == (int)CategoryEnum.DietitianCenter && model.AddressId == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
            }

            string returnUrl = string.Empty;

            var subscription = new Subscription
            {
                PackageId = model.PackageId,
                ClientId = model.ClientId,
                CategoryId = package.CategoryId,
                AddressId = model.AddressId,
                Price = package.Price,
                OldPrice = package.OldPrice,
                Days = package.Days,
                Sessions = package.Sessions,
                PeriodIndicatorId = package.PeriodIndicatorId,
                Meals = package.Meals,
                Duration = package.Duration,
                PaymentMethodId = model.PaymentMethodId,
                StartDate = model.StartDate.ToUniversalTime(),
                TransactionId = DateTime.Now.Ticks.ToString(),
                UserId = userId,
                IsPaid = false,
                IsActive = true,
                CreateUserId = userId,
                CreateDate = DateTime.UtcNow,
            };

            var packageDto = new PackageDto
            {
                NameAr = package.NameAr,
                NameEn = package.NameEn,
                Price = package.Price
            };

            string refid = Guid.NewGuid().ToString();
            var invoiceResponseISO = await _hesabePaymentV2.CreateInvoiceISO_hesabe(packageDto, baseUrl, refid);

            subscription.ResponseId = refid;

            if (invoiceResponseISO.Status)
            {
                var url = _appSettings.Hesabe_merchant_Url + "/payment";
                returnUrl = $"{url}?data={invoiceResponseISO.Response.Data}";
            }
            else
            {
                returnUrl = $"/Subscriptions/error?data={invoiceResponseISO.Response.Data}";
            }

            _unitOfWorkSubscription.Repository.Add(subscription);
            bool isAdded = await _unitOfWorkSubscription.SaveChanges() > 0;

            if (isAdded)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: true, result: returnUrl, message: ResponseActionMessages.GetMesage(ResponseMessages.Created));
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
        }

        public async Task<IRepositoryActionResult> GenerateResponse(string fileUrl)
        {
            return RepositoryActionResult.GetRepositoryActionResult(success: true, result: fileUrl, message: ResponseActionMessages.GetMesage(ResponseMessages.Created));
        }

        public async Task UpdateSubscriptionAsPaid(long id, HesabePaymentResponse paymentResponse, bool status)
        {
            var subscription = await _unitOfWorkSubscription.Repository.FirstOrDefault(x => x.Id == id);

            subscription.ModifyDate = DateTime.UtcNow;
            subscription.PaymentId = paymentResponse.Response.PaymentId;
            subscription.RefId = paymentResponse.Response.PaymentToken.ToString();
            subscription.Gateway = paymentResponse.Response.Method.ToString();
            subscription.IsPaid = status;

            _unitOfWorkSubscription.Repository.Update(subscription);
            await _unitOfWorkSubscription.SaveChanges();
        }

        #endregion

    }
}
