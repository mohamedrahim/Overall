﻿using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Parameters.CitiesAndArea;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.CitiesAndArea
{
    public interface IAreaBusiness : IBaseBusiness
    {
        Task<List<AreaVM>> Areas(long cityId);
        Task Add(AreaBM bM, string userId);
        Task Edit(AreaBM bM, string userId);
        Task Delete(long id, string userId);
        Task<AreaBM> GetBM(long id);
        Task<AreaVM> GetOne(long id);
        Task<IRepositoryActionResult> GetAreasList(long cityId);
        Task<IRepositoryActionResult> GetCurrentLocation(string areaName);
    }
}
