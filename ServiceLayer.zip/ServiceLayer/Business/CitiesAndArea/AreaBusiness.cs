﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer.Models.DB;
using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Parameters.CitiesAndArea;
using HelperLayer.Utilities;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.Base;

namespace ServiceLayer.Business.CitiesAndArea
{
    public class AreaBusiness : BusinessBase<Area>, IAreaBusiness
    {
        public AreaBusiness(IBusinessBaseParameter<Area> businessBaseParameter) : base(businessBaseParameter)
        {
        }

        public async Task Add(AreaBM bM, string userId)
        {
            var model = Mapper.Map<Area>(bM);
            model.CreateDate = DateTime.UtcNow;
            model.CreateUserId = userId;

            _unitOfWork.Repository.Add(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task<List<AreaVM>> Areas(long cityId)
        {
            var model = await _unitOfWork.Repository.Find(x => x.CityId == cityId);
            var areas = Mapper.Map<List<AreaVM>>(model);

            return areas;
        }

        public async Task Delete(long id, string userId)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);

            model.IsDeleted = true;
            model.IsActive = false;
            model.DeleteDate = DateTime.UtcNow;
            model.DeteleUserId = userId;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task Edit(AreaBM bM, string userId)
        {
            var model = Mapper.Map<Area>(bM);
            model.ModifyDate = DateTime.UtcNow;
            model.ModifyUserId = userId;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task<IRepositoryActionResult> GetAreasList(long cityId)
        {
            if (cityId == 0)
            {
                var list = await _unitOfWork.Repository.Find(x => x.IsActive == true && x.IsDeleted != true);
                var models = Mapper.Map<List<AreaDetails>>(list);
                return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
            }
            else
            {
                var list = await _unitOfWork.Repository.Find(x => x.IsActive == true && x.IsDeleted != true && x.CityId == cityId);
                var models = Mapper.Map<List<AreaDetails>>(list);
                return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
            }
        }

        public async Task<AreaBM> GetBM(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var area = Mapper.Map<AreaBM>(model);

            return area;
        }

        public async Task<IRepositoryActionResult> GetCurrentLocation(string areaName)
        {
            var model = await _unitOfWork.Repository.FirstOrDefaultThenIncludeAsync(predicate: x => x.NameEn.ToLower() == areaName.Trim().ToLower() || x.NameAr == areaName.Trim(),
                include: x => x.Include(i => i.City));

            if (model == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            var area = new AreaLocationDetails
            {
                CityId = model.CityId,
                CityNameAr = model.City.NameAr,
                CityNameEn = model.City.NameEn,
                NameAr = model.NameAr,
                NameEn = model.NameEn,
                Id = model.Id,
                CreatedOn = model.CreateDate,
                IsActive = model.IsActive
            };

            return RepositoryActionResult.GetRepositoryActionResult(success: true, area, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<AreaVM> GetOne(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var area = Mapper.Map<AreaVM>(model);

            return area;
        }

    }
}
