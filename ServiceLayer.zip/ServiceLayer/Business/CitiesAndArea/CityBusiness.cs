﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer.Models.DB;
using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Parameters.CitiesAndArea;
using HelperLayer.Utilities;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.Base;

namespace ServiceLayer.Business.CitiesAndArea
{
    public class CityBusiness : BusinessBase<City>, ICityBusiness
    {
        public CityBusiness(IBusinessBaseParameter<City> businessBaseParameter) : base(businessBaseParameter)
        {
        }

        public async Task Add(CityBM bM, string userId)
        {
            var model = Mapper.Map<City>(bM);
            model.CreateDate = DateTime.Now;
            model.CreateUserId = userId;

            _unitOfWork.Repository.Add(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task Delete(long id, string userId)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);

            model.IsDeleted = true;
            model.IsActive = false;
            model.DeteleUserId = userId;
            model.DeleteDate = DateTime.UtcNow;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task Edit(CityBM bM, string userId)
        {
            var model = Mapper.Map<City>(bM);
            model.ModifyUserId = userId;
            model.ModifyDate = DateTime.UtcNow;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task<CityBM> GetBM(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var city = Mapper.Map<CityBM>(model);

            return city;
        }

        public async Task<List<CityVM>> GetCities()
        {
            var model = _unitOfWork.Repository.FindThenInclude(predicate: x => x.IsDeleted != true,
                include: x => x.Include(a => a.Areas));

            var cities = Mapper.Map<List<CityVM>>(model);

            return cities;
        }

        public async Task<List<CityVM>> GetAllActiveCities()
        {
            var model = await _unitOfWork.Repository.Find(x => x.IsActive == true && x.IsDeleted != true);
            var cities = Mapper.Map<List<CityVM>>(model);

            return cities;
        }

        public async Task<CityVM> GetDetails(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefaultThenIncludeAsync(
                predicate: x => x.Id == id && x.IsActive == true && x.IsDeleted != true,
                include: x => x.Include(i => i.Areas));

            var city = Mapper.Map<CityVM>(model);

            return city;
        }

        public async Task<CityVM> GetOne(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var city = Mapper.Map<CityVM>(model);

            return city;
        }

        public async Task<IRepositoryActionResult> GetCitiesList()
        {
            var list = await _unitOfWork.Repository.Find(x => x.IsDeleted != true && x.IsActive == true);
            var models = Mapper.Map<List<CityDetails>>(list);
            return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

    }
}
