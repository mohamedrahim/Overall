﻿using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Parameters.CitiesAndArea;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.CitiesAndArea
{
    public interface ICityBusiness:IBaseBusiness
    {
        Task<List<CityVM>> GetCities();
        Task<List<CityVM>> GetAllActiveCities();
        Task Add(CityBM bM, string userId);
        Task Edit(CityBM bM, string userId);
        Task Delete(long id, string userId);
        Task<CityBM> GetBM(long id);
        Task<CityVM> GetDetails(long id);
        Task<IRepositoryActionResult> GetCitiesList();
    }
}
