﻿using HelperLayer.Dtos.CategoryDtos;
using HelperLayer.Parameters.Categories;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Category
{
    public interface ICategoryBusiness : IBaseBusiness
    {
        //categories
        Task<List<CategoryVM>> GetCategories();
        Task Add(CategoryBM bM);
        Task Edit(CategoryBM bM);
        Task<CategoryBM> GetBM(int id);
        Task<CategoryVM> GetOne(int id);

        Task<IRepositoryActionResult> GetCategoriesApi();

        Task<List<CategoryDetails>> GetCategoriesDDL();

        Task<List<CategoryDetails>> GetCategoriesDDL(int parentCategoryId);

        Task<List<CategoryVM>> GetSubCategories(int categoryId);
        Task Delete(int id, string v);
        Task<IRepositoryActionResult> GetPackageCategoriesApi();
    }
}
