﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer.Models.DB;
using HelperLayer.Dtos.CategoryDtos;
using HelperLayer.Dtos.Clients;
using HelperLayer.Parameters.Categories;
using HelperLayer.Utilities;
using ServiceLayer.Base;

namespace ServiceLayer.Business.Category
{
    public class CategoryBusiness : BusinessBase<ClientCategory>, ICategoryBusiness
    {
        public CategoryBusiness(IBusinessBaseParameter<ClientCategory> businessBaseParameter) : base(businessBaseParameter)
        {
        }

        #region Category

        public async Task<List<CategoryVM>> GetCategories()
        {
            var model = await _unitOfWork.Repository.Find(x => true);
            var categories = Mapper.Map<List<CategoryVM>>(model);

            return categories;
        }

        public async Task<List<CategoryVM>> GetSubCategories(int categoryId)
        {
            var model = await _unitOfWork.Repository.Find(x => x.ParentCategoryId == categoryId);
            var categories = Mapper.Map<List<CategoryVM>>(model);

            return categories;
        }

        public async Task Add(CategoryBM bM)
        {
            var model = Mapper.Map<ClientCategory>(bM);
            var models = await _unitOfWork.Repository.Find(x => true);
            int lastId = models.Last().Id;

            model.Id = lastId + 1;
            _unitOfWork.Repository.Add(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task Edit(CategoryBM bM)
        {
            var model = Mapper.Map<ClientCategory>(bM);

            model.ModifyDate = DateTime.UtcNow;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task<CategoryBM> GetBM(int id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var category = Mapper.Map<CategoryBM>(model);

            return category;
        }

        public async Task<CategoryVM> GetOne(int id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var category = Mapper.Map<CategoryVM>(model);

            return category;
        }

        public async Task<IRepositoryActionResult> GetCategoriesApi()
        {
            var model = await _unitOfWork.Repository.Find(x => x.IsActive == true && x.ParentCategoryId == null);

            var models = Mapper.Map<List<CategoryDetailsApi>>(model);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> GetPackageCategoriesApi()
        {
            var model = await _unitOfWork.Repository.Find(x => x.ParentCategoryId == (int)CategoryEnum.DietitianCenter && x.IsActive == true);

            var models = Mapper.Map<List<PackageCategoryDto>>(model);
            if (models != null && models.Any())
            {
                models = models.Prepend(new PackageCategoryDto
                {
                    Id = 0,
                    NameAr = "الكل",
                    NameEn = "All"
                }).ToList();
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<List<CategoryDetails>> GetCategoriesDDL()
        {
            var model = await _unitOfWork.Repository.Find(x => x.IsActive == true);

            var models = Mapper.Map<List<CategoryDetails>>(model);

            return models;
        }

        public async Task<List<CategoryDetails>> GetCategoriesDDL(int parentCategoryId)
        {
            var model = await _unitOfWork.Repository.Find(x => x.IsActive == true && x.ParentCategoryId == parentCategoryId);

            var models = Mapper.Map<List<CategoryDetails>>(model);

            return models;
        }

        public async Task Delete(int id, string userId)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);

            model.IsDeleted = true;
            model.IsActive = false;
            model.DeleteDate = DateTime.UtcNow;
            model.DeleteUserId = userId;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        #endregion

    }
}
