﻿using DataLayer.Models;
using DataLayer.Models.DB;
using HelperLayer.Dtos.Account;
using HelperLayer.Parameters.Account;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Business.Services.UserSer
{
    public interface IUserBusiness : IBaseBusiness
    {
        Task<List<UserDataVM>> GetAdminUsers();
        Task<IQueryable<UserDataVM>> GetCustomerUsers();
        Task<UserDataVM> GetUserById(string userid);
        Task DeleteUser(string id);
        Task<UserDataBM> GetUserBM(string id);
        Task<List<UserDataVM>> GetModerators();
        Task UpdateUserPassword(AppUser user);
        Task<UserDataVM> GetUserByUserName(string userName);
        Task UpdateUserActiveStatus(string userId, bool status);
        Task<List<RolesDto>> ActionListRoles();
        Task<IRepositoryActionResult> GuestLogin(GuestRefreshToken model);
        Task<IRepositoryActionResult> GuestRegister();
        Task<ClientHomeDto> GetClientHomeStatistics(long clientId);
        Task<HomeDto> GetHomeStatistics();
        Task<IRepositoryActionResult> Login(LoginModel model);
        Task<IRepositoryActionResult> CreateAccount(AddCustomerParameters model);
        Task<IRepositoryActionResult> AccountDetails(string userId);
        Task<IRepositoryActionResult> EditAccount(EditCustomerParameters model, string userId);
        Task<IRepositoryActionResult> ChangePassword(ChangePasswordModel model, string userId);
        Task<IRepositoryActionResult> LogOut(LogoutParameters model);
        Task<IRepositoryActionResult> Delete(LogoutParameters model);
        Task<IRepositoryActionResult> ResetPassword(ResetPasswordParameters model, string baseUrl);

        Task<IRepositoryActionResult> Addresses(string userId);
        Task<IRepositoryActionResult> AddAddress(AddAddressParameters model, string userId);
        Task<IRepositoryActionResult> UpdateAddress(UpdateAddressParameters model, string userId);
        Task<IRepositoryActionResult> DeleteAddress(long addressId, string userId);

        Task<UserCode> GetUserCode(string id);
        Task UpdateUserCodeToNewPassword(string id);
        Task UpdateUserCode(string id);
        Task<UserCode> GetUserCodeToSetNewPassword(string id);
    }
}
