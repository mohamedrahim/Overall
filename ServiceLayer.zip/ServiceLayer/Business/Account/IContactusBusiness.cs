﻿using HelperLayer.Dtos.Account;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Account
{
    public interface IContactusBusiness : IBaseBusiness
    {
        Task<IRepositoryActionResult> Add(ContactusParameters model, string userId);
        Task<IQueryable<ContactusDto>> GetAll();
    }
}
