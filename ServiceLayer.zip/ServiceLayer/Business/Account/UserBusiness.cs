﻿using Business.Services.SettingsSer;
using DataLayer.Abstract;
using DataLayer.Models;
using DataLayer.Models.DB;
using HelperLayer.Dtos.Account;
using HelperLayer.Dtos.Clients;
using HelperLayer.Parameters.Account;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services.UserSer
{
    public class UserBusiness : BusinessBase<AppUser>, IUserBusiness
    {
        IAppSettings _appSettings;
        IUnitOfWork<Client> _unitOfWorkClient;
        IUnitOfWork<Favorite> _unitOfWorkFavorite;
        IUnitOfWork<Package> _unitOfWorkPackage;
        IUnitOfWork<Subscription> _unitOfWorkSubscription;
        IUnitOfWork<AppRole> _unitOfWorkRole;
        IUnitOfWork<Address> _unitOfWorkAddress;
        IUnitOfWork<DeviceToken> _unitOfWorkDeviceToken;
        IUnitOfWork<UserCode> _unitOfWorkUserCode;
        readonly UserManager<AppUser> _userManager;
        IConfiguration _configuration;

        public UserBusiness(IAppSettings appSettings,
            IUnitOfWork<AppRole> unitOfWorkRole,
            IUnitOfWork<Client> unitOfWorkClient,
            IUnitOfWork<Package> unitOfWorkPackage,
            IUnitOfWork<Address> unitOfWorkAddress,
            IUnitOfWork<Subscription> unitOfWorkSubscription,
            IUnitOfWork<DeviceToken> unitOfWorkDeviceToken,
            IUnitOfWork<Favorite> unitOfWorkFavorite,
            IUnitOfWork<UserCode> unitOfWorkUserCode,
            IConfiguration configuration,
            UserManager<AppUser> userManager,
            IBusinessBaseParameter<AppUser> businessBaseParameter)
            : base(businessBaseParameter)
        {
            _appSettings = appSettings;
            _unitOfWorkClient = unitOfWorkClient;
            _unitOfWorkPackage = unitOfWorkPackage;
            _unitOfWorkSubscription = unitOfWorkSubscription;
            _unitOfWorkRole = unitOfWorkRole;
            _configuration = configuration;
            _userManager = userManager;
            _unitOfWorkAddress = unitOfWorkAddress;
            _unitOfWorkDeviceToken = unitOfWorkDeviceToken;
            _unitOfWorkFavorite = unitOfWorkFavorite;
            _unitOfWorkUserCode = unitOfWorkUserCode;
        }


        #region Users
        public async Task DeleteUser(string id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            if (model != null)
            {
                model.IsActive = false;
                model.IsDeleted = true;
                model.DeletedOn = DateTime.UtcNow;

                _unitOfWork.Repository.Update(model);
                await _unitOfWork.SaveChanges();
            }
        }

        public async Task<List<UserDataVM>> GetAdminUsers()
        {
            var models = await _unitOfWork.Repository.Find(x => x.Type == (int)UserTypes.Admin && x.IsDeleted != true);
            var res = Mapper.Map<List<UserDataVM>>(models);
            return res;
        }

        public async Task<IQueryable<UserDataVM>> GetCustomerUsers()
        {
            var query = _unitOfWork.Repository.FindQueryable(x => x.Type == (int)UserTypes.Customer && x.IsDeleted != true);

            var models = _unitOfWork.Repository.FindSelectorQueryable(myQueryable: query,
                selector: x => new UserDataVM
                {
                    Id = x.Id,
                    Email = x.Email,
                    CreatedOn = x.CreatedOn,
                    EmailConfirmed = x.EmailConfirmed,
                    FirstName = x.FirstName,
                    IsActive = x.IsActive,
                    LastLogin = x.LastLogin,
                    LastName = x.LastName,
                    NormalizedEmail = x.NormalizedEmail,
                    NormalizedUserName = x.NormalizedUserName,
                    PhoneNumber = x.PhoneNumber,
                    PhoneNumberConfirmed = x.PhoneNumberConfirmed,
                    Type = x.Type,
                    UserName = x.UserName,
                    Name = x.FirstName + " " + x.LastName
                });

            return models;
        }

        public async Task<UserDataBM> GetUserBM(string id)
        {
            var models = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var res = Mapper.Map<UserDataBM>(models);

            return res;
        }

        public async Task<UserDataVM> GetUserById(string userid)
        {
            var models = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == userid);
            var res = Mapper.Map<UserDataVM>(models);

            return res;
        }

        public async Task<UserDataVM> GetUserByUserName(string userName)
        {
            var models = await _unitOfWork.Repository.FirstOrDefault(x => x.UserName == userName);
            var res = Mapper.Map<UserDataVM>(models);

            return res;
        }

        public async Task<List<UserDataVM>> GetModerators()
        {
            var moderators = await _unitOfWork.Repository.Find(x => x.Type == (int)UserTypes.Admin && x.UserName != "Admin");
            var res = Mapper.Map<List<UserDataVM>>(moderators);
            return res;
        }

        public async Task UpdateUserPassword(AppUser user)
        {
            if (user.SecurityStamp == null)
            {
                user.SecurityStamp = "";
                await _userManager.UpdateSecurityStampAsync(user);
            }

            await _userManager.UpdateAsync(user);
        }

        public async Task UpdateUserActiveStatus(string userId, bool status)
        {
            var client = await _unitOfWorkClient.Repository.FirstOrDefault(x => x.UserId == userId);
            client.IsActive = status;

            _unitOfWorkClient.Repository.UpdateCustomFields(client, x => x.IsActive);
            await _unitOfWork.SaveChanges();
        }

        public async Task<HomeDto> GetHomeStatistics()
        {
            var clients = _unitOfWorkClient.Repository.FindQueryable(x => x.IsActive == true);
            var packages = _unitOfWorkPackage.Repository.FindQueryable(x => x.IsActive == true);
            var subscriptions = _unitOfWorkSubscription.Repository.FindQueryable(x => x.IsActive == true);
            var customers = _unitOfWork.Repository.FindQueryable(x => x.IsActive == true && x.Type == (int)UserTypes.Customer);

            return new HomeDto
            {
                Clients = clients.Count(),
                Customers = customers.Count(),
                Packages = packages.Count(),
                PackageSubscriptions = subscriptions.Count()
            };
        }

        public async Task<ClientHomeDto> GetClientHomeStatistics(long clientId)
        {
            var packages = _unitOfWorkPackage.Repository.FindQueryable(x => x.IsActive == true && x.ClientId == clientId);
            var subscriptions = _unitOfWorkSubscription.Repository.FindQueryable(x => x.IsActive == true && x.ClientId == clientId);

            return new ClientHomeDto
            {
                Packages = packages.Count(),
                PackageSubscriptions = subscriptions.Count()
            };
        }

        public async Task<List<RolesDto>> ActionListRoles()
        {
            var roles = await _unitOfWorkRole.Repository.Find(x => x.Name != "Admin" && x.Name != "Moderator" && x.Name != "Center");

            return roles.Select(x => new RolesDto
            {
                Id = x.Id,
                Name = x.Name
            }).ToList();

        }

        public async Task<IRepositoryActionResult> GuestLogin(GuestRefreshToken model)
        {
            var user = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == model.UserId);
            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            var dto = new LoginOutputModel
            {
                UserId = user.Id,
                IsGuest = true,
                Email = user.UserName,
                Username = user.UserName,
                Name = user.UserName,
                Token = GetToken(user)
            };

            return RepositoryActionResult.GetRepositoryActionResult(success: true, dto, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> LogOut(LogoutParameters model)
        {
            var user = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == model.UserId);
            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            var deviceToken = await _unitOfWorkDeviceToken.Repository.FirstOrDefault(x => x.DeviceId == model.DeviceId && x.UserId == model.UserId);
            if (deviceToken != null)
            {
                _unitOfWorkDeviceToken.Repository.Remove(deviceToken);
                await _unitOfWorkDeviceToken.SaveChanges();
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> Delete(LogoutParameters model)
        {
            var user = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == model.UserId);
            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            user.IsDeleted = true;
            user.DeletedOn = DateTime.UtcNow;
            user.IsActive = true;

            _unitOfWork.Repository.UpdateCustomFields(user, x => x.IsDeleted, x => x.IsActive, x => x.DeletedOn);
            await _unitOfWork.SaveChanges();

            var deviceToken = await _unitOfWorkDeviceToken.Repository.FirstOrDefault(x => x.DeviceId == model.DeviceId && x.UserId == model.UserId);
            if (deviceToken != null)
            {
                _unitOfWorkDeviceToken.Repository.Remove(deviceToken);
                await _unitOfWorkDeviceToken.SaveChanges();
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> ResetPassword(ResetPasswordParameters model, string baseUrl)
        {
            var user = await _unitOfWork.Repository.FirstOrDefault(x => x.Email == model.Email);

            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            Random random = new Random();
            var code = random.Next(1000, 9999);

            _unitOfWorkUserCode.Repository.Add(new UserCode
            {
                UserId = user.Id,
                Code = code.ToString(),
                ValidTo = DateTime.Now.AddHours(1),
                Status = 1
            });

            await _unitOfWorkUserCode.SaveChanges();

            string url = string.Concat(baseUrl, "/Account/ResetPassword?email=", model.Email, "&code=", code);
            string Subject = "Change Password Confirmation Email";

            string Body = $@"<a style='padding:12px 27px;color:#000;text-decoration:none;display:block;border:2px solid #000;border-radius:5px;font-weight: bold;' href='{url}' target='_blank' data-saferedirecturl={url}'>
                        Reset Your Password</a>";

            var UrlFolder = string.Concat(baseUrl, FileHelper.BaseFileUrl, "logo.png");

            var sendMail = EmailService.SendUserForgetPassword(_appSettings, user.Email, Subject, Body, UrlFolder);

            if (true)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: true, result: url, message: ResponseActionMessages.GetMesage(ResponseMessages.RecoveryEmail));
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: false, result: url, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
        }

        public async Task<IRepositoryActionResult> Login(LoginModel model)
        {
            var user = _userManager.Users.FirstOrDefault(x => x.Type == (byte)UserTypes.Customer && x.Email == model.Email && x.IsActive == true);
            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.WrongUserNameOrPassword));
            }

            var login = await _userManager.CheckPasswordAsync(user, model.Password);

            if (login)
            {
                user.LastLogin = DateTime.Now;

                if (user.SecurityStamp == null)
                {
                    user.SecurityStamp = "";
                    await _userManager.UpdateSecurityStampAsync(user);
                }

                await _userManager.UpdateAsync(user);

                if (!string.IsNullOrEmpty(model.GuestUserId))
                {
                    var favorite = await _unitOfWorkFavorite.Repository.Find(x => x.UserId == model.GuestUserId);
                    var favs = favorite.ToList();
                    favs.ForEach(x =>
                    {
                        x.UserId = user.Id;
                    });

                    var addresses = await _unitOfWorkAddress.Repository.Find(x => x.UserId == model.GuestUserId);
                    var adds = addresses.ToList();
                    adds.ForEach(x =>
                    {
                        x.UserId = user.Id;
                    });

                    _unitOfWorkFavorite.Repository.UpdateRange(favs);
                    await _unitOfWorkFavorite.SaveChanges();

                    _unitOfWorkAddress.Repository.UpdateRange(adds);
                    await _unitOfWorkAddress.SaveChanges();
                }

                var dto = new LoginOutputModel
                {
                    UserId = user.Id,
                    IsGuest = false,
                    Email = user.Email,
                    Username = user.UserName,
                    Name = user.FirstName + " " + user.LastName,
                    Token = GetToken(user)
                };

                return RepositoryActionResult.GetRepositoryActionResult(success: true, dto, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.WrongUserNameOrPassword));
        }

        public async Task<IRepositoryActionResult> GuestRegister()
        {
            var code = string.Format("{0:d9}", (DateTime.Now.Ticks / 10) % 1000000000);
            var user = new AppUser
            {
                PreferredLang = (byte)2,
                IsActive = true,
                UserName = "guest" + code,
                NormalizedUserName = "GUEST" + code,
                CreatedOn = DateTime.UtcNow,
                IsGuest = true,
            };

            user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, "123");

            await _userManager.CreateAsync(user);

            var dto = new LoginOutputModel
            {
                UserId = user.Id,
                IsGuest = true,
                Email = user.UserName,
                Username = user.UserName,
                Name = user.UserName,
                Token = GetToken(user)
            };

            return RepositoryActionResult.GetRepositoryActionResult(success: true, dto, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> CreateAccount(AddCustomerParameters registerModel)
        {
            if (string.IsNullOrEmpty(registerModel.GuestUserId))
            {
                if (!EmailCheck(registerModel.Email, ""))
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.EmailExist));
                }

                if (!MobileCheck(registerModel.PhoneNumber, ""))
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.MobileExist));
                }

                if (registerModel.Password.Length < 6)
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.PasswordValidLength));
                }

                var user = new AppUser
                {
                    UserName = registerModel.Email,
                    Email = registerModel.Email,
                    PhoneNumber = registerModel.PhoneNumber,
                    FirstName = registerModel.FirstName,
                    LastName = registerModel.LastName,
                    Type = (byte)UserTypes.Customer,
                    CreatedOn = DateTime.UtcNow,
                    LastLogin = DateTime.UtcNow,
                    IsDeleted = false,
                    IsActive = true,
                    IsGuest = false,
                    PreferredLang = (ResourcesReader.IsArabic ? (byte)1 : (byte)2),
                };

                user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, registerModel.Password);

                var addedUser = _unitOfWork.Repository.Add(user);
                await _unitOfWork.SaveChanges();

                var dto = new LoginOutputModel
                {
                    UserId = addedUser.Id,
                    IsGuest = false,
                    Email = addedUser.Email,
                    Username = addedUser.UserName,
                    Name = addedUser.FirstName + " " + addedUser.LastName,
                    Token = GetToken(addedUser)
                };

                return RepositoryActionResult.GetRepositoryActionResult(success: true, dto, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
            }
            else
            {
                var user = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == registerModel.GuestUserId && x.IsGuest == true);
                if (user == null)
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
                }

                if (!EmailCheck(registerModel.Email, ""))
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.EmailExist));
                }

                if (!MobileCheck(registerModel.PhoneNumber, ""))
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.MobileExist));
                }

                if (registerModel.Password.Length < 6)
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.PasswordValidLength));
                }

                user.UserName = registerModel.Email;
                user.Email = registerModel.Email;
                user.PhoneNumber = registerModel.PhoneNumber;
                user.FirstName = registerModel.FirstName;
                user.LastName = registerModel.LastName;
                user.Type = (byte)UserTypes.Customer;
                user.LastLogin = DateTime.UtcNow;
                user.IsDeleted = false;
                user.IsActive = true;
                user.IsGuest = false;
                user.PreferredLang = (ResourcesReader.IsArabic ? (byte)1 : (byte)2);

                if (user.SecurityStamp == null)
                {
                    user.SecurityStamp = "";
                    await _userManager.UpdateSecurityStampAsync(user);
                }

                await _userManager.UpdateAsync(user);

                var dto = new LoginOutputModel
                {
                    UserId = user.Id,
                    IsGuest = false,
                    Email = user.Email,
                    Username = user.UserName,
                    Name = user.FirstName + " " + user.LastName,
                    Token = GetToken(user)
                };

                return RepositoryActionResult.GetRepositoryActionResult(success: true, dto, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
            }
        }

        public async Task<IRepositoryActionResult> AccountDetails(string userId)
        {
            var user = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == userId);
            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            var dto = new UserDto
            {
                UserId = user.Id,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                UserName = user.UserName,
                FirstName = user.FirstName,
                LastName = user.LastName,
                FullName = user.FirstName + " " + user.LastName,
            };

            return RepositoryActionResult.GetRepositoryActionResult(success: true, dto, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> EditAccount(EditCustomerParameters model, string userId)
        {
            var user = await _userManager.FindByIdAsync(model.UserId);

            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
            }

            if (userId != model.UserId)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
            }

            if (!EmailCheck(model.Email, userId))
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.EmailExist));
            }

            if (!MobileCheck(model.PhoneNumber, userId))
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.MobileExist));
            }

            user.UserName = model.Email;
            user.Email = model.Email;
            user.PhoneNumber = model.PhoneNumber;
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;

            if (user.SecurityStamp == null)
            {
                user.SecurityStamp = "";
                await _userManager.UpdateSecurityStampAsync(user);
            }

            await _userManager.UpdateAsync(user);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Updated));
        }

        public async Task<IRepositoryActionResult> ChangePassword(ChangePasswordModel model, string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.Error));
            }

            var check = await _userManager.CheckPasswordAsync(user, model.OldPassword);
            if (check)
            {
                if (model.NewPassword.Length < 6)
                {
                    return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.PasswordValidLength));
                }

                user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, model.NewPassword);
                await UpdateUserPassword(user);

                return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Updated));
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.WrongPassword));
        }

        private string GetToken(AppUser user)
        {
            var utcNow = DateTime.UtcNow;

            var claims = new List<Claim>
            {
                        new Claim(JwtRegisteredClaimNames.Sub, user.Id),
                        new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, utcNow.ToString()),
                        new Claim("username", user.UserName),
                        new Claim("Id", user.Id),
                        new Claim("isGuest", user.IsGuest.ToString())
            };

            var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Tokens:Key"]));
            var signingCredentials = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);
            var jwt = new JwtSecurityToken(
                signingCredentials: signingCredentials,
                claims: claims,
                notBefore: utcNow,
                expires: utcNow.AddYears(1),
                audience: this._configuration.GetValue<String>("Tokens:Issuer"),
                issuer: this._configuration.GetValue<String>("Tokens:Issuer")
                );

            return new JwtSecurityTokenHandler().WriteToken(jwt);
        }

        private bool EmailCheck(string Email, string Id)
        {
            if (string.IsNullOrEmpty(Id))
            {
                var checkExist = _userManager.Users.Any(x => x.Email.Equals(Email) && x.IsDeleted != true);
                if (checkExist)
                    return false;
            }
            else
            {
                var checkExist = _userManager.Users.Any(x => x.Email.Equals(Email)
                && x.Id != Id
                && x.IsDeleted != true);

                if (checkExist)
                    return false;
            }
            return true;
        }

        private bool MobileCheck(string phoneNumber, string Id)
        {
            if (string.IsNullOrEmpty(Id))
            {
                var checkExist = _userManager.Users.Any(x => x.PhoneNumber.Equals(phoneNumber) && x.IsDeleted != true);
                if (checkExist)
                    return false;
            }
            else
            {
                var checkExist = _userManager.Users.Any(x => x.PhoneNumber.Equals(phoneNumber)
                && x.Id != Id
                && x.IsDeleted != true);

                if (checkExist)
                    return false;
            }
            return true;
        }

        #endregion

        #region Addresses

        public async Task<IRepositoryActionResult> Addresses(string userId)
        {
            var models = _unitOfWorkAddress.Repository.FindThenInclude(predicate: x => x.UserId == userId && x.IsActive == true && x.IsDeleted != true,
                  include: i =>
                  i.Include(x => x.City)
                   .Include(x => x.Area));

            var addresses = Mapper.Map<List<AddressDto>>(models);

            addresses.ForEach(x =>
                {
                    x.full_address = (string.IsNullOrEmpty(x.AddressTitle) ? "" : (x.AddressTitle + ", ")) +
                                     (string.IsNullOrEmpty(x.BlockNo) ? "" : (x.BlockNo + ", ")) +
                                     (string.IsNullOrEmpty(x.StreetName) ? "" : (x.StreetName + ", ")) +
                                     (string.IsNullOrEmpty(x.BuildNo) ? "" : (x.BuildNo + ", ")) +
                                     (string.IsNullOrEmpty(x.Avenue) ? "" : (x.Avenue + ", ")) +
                                     (string.IsNullOrEmpty(x.FloorNo) ? "" : (x.FloorNo + ", ")) +
                                     (string.IsNullOrEmpty(x.ApartmentNo) ? "" : (x.ApartmentNo + ", ")) +
                                     (ResourcesReader.IsArabic ? x.Area.NameAr : x.Area.NameEn) + ", " +
                                     (ResourcesReader.IsArabic ? x.City.NameAr : x.City.NameEn);
                });

            return RepositoryActionResult.GetRepositoryActionResult(success: true, addresses, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

        public async Task<IRepositoryActionResult> AddAddress(AddAddressParameters model, string userId)
        {
            var address = new Address
            {
                AreaId = model.AreaId,
                CityId = model.CityId,
                BlockNo = model.BlockNo,
                AddressDetails = model.AddressDetails,
                AddressTitle = model.AddressTitle,
                BuildNo = model.BuildNo,
                Avenue = model.Avenue,
                ApartmentNo = model.ApartmentNo,
                FloorNo = model.FloorNo,
                StreetName = model.StreetName,
                Mobile = model.Mobile,
                Email = model.Email,
                UserId = userId,
                CreateUserId = userId,
                CreateDate = DateTime.UtcNow,
                IsActive = true,
                IsDeleted = false,
            };

            _unitOfWorkAddress.Repository.Add(address);
            await _unitOfWorkAddress.SaveChanges();

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Created));
        }

        public async Task<IRepositoryActionResult> UpdateAddress(UpdateAddressParameters model, string userId)
        {
            var address = await _unitOfWorkAddress.Repository.FirstOrDefault(x => x.Id == model.Id && x.UserId == userId);
            if (address == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            address.AreaId = model.AreaId;
            address.CityId = model.CityId;
            address.BlockNo = model.BlockNo;
            address.AddressDetails = model.AddressDetails;
            address.AddressTitle = model.AddressTitle;
            address.BuildNo = model.BuildNo;
            address.Avenue = model.Avenue;
            address.ApartmentNo = model.ApartmentNo;
            address.FloorNo = model.FloorNo;
            address.StreetName = model.StreetName;
            address.Mobile = model.Mobile;
            address.Email = model.Email;
            address.ModifyUserId = userId;
            address.ModifyDate = DateTime.UtcNow;

            _unitOfWorkAddress.Repository.Update(address);
            await _unitOfWorkAddress.SaveChanges();

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Updated));
        }

        public async Task<IRepositoryActionResult> DeleteAddress(long addressId, string userId)
        {
            var address = await _unitOfWorkAddress.Repository.FirstOrDefault(x => x.Id == addressId && x.UserId == userId);
            if (address == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            address.IsActive = false;
            address.IsDeleted = true;
            address.DeteleUserId = userId;
            address.DeleteDate = DateTime.UtcNow;

            _unitOfWorkAddress.Repository.Update(address);
            await _unitOfWorkAddress.SaveChanges();

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Deleted));
        }

        public async Task<UserCode> GetUserCode(string id)
        {
            var userCode = await _unitOfWorkUserCode.Repository.FirstOrDefault(x => x.UserId == id && x.Status == 1);
            return userCode;
        }

        public async Task UpdateUserCodeToNewPassword(string id)
        {
            var userCode = await _unitOfWorkUserCode.Repository.FirstOrDefault(x => x.UserId == id && x.Status == 1);

            userCode.Status = 2;

            _unitOfWorkUserCode.Repository.UpdateCustomFields(userCode, x => x.Status);
            await _unitOfWorkUserCode.SaveChanges();
        }

        public async Task UpdateUserCode(string id)
        {
            var oldCodes = await _unitOfWorkUserCode.Repository.Find(x => x.UserId == id
                                                && x.Status != 0);

            for (int i = 0; i < oldCodes.Count(); i++)
            {
                oldCodes[i].Status = 0;
            }

            _unitOfWorkUserCode.Repository.UpdateRange(oldCodes);
            await _unitOfWorkUserCode.SaveChanges();
        }

        public async Task<UserCode> GetUserCodeToSetNewPassword(string id)
        {
            var userCode = await _unitOfWorkUserCode.Repository.FirstOrDefault(x => x.UserId == id && x.Status == 2);
            return userCode;
        }

        #endregion

    }
}
