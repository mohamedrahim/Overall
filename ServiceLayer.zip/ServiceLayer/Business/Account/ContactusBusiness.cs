﻿using DataLayer.Models.DB;
using HelperLayer.Dtos.Account;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Account
{
    public class ContactusBusiness : BusinessBase<Contactus>, IContactusBusiness
    {
        public ContactusBusiness(IBusinessBaseParameter<Contactus> businessBaseParameter) : base(businessBaseParameter)
        {
        }

        public async Task<IRepositoryActionResult> Add(ContactusParameters model, string userId)
        {
            var oldMessages = await _unitOfWork.Repository.Find(x => x.CreateUserId == userId && x.CreateDate.Date == DateTime.UtcNow.Date);
            if (oldMessages.Count() <= 1)
            {
                var message = Mapper.Map<Contactus>(model);

                message.CreateDate = DateTime.UtcNow;
                message.IsActive = true;
                message.CreateUserId = userId;

                _unitOfWork.Repository.Add(message);
                await _unitOfWork.SaveChanges();
            }
            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Created));
        }

        public async Task<IQueryable<ContactusDto>> GetAll()
        {
            var query = _unitOfWork.Repository.FindQueryable(x => x.IsActive == true);
            var models = _unitOfWork.Repository.FindSelectorQueryable(query, selector: q => new ContactusDto()
            {
                Id = q.Id,
                Email = q.Email,
                Message = q.Message,
                Subject = q.Subject,
                CreateDate = q.CreateDate
            });

            return models;
        }

    }
}
