﻿using HelperLayer.Dtos.Faqs;
using HelperLayer.Parameters.Faqs;
using HelperLayer.Utilities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Faqs
{
    public interface IFaqBusiness
    {
        Task<List<FaqVM>> GetAll();
        Task<List<FaqDto>> GetFAQs();
        Task<FaqVM> GetOne(long id);
        Task<FaqBM> GetBM(long id);
        Task add(FaqBM bM);
        Task Edit(FaqBM bM);
        Task Delete(long id);
        Task<IRepositoryActionResult> FAQs();
    }
}
