﻿using DataLayer.Models.DB;
using HelperLayer.Dtos.Faqs;
using HelperLayer.Parameters.Faqs;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Faqs
{
    public class FaqBusiness : BusinessBase<Faq>, IFaqBusiness
    {
        public FaqBusiness(IBusinessBaseParameter<Faq> businessBaseParameter) : base(businessBaseParameter)
        {
        }

        public async Task add(FaqBM bM)
        {
            var model = Mapper.Map<Faq>(bM);
            _unitOfWork.Repository.Add(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task Delete(long id)
        {
            var model = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            model.IsDeleted = true;
            model.IsActive = false;
            model.DeleteDate = DateTime.UtcNow;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task Edit(FaqBM bM)
        {
            var model = Mapper.Map<Faq>(bM);
            model.ModifyDate = DateTime.UtcNow;

            _unitOfWork.Repository.Update(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task<List<FaqVM>> GetAll()
        {
            var models = await _unitOfWork.Repository.Find(x => x.IsDeleted != true);
            var res = Mapper.Map<List<FaqVM>>(models);

            return res;
        }

        public async Task<List<FaqDto>> GetFAQs()
        {
            var models = await _unitOfWork.Repository.Find(x => x.IsActive == true);
            var res = Mapper.Map<List<FaqDto>>(models);

            return res;
        }

        public async Task<IRepositoryActionResult> FAQs()
        {
            var models = await _unitOfWork.Repository.Find(x => x.IsActive == true && x.IsDeleted != true);

            var faqs = Mapper.Map<List<FaqDto>>(models);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, faqs, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }


        public async Task<FaqBM> GetBM(long id)
        {
            var models = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var res = Mapper.Map<FaqBM>(models);

            return res;
        }

        public async Task<FaqVM> GetOne(long id)
        {
            var models = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == id);
            var res = Mapper.Map<FaqVM>(models);

            return res;
        }

    }
}
