﻿using DataLayer.Models.DB;
using HelperLayer.Dtos.SliderDto;
using HelperLayer.Parameters.SliderParameters;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.Extensions;
using HelperLayer.Utilities;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.Business.Clients;

namespace ServiceLayer.Business.Sliders
{
    public class SliderBusiness : BusinessBase<Slider>, ISliderBusiness
    {
        IClientsBusiness _clientsBusiness;
        public SliderBusiness(IBusinessBaseParameter<Slider> businessBaseParameter,
            IClientsBusiness clientsBusiness) : base(businessBaseParameter)
        {
            _clientsBusiness = clientsBusiness;
        }

        public async Task AddSlider(SliderParameter parameter, string userId)
        {
            var model = new Slider
            {
                Id = parameter.Id,
                ClientId = parameter.ClientId,
                ImageUrl = parameter.ImageUrl,
                ExternalLink = parameter.ExternalLink,
                CreateDate = DateTime.UtcNow,
                CreateUserId = userId,
                IsActive = parameter.IsActive,
            };

            _unitOfWork.Repository.Add(model);
            await _unitOfWork.SaveChanges();
        }

        public async Task DeleteSliderImage(long Id, string userId)
        {
            var slider = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == Id);
            if (slider != null)
            {
                slider.ImageUrl = null;
                slider.ModifyDate = DateTime.UtcNow;
                slider.ModifyUserId = userId;

                _unitOfWork.Repository.Update(slider);
                await _unitOfWork.SaveChanges();
            }
        }

        public async Task DeleteSlider(long Id, string userId)
        {
            var slider = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == Id);
            if (slider != null)
            {
                slider.DeleteDate = DateTime.UtcNow;
                slider.DeteleUserId = userId;
                slider.IsDeleted = true;
                slider.IsActive = false;

                _unitOfWork.Repository.Update(slider);
                await _unitOfWork.SaveChanges();
            }
        }

        public async Task EditSlider(SliderParameter parameter, string userId)
        {
            var slider = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == parameter.Id);
            if (slider != null)
            {
                slider.ImageUrl = parameter.ImageUrl;
                slider.ExternalLink = parameter.ExternalLink;
                slider.IsActive = parameter.IsActive;
                slider.ModifyDate = DateTime.UtcNow;
                slider.ModifyUserId = userId;
                slider.ClientId = parameter.ClientId;

                _unitOfWork.Repository.Update(slider);
                await _unitOfWork.SaveChanges();
            }
        }

        public async Task<SliderDto> GetSliderDetails(long Id)
        {
            var slider = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == Id);
            if (slider != null)
            {
                var model = Mapper.Map<SliderDto>(slider);
                return model;
            }

            return null;
        }

        public async Task<IRepositoryActionResult> GetSlidersApi(string userId)
        {
            var sliders = await _unitOfWork.Repository.Find(x => x.IsActive == true && x.IsDeleted != true);
            var models = Mapper.Map<List<SliderApiDto>>(sliders);
            foreach (var item in models)
            {
                if (item.ClientId != null)
                {
                    item.Client = await _clientsBusiness.GetFullDetails((long)item.ClientId, null, userId);
                }
            }
            return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }


        public async Task<List<SliderDto>> GetSliders()
        {
            var sliders = await _unitOfWork.Repository.Find(x => x.IsDeleted != true);
            var models = Mapper.Map<List<SliderDto>>(sliders);
            return models;
        }

    }
}
