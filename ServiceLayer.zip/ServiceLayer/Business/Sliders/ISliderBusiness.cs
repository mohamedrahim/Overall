﻿using HelperLayer.Dtos.SliderDto;
using HelperLayer.Parameters.SliderParameters;
using HelperLayer.Utilities;
using ServiceLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Sliders
{
    public interface ISliderBusiness : IBaseBusiness
    {
        Task<List<SliderDto>> GetSliders();
        Task<SliderDto> GetSliderDetails(long Id);
        Task AddSlider(SliderParameter parameter, string userId);
        Task EditSlider(SliderParameter parameter, string userId);
        Task DeleteSliderImage(long Id, string userId);
        Task DeleteSlider(long Id, string userId);
        Task<IRepositoryActionResult> GetSlidersApi(string userId);
    }
}
