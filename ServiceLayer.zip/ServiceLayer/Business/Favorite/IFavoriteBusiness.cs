﻿using HelperLayer.Utilities;
using ServiceLayer.Base;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Favorites
{
    public interface IFavoriteBusiness : IBaseBusiness
    {
        Task<IRepositoryActionResult> Add(long clientId, string userId);
        Task<IRepositoryActionResult> Delete(long Id);
        Task<IRepositoryActionResult> GetFavoriteApi(string userId, int pageNum = 0);
    }
}
