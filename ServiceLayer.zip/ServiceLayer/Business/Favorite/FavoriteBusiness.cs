﻿using DataLayer.Models.DB;
using HelperLayer.Dtos.Account;
using HelperLayer.Utilities;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.Base;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceLayer.Business.Favorites
{
    public class FavoriteBusiness : BusinessBase<Favorite>, IFavoriteBusiness
    {
        public FavoriteBusiness(IBusinessBaseParameter<Favorite> businessBaseParameter) : base(businessBaseParameter)
        {
        }

        public async Task<IRepositoryActionResult> Add(long clientId, string userId)
        {
            var favorite = await _unitOfWork.Repository.FirstOrDefault(x => x.ClientId == clientId && x.UserId == userId);
            if (favorite == null)
            {
                var model = new Favorite
                {
                    ClientId = clientId,
                    UserId = userId,
                };

                _unitOfWork.Repository.Add(model);
                await _unitOfWork.SaveChanges();
            }

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Created));
        }

        public async Task<IRepositoryActionResult> Delete(long Id)
        {
            var favorite = await _unitOfWork.Repository.FirstOrDefault(x => x.Id == Id);

            if (favorite == null)
            {
                return RepositoryActionResult.GetRepositoryActionResult(success: false, message: ResponseActionMessages.GetMesage(ResponseMessages.NotFound));
            }

            _unitOfWork.Repository.Remove(favorite);
            await _unitOfWork.SaveChanges();

            return RepositoryActionResult.GetRepositoryActionResult(success: true, message: ResponseActionMessages.GetMesage(ResponseMessages.Deleted));
        }

        public async Task<IRepositoryActionResult> GetFavoriteApi(string userId, int pageNum = 0)
        {
            int skip = (pageNum > 0 ? pageNum - 1 : 0) * 10;
            int pageCount = 10;

            var favorites = _unitOfWork.Repository.FindThenInclude(x => x.UserId == userId,
                include: x => x.Include(i => i.Client));

            var list = favorites.Skip(skip).Take(pageCount).ToList();

            var models = Mapper.Map<List<FavoriteDto>>(list);

            return RepositoryActionResult.GetRepositoryActionResult(success: true, models, message: ResponseActionMessages.GetMesage(ResponseMessages.DataRetrived));
        }

    }
}
