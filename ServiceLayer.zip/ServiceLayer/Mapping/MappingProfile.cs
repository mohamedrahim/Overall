﻿using AutoMapper;
using DataLayer.Models;
using DataLayer.Models.DB;
using HelperLayer.Dtos.Account;
using HelperLayer.Dtos.CategoryDtos;
using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Dtos.Clients;
using HelperLayer.Dtos.Faqs;
using HelperLayer.Dtos.Notifications;
using HelperLayer.Dtos.Settings;
using HelperLayer.Dtos.SliderDto;
using HelperLayer.Parameters.Account;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Parameters.Categories;
using HelperLayer.Parameters.CitiesAndArea;
using HelperLayer.Parameters.Faqs;
using HelperLayer.Parameters.Notifications;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Http;

namespace ServiceLayer.Mapping
{
    public class MappingProfile : Profile
    {
        private IHttpContextAccessor _httpContextAccessor;

        public MappingProfile(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;

            //slider
            CreateMap<Slider, SliderDto>();
            CreateMap<SliderDto, Slider>();

            //gender
            CreateMap<Gender, GenderDto>();
            CreateMap<GenderDto, Gender>();

            CreateMap<ClientGender, GenderDto>()
                  .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.GenderId))
                  .ForMember(dest => dest.NameEn, opt => opt.MapFrom(src => src.Gender.NameEn))
                  .ForMember(dest => dest.NameAr, opt => opt.MapFrom(src => src.Gender.NameAr));

            CreateMap<ClientLocation, LocationDto>()
                 .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.AreaId))
                 .ForMember(dest => dest.NameEn, opt => opt.MapFrom(src => src.Area.NameEn))
                 .ForMember(dest => dest.NameAr, opt => opt.MapFrom(src => src.Area.NameAr));

            CreateMap<Slider, SliderApiDto>()
                .ForMember(dest => dest.ImageUrl, opt => opt.MapFrom(src =>
                 string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                 _httpContextAccessor.HttpContext.Request.Host,
                 FileHelper.SliderFileUrl,
                 !string.IsNullOrEmpty(src.ImageUrl) ? src.ImageUrl : FileHelper.NoImageFileUrl)));

            CreateMap<UserDto, AppUser>();
            CreateMap<AppUser, UserDto>();

            CreateMap<City, CityVM>();
            CreateMap<CityVM, City>();

            CreateMap<City, CityDetails>();
            CreateMap<CityDetails, City>();

            CreateMap<City, CityBM>();
            CreateMap<CityBM, City>();

            CreateMap<Area, AreaVM>();
            CreateMap<AreaVM, Area>();
            CreateMap<Area, AreaDetails>();
            CreateMap<AreaDetails, Area>();

            CreateMap<Area, AreaBM>();
            CreateMap<AreaBM, Area>();

            CreateMap<UserDto, AppUser>();
            CreateMap<AppUser, UserDto>();

            CreateMap<UserDataVM, AppUser>();
            CreateMap<AppUser, UserDataVM>();

            CreateMap<UserDataBM, AppUser>();
            CreateMap<AppUser, UserDataBM>();

            CreateMap<ClientCategory, CategoryVM>();
            CreateMap<CategoryVM, ClientCategory>();

            CreateMap<ClientCategory, CategoryDetails>();
            CreateMap<CategoryDetails, ClientCategory>();

            CreateMap<ClientCategory, CategoryDetailsApi>()
                .ForMember(dest => dest.ImageUrl, opt => opt.MapFrom(src =>
                 string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                 _httpContextAccessor.HttpContext.Request.Host,
                 FileHelper.CategoryFileUrl,
                 !string.IsNullOrEmpty(src.ImageUrl) ? src.ImageUrl : FileHelper.NoImageFileUrl)));

            CreateMap<ClientCategory, PackageCategoryDto>();

            CreateMap<ClientCategory, ClientCategoryDto>();
            CreateMap<ClientCategoryDto, ClientCategory>();

            CreateMap<ClientCategory, CategoryBM>();
            CreateMap<CategoryBM, ClientCategory>();

            CreateMap<Client, ClientDto>();
            CreateMap<ClientDto, Client>();

            CreateMap<Client, ClientApiDto>()
                  .ForMember(dest => dest.Genders, opt => opt.MapFrom(src => src.ClientGenders))
                  .ForMember(dest => dest.Locations, opt => opt.MapFrom(src => src.ClientLocations))
                    .ForMember(dest => dest.LogoUrl, opt => opt.MapFrom(src =>
                     string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                     _httpContextAccessor.HttpContext.Request.Host,
                     FileHelper.ClientFileUrl,
                     !string.IsNullOrEmpty(src.LogoUrl) ? src.LogoUrl : FileHelper.NoImageFileUrl)))

                    .ForMember(dest => dest.CoverUrl, opt => opt.MapFrom(src =>
                     string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                     _httpContextAccessor.HttpContext.Request.Host,
                     FileHelper.ClientFileUrl,
                     !string.IsNullOrEmpty(src.CoverUrl) ? src.CoverUrl : FileHelper.NoImageFileUrl)));

            CreateMap<Info, InfoVM>();
            CreateMap<InfoVM, Info>();

            CreateMap<Package, PackageDto>();
            CreateMap<Package, PackageApiDto>();
            CreateMap<PackageDto, Package>();
            CreateMap<PackageApiDto, Package>();

            CreateMap<PeriodIndicator, PeriodIndicatorDto>();
            CreateMap<PeriodIndicatorDto, PeriodIndicator>();

            CreateMap<Subscription, SubscriptionApiDto>();

            CreateMap<Subscription, SubscriptionDto>();
            CreateMap<SubscriptionDto, Subscription>();

            CreateMap<PaymentMethod, PaymentMethodDto>()
                 .ForMember(dest => dest.ImageUrl, opt => opt.MapFrom(src =>
                 string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                 _httpContextAccessor.HttpContext.Request.Host,
                 FileHelper.PaymentFileUrl,
                 !string.IsNullOrEmpty(src.ImageUrl) ? src.ImageUrl : FileHelper.NoImageFileUrl)));

            CreateMap<PaymentMethodDto, PaymentMethod>();

            CreateMap<Address, AddressDto>();
            CreateMap<AddressDto, Address>();

            CreateMap<Notification, NotificationBM>();
            CreateMap<NotificationBM, Notification>();

            CreateMap<Notification, NotificationListVM>();
            CreateMap<NotificationListVM, Notification>();

            CreateMap<Notification, NotificationDetails>();
            CreateMap<NotificationDetails, Notification>();

            CreateMap<Faq, FaqBM>();
            CreateMap<FaqBM, Faq>();

            CreateMap<Faq, FaqVM>();
            CreateMap<FaqVM, Faq>();

            CreateMap<Faq, FaqDto>();
            CreateMap<FaqDto, Faq>();

            CreateMap<Favorite, FavoriteDto>();
            CreateMap<FavoriteDto, Favorite>();

            CreateMap<Info, AboutDetails>()
                .ForMember(dest => dest.LogoUrl, opt => opt.MapFrom(src =>
                 string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                 _httpContextAccessor.HttpContext.Request.Host,
                 FileHelper.SettingFileUrl,
                 !string.IsNullOrEmpty(src.LogoUrl) ? src.LogoUrl : FileHelper.NoImageFileUrl)));

            CreateMap<Info, TermsDetails>()
                .ForMember(dest => dest.LogoUrl, opt => opt.MapFrom(src =>
                 string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                 _httpContextAccessor.HttpContext.Request.Host,
                 FileHelper.SettingFileUrl,
                 !string.IsNullOrEmpty(src.LogoUrl) ? src.LogoUrl : FileHelper.NoImageFileUrl)));

            CreateMap<Info, PrivacyDetails>()
               .ForMember(dest => dest.LogoUrl, opt => opt.MapFrom(src =>
                string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                _httpContextAccessor.HttpContext.Request.Host,
                FileHelper.SettingFileUrl,
                !string.IsNullOrEmpty(src.LogoUrl) ? src.LogoUrl : FileHelper.NoImageFileUrl)));

            CreateMap<Info, ContactDetails>()
                .ForMember(dest => dest.LogoUrl, opt => opt.MapFrom(src =>
                 string.Concat(_httpContextAccessor.HttpContext.Request.IsHttps ? "https://" : "http://",
                 _httpContextAccessor.HttpContext.Request.Host,
                 FileHelper.SettingFileUrl,
                 !string.IsNullOrEmpty(src.LogoUrl) ? src.LogoUrl : FileHelper.NoImageFileUrl)));

            CreateMap<Info, AppDetails>();

            CreateMap<Contactus, ContactusParameters>();
            CreateMap<ContactusParameters, Contactus>()
                .ForMember(dest => dest.Subject, opt => opt.MapFrom(src => src.Name));


            CreateMap<DeviceTokenModel, DeviceToken>();
            CreateMap<DeviceToken, DeviceTokenModel>();
        }

    }
}
