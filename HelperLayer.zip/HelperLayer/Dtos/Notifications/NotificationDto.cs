﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Dtos.Notifications
{
    public class DeviceTokenModel
    {
        public long Id { get; set; }
        public string Token { get; set; }
        public string UserId { get; set; }
        public DateTime? Date { get; set; }
        public string DeviceId { get; set; }
        public int? Type { get; set; }
        public string Lang { get; set; }
    }

    public class NotificationListVM
    {
        public long Id { get; set; }
        public string TitleAr { get; set; }
        public string TitleEn { get; set; }
        public string MessageAr { get; set; }
        public string MessageEn { get; set; }
        public string Url { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
    }

    public class NotificationModel
    {
        public string TitleAr { get; set; } = string.Empty;
        public string TitleEn { get; set; } = string.Empty;
        public string MessageAr { get; set; } = string.Empty;
        public string MessageEn { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
        public int Type { get; set; }
        public long? ReferenceId { get; set; }
    }

    public class NotificationDetails
    {
        public Guid Id { get; set; }
        public string TitleAr { get; set; }
        public string TitleEn { get; set; }
        public string MessageAr { get; set; }
        public string MessageEn { get; set; }
        public string Url { get; set; }
        public bool? IsRead { get; set; }
        public string UserId { get; set; }
        public int Type { get; set; }
        public long? ReferenceId { get; set; }
        public DateTime? Date { get; set; }
    }

}
