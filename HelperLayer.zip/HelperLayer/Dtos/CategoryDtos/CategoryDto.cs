﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Dtos.CategoryDtos
{
    public class CategoryVM
    {
        public int Id { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string ImageUrl { get; set; }
        public bool IsActive { get; set; }
        public bool HasSubCategories { get; set; }
        public int? ParentCategoryId { get; set; }
        public string ModifyUserId { get; set; }
        public DateTime? ModifyDate { get; set; }
    }

    public class CategoryDetails
    {
        public int Id { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string ImageUrl { get; set; }
        public bool IsActive { get; set; }
        public bool HasSubCategories { get; set; }
        public int? ParentCategoryId { get; set; }
    }

    public class CategoryDetailsApi
    {
        public int Id { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string ImageUrl { get; set; }
        public bool IsActive { get; set; }
        public bool HasSubCategories { get; set; }
        public int? ParentCategoryId { get; set; }
    }

}
