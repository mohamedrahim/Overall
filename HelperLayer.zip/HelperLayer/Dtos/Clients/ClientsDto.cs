﻿using HelperLayer.Dtos.Account;
using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Dtos.Global;
using System;
using System.Collections.Generic;

namespace HelperLayer.Dtos.Clients
{
    public class ClientDto : BaseDto
    {
        public int CategoryId { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string DescriptionAr { get; set; }
        public string DescriptionEn { get; set; }
        public string Location { get; set; }
        public string Lat { get; set; }
        public string Lng { get; set; }
        public string LogoUrl { get; set; }
        public string CoverUrl { get; set; }
        public int Views { get; set; }
        public string UserId { get; set; }
        public string AddressAr { get; set; }
        public string AddressEn { get; set; }

        public virtual ClientCategoryDto ClientCategory { get; set; }
        public virtual UserDto User { get; set; }
    }

    public class ClientApiDto : BaseDto
    {
        public int CategoryId { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string DescriptionAr { get; set; }
        public string DescriptionEn { get; set; }
        public string Location { get; set; }
        public string Lat { get; set; }
        public string Lng { get; set; }
        public string LogoUrl { get; set; }
        public string CoverUrl { get; set; }
        public bool IsFavorite { get; set; }
        public int Views { get; set; }
        public string UserId { get; set; }
        public string AddressAr { get; set; }
        public string AddressEn { get; set; }

        public virtual List<PackageApiDto> Packages { get; set; }
        public virtual List<PackageCategoryDto> PackageType { get; set; }
        public virtual List<GenderDto> Genders { get; set; }
        public virtual List<LocationDto> Locations { get; set; }
        public virtual ClientCategoryDto ClientCategory { get; set; }
    }

    public class ClientCategoryDto
    {
        public int Id { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
        public string ImageUrl { get; set; }
        public bool IsActive { get; set; }
    }

    public class PackageCategoryDto
    {
        public int Id { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
    }

    public class PackageDto : BaseDto
    {
        public long ClientId { get; set; }
        public int CategoryId { get; set; }
        public int? SubCategoryId { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string DescriptionAr { get; set; }
        public string DescriptionEn { get; set; }
        public int? Duration { get; set; }
        public int? PeriodIndicatorId { get; set; }
        public int? Meals { get; set; }
        public int? Days { get; set; }
        public int? Sessions { get; set; }
        public double Price { get; set; }
        public double? OldPrice { get; set; }

        public virtual PeriodIndicatorDto PeriodIndicator { get; set; }
        public virtual ClientCategoryDto ClientCategory { get; set; }
        public virtual ClientDto Client { get; set; }
    }

    public class PackageApiDto : BaseDto
    {
        public long ClientId { get; set; }
        public int CategoryId { get; set; }
        public int? SubCategoryId { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string DescriptionAr { get; set; }
        public string DescriptionEn { get; set; }
        public int? Duration { get; set; }
        public int? PeriodIndicatorId { get; set; }
        public int? Meals { get; set; }
        public int? Days { get; set; }
        public int? Sessions { get; set; }
        public double Price { get; set; }
        public double? OldPrice { get; set; }

        public virtual PeriodIndicatorDto PeriodIndicator { get; set; }
    }


    public class SubscriptionDto : BaseDto
    {
        public long ClientId { get; set; }
        public long PackageId { get; set; }
        public long CategoryId { get; set; }
        public double? OldPrice { get; set; }
        public double Price { get; set; }
        public DateTime StartDate { get; set; }
        public long? AddressId { get; set; }
        public int PaymentMethodId { get; set; }
        public bool IsPaid { get; set; }
        public string TransactionId { get; set; }
        public int? Duration { get; set; }
        public int? PeriodIndicatorId { get; set; }
        public int? Meals { get; set; }
        public int? Days { get; set; }
        public int? Sessions { get; set; }
        public string UserId { get; set; }
        public string ResponseId { get; set; }
        public string Auth { get; set; }
        public string PaymentId { get; set; }
        public string RefId { get; set; }
        public string TrankId { get; set; }
        public string Gateway { get; set; }

        public virtual ClientCategoryDto ClientCategory { get; set; }
        public virtual ClientDto Client { get; set; }
        public virtual PackageDto Package { get; set; }
        public virtual AddressDto Address { get; set; }
        public virtual PaymentMethodDto PaymentMethod { get; set; }
        public virtual UserDto User { get; set; }
        public virtual PeriodIndicatorDto PeriodIndicator { get; set; }
    }

    public class SubscriptionApiDto : BaseDto
    {
        public long ClientId { get; set; }
        public long PackageId { get; set; }
        public long CategoryId { get; set; }
        public double Price { get; set; }
        public double? OldPrice { get; set; }
        public DateTime StartDate { get; set; }
        public long? AddressId { get; set; }
        public int PaymentMethodId { get; set; }
        public bool IsPaid { get; set; }
        public string TransactionId { get; set; }
        public int? Duration { get; set; }
        public int? PeriodIndicatorId { get; set; }
        public int? Meals { get; set; }
        public int? Days { get; set; }
        public int? Sessions { get; set; }
        public string UserId { get; set; }

        public virtual UserDto User { get; set; }
        public virtual ClientCategoryDto ClientCategory { get; set; }
        public virtual ClientApiDto Client { get; set; }
        public virtual PackageApiDto Package { get; set; }
        public virtual AddressDto Address { get; set; }
        public virtual PaymentMethodDto PaymentMethod { get; set; }
        public virtual PeriodIndicatorDto PeriodIndicator { get; set; }
    }

    public class PeriodIndicatorDto
    {
        public int Id { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
    }

    public class PaymentMethodDto
    {
        public int Id { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
        public string ImageUrl { get; set; }
    }

    public class GenderDto
    {
        public int Id { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
    }

    public class LocationDto
    {
        public long Id { get; set; }
        public string NameEn { get; set; }
        public string NameAr { get; set; }
    }

    public class AddressDto : BaseDto
    {
        public string AddressTitle { get; set; }
        public string BlockNo { get; set; }
        public string StreetName { get; set; }
        public string BuildNo { get; set; }
        public string Avenue { get; set; }
        public string FloorNo { get; set; }
        public string ApartmentNo { get; set; }
        public string AddressDetails { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public long CityId { get; set; }
        public long AreaId { get; set; }
        public string UserId { get; set; }
        public string full_address { get; set; }

        public virtual CityDetails City { get; set; }

        public virtual AreaDetails Area { get; set; }
    }

}
