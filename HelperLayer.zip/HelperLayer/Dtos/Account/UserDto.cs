﻿using HelperLayer.Dtos.Clients;
using System;

namespace HelperLayer.Dtos.Account
{
    public class FavoriteDto
    {
        public long Id { get; set; }
        public long ClientId { get; set; }
        public string UserId { get; set; }

        public virtual ClientApiDto Client { get; set; }
    }

    public class LoginOutputModel
    {
        public string Token { get; set; }
        public string Username { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string UserId { get; set; }
        public bool IsGuest { get; set; }
    }

    public class UserDto
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string UserName { get; set; }
        public DateTime? LastLogin { get; set; }
        public int Type { get; set; }
    }

    public class UserDataVM
    {
        public virtual bool PhoneNumberConfirmed { get; set; }
        public virtual string PhoneNumber { get; set; }
        public virtual bool EmailConfirmed { get; set; }
        public virtual string NormalizedEmail { get; set; }
        public virtual string Email { get; set; }
        public virtual string NormalizedUserName { get; set; }
        public virtual string UserName { get; set; }
        public virtual string Id { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Name { get; set; }
        public int Type { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? LastLogin { get; set; }
    }

}
