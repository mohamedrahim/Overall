﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Dtos.Account
{
    public class ContactusDto
    {
        public long Id { get; set; }
        public string Email { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public DateTime CreateDate { get; set; }
    }

    public class HomeDto
    {
        public long Clients { get; set; }
        public long Customers { get; set; }
        public long Packages { get; set; }
        public long PackageSubscriptions { get; set; }
    }

    public class ClientHomeDto
    {
        public long Packages { get; set; }
        public long PackageSubscriptions { get; set; }
    }

}
