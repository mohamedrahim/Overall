﻿namespace HelperLayer.Dtos.Settings
{
    public class InfoVM
    {
        public string Lock { get; set; }
        public string InstagramPageLink { get; set; }
        public string FacebookPageLink { get; set; }
        public string TwiterAccountLink { get; set; }
        public string WhatsAppLink { get; set; }
        public string LogoUrl { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string AboutAr { get; set; }
        public string AboutEn { get; set; }
        public string TermsAndConditionsAr { get; set; }
        public string TermsAndConditionsEn { get; set; }
        public string PrivacyAndPolicyAr { get; set; }
        public string PrivacyAndPolicyEn { get; set; }
        public string GooglePlay { get; set; }
        public string AppStore { get; set; }
        public string HomeTextAr { get; set; }
        public string HomeTextEn { get; set; }
        public int? IosVersion { get; set; }
        public int? AndroidVersion { get; set; }
    }

    public class AboutDetails
    {
        public string LogoUrl { get; set; }
        public string AboutAr { get; set; }
        public string AboutEn { get; set; }
    }

    public class AppDetails
    {
        public int AndroidVersion { get; set; }
        public int IosVersion { get; set; }
    }

    public class ContactDetails
    {
        public string InstagramPageLink { get; set; }
        public string FacebookPageLink { get; set; }
        public string TwiterAccountLink { get; set; }
        public string WhatsAppLink { get; set; }
        public string LogoUrl { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int AndroidVersion { get; set; }
        public int IosVersion { get; set; }
    }

    public class TermsDetails
    {
        public string LogoUrl { get; set; }
        public string TermsAndConditionsAr { get; set; }
        public string TermsAndConditionsEn { get; set; }
    }

    public class PrivacyDetails
    {
        public string LogoUrl { get; set; }
        public string PrivacyAndPolicyAr { get; set; }
        public string PrivacyAndPolicyEn { get; set; }
    }

}
