﻿using HelperLayer.Dtos.Clients;
using HelperLayer.Dtos.Global;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Dtos.SliderDto
{
    public class SliderDto : BaseDto
    {
        public string ImageUrl { get; set; }
        public long? ClientId { get; set; }
        public string ExternalLink { get; set; }
    }

    public class SliderApiDto
    {
        public long Id { get; set; }
        public string ImageUrl { get; set; }
        public long? ClientId { get; set; }
        public string ExternalLink { get; set; }
        public ClientApiDto Client { get; set; }
    }
}
