﻿using HelperLayer.Dtos.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Dtos.Global
{
    public class OutputModel<T>
    {
        public bool Success { get; set; }
        public int Code { get; set; }
        public T Item { get; set; }
    }

    public class BaseDto
    {
        public long Id { get; set; }
        public string CreateUserId { get; set; }
        public DateTime CreateDate { get; set; }
        public string ModifyUserId { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string DeteleUserId { get; set; }
        public DateTime? DeleteDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }

        public UserDto CreatedUser { get; set; }
        public UserDto ModifyUser { get; set; }
        public UserDto DeteleUser { get; set; }
    }

}
