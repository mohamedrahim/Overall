﻿using System;
using System.Collections.Generic;

namespace HelperLayer.Hesabe
{
    public class TokenResponse
    {
        public string access_token { get; set; }
        public string token_type { get; set; }
        public string expires_in { get; set; }
        public string userName { get; set; }
        public string issued { get; set; }
        public string expires { get; set; }
    }
    public class InvoiceItemsCreate
    {
        public int? ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public double UnitPrice { get; set; }
    }
    public class InvoiceItem
    {
        public string ProductName { get; set; }
        public string UnitPrice { get; set; }
        public string Quantity { get; set; }
        public string ExtendedAmount { get; set; }
    }
    public class TransactionResponse
    {
        public string InvoiceId { get; set; }
        public string InvoiceReference { get; set; }
        public string CreatedDate { get; set; }
        public string ExpireDate { get; set; }
        public decimal InvoiceValue { get; set; }
        public string Comments { get; set; }
        public string CustomerName { get; set; }
        public string CustomerMobile { get; set; }
        public string CustomerEmail { get; set; }
        public string TransactionDate { get; set; }
        public string PaymentGateway { get; set; }
        public string ReferenceId { get; set; }
        public string TrackId { get; set; }
        public string TransactionId { get; set; }
        public string PaymentId { get; set; }
        public string AuthorizationId { get; set; }
        public string OrderId { get; set; }
        public IList<InvoiceItem> InvoiceItems { get; set; }
        public int TransactionStatus { get; set; }
        public string Error { get; set; }
        public string PaidCurrency { get; set; }
        public string PaidCurrencyValue { get; set; }
        public string TransationValue { get; set; }
        public string CustomerServiceCharge { get; set; }
        public string DueValue { get; set; }
        public string Currency { get; set; }
    }
    public class InvoiceRequestISO
    {
        public double InvoiceValue { get; set; }
        public string CustomerName { get; set; }
        public string CustomerBlock { get; set; }
        public string CustomerStreet { get; set; }
        public string CustomerHouseBuildingNo { get; set; }
        public string CustomerCivilId { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerReference { get; set; }
        public string DisplayCurrencyIsoAlpha { get; set; }
        public int CountryCodeId { get; set; }
        public string CustomerMobile { get; set; }
        public string CustomerEmail { get; set; }
        public int SendInvoiceOption { get; set; }
        public IList<InvoiceItemsCreate> InvoiceItemsCreate { get; set; }
        public string CallBackUrl { get; set; }
        public int Language { get; set; }
        public DateTime ExpireDate { get; set; }
        public string ApiCustomFileds { get; set; }
        public string ErrorUrl { get; set; }
    }
    public class FieldsError
    {
        public string Name { get; set; }
        public string Error { get; set; }
    }
    public class PaymentMethod
    {
        public string PaymentMethodName { get; set; }
        public string PaymentMethodUrl { get; set; }
        public string PaymentMethodCode { get; set; }
    }
    public class InvoiceResponseISO
    {
        public int Id { get; set; }
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public string RedirectUrl { get; set; }
        public IList<FieldsError> FieldsErrors { get; set; }
        public IList<PaymentMethod> PaymentMethods { get; set; }
        public string ApiCustomFileds { get; set; }
    }
    public class HesabeAuthResponseISO
    {
        public string Status { get; set; }
        public string Message { get; set; }
        public ResponseData Data { get; set; }
    }
    public class ResponseData
    {
        public string Token { get; set; }
        public string paymenturl { get; set; }

    }
}
