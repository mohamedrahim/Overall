﻿namespace HelperLayer.Parameters.Accounts
{
    public class ContactusParameters
    {
        public string Email { get; set; }
        public string Name { get; set; }
        public string Message { get; set; }
    }
}
