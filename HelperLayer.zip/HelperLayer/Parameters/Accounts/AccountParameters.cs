﻿using System.ComponentModel.DataAnnotations;

namespace HelperLayer.Parameters.Accounts
{
    public class AddCustomerParameters
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        public string GuestUserId { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")]
        public string Email { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        [Required]
        public string Password { get; set; }
    }

    public class EditCustomerParameters
    {
        [Required]
        public string UserId { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")]
        public string Email { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
    }

    public class AddAddressParameters
    {
        [Required]
        public string AddressTitle { get; set; }
        public string BlockNo { get; set; }
        public string StreetName { get; set; }
        public string BuildNo { get; set; }
        public string Avenue { get; set; }
        public string FloorNo { get; set; }
        public string ApartmentNo { get; set; }
        //[Required]
        public string AddressDetails { get; set; }
        public string Mobile { get; set; }
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")]
        public string Email { get; set; }
        [Required]
        public long CityId { get; set; }
        [Required]
        public long AreaId { get; set; }
    }

    public class UpdateAddressParameters
    {
        [Required]
        public long Id { get; set; }
        [Required]
        public string AddressTitle { get; set; }
        public string BlockNo { get; set; }
        public string StreetName { get; set; }
        public string BuildNo { get; set; }
        public string Avenue { get; set; }
        public string FloorNo { get; set; }
        public string ApartmentNo { get; set; }
        [Required]
        public string AddressDetails { get; set; }
        public string Mobile { get; set; }
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")]
        public string Email { get; set; }
        [Required]
        public long CityId { get; set; }
        [Required]
        public long AreaId { get; set; }
    }

    public class AddClientToFavoriteParameters
    {
        [Required]
        public long ClientId { get; set; }
    }

    public class ResetPasswordModel
    {
        [Required]
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")]
        public string email { get; set; }
        [Required]
        public string Code { get; set; }
    }

    public class SetPasswordModel
    {
        [Required]
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")]
        public string email { get; set; }
        [Required]
        public string code { get; set; }
        [Required]
        [MinLength(6)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
    }


}
