﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HelperLayer.Parameters.Account
{
    public class LoginParameter
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public bool RememberMe { get; set; }
    }

    public class ChangePasswordParameter
    {
        [Required]
        public string UserId { get; set; }
        [Required]
        public string OldPassword { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
    }

    public class RolesModel
    {
        public string UserId { get; set; }
        public IEnumerable<string> userRoles { get; set; }
        public List<RolesDto> Roles { get; set; }
    }

    public class RolesDto
    {
        public string Id { get; set; }
        public string Name { get; set; }

    }

    public class UserDataBM
    {
        public virtual string Id { get; set; }
        //[Required]
        //[Remote("Admin_PhoneCheck", "Account", AdditionalFields = "Id", ErrorMessage = "Phone Number Already Exist")]
        public virtual string PhoneNumber { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        [Remote("Admin_EmailCheck", "Account", AdditionalFields = "Id", ErrorMessage = "Email Address Already Exist")]
        public virtual string Email { get; set; }
        [Required]
        [Remote("Admin_UsernameCheck", "Account", AdditionalFields = "Id", ErrorMessage = "username Already Exist")]
        public virtual string UserName { get; set; }
        public bool IsAdd { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public virtual string PasswordHash { get; set; }
        public byte Type { get; set; }
        public bool IsActive { get; set; }
    }

    public class AddUserRoles
    {
        [Required]
        public string UserId { get; set; }
        public string[] Roles { get; set; }
    }

    public class LoginModel
    {
        [Required]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public string GuestUserId { get; set; }
    }

    public class GuestRefreshToken
    {
        [Required]
        public string UserId { get; set; }
    }

    public class LogoutParameters
    {
        [Required]
        public string UserId { get; set; }
        [Required]
        public string DeviceId { get; set; }
    }

    public class ResetPasswordParameters
    {
        [Required]
        public string Email { get; set; }
    }

    public class GuestRegister
    {
        [Required]
        public string Language { get; set; }
    }

    public class ChangePasswordModel
    {
        [Required]
        public string OldPassword { get; set; }
        [Required]
        public string NewPassword { get; set; }
    }

}
