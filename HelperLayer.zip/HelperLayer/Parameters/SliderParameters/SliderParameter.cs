﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Parameters.SliderParameters
{
    public class SliderParameter
    {
        public long Id { get; set; }
        public long? ClientId { get; set; }
        public string ImageUrl { get; set; }
        public string ExternalLink { get; set; }
        public bool IsActive { get; set; }
    }
}
