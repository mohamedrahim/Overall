﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HelperLayer.Parameters.Clients
{
    public class AddClientParameters
    {
        public long Id { get; set; }
        [Required]
        public string NameAr { get; set; }
        [Required]
        public string NameEn { get; set; }
        [Required]
        public string DescriptionAr { get; set; }
        [Required]
        public string DescriptionEn { get; set; }
        [Required]
        public string Location { get; set; }
        [Required]
        public string Lat { get; set; }
        [Required]
        public string Lng { get; set; }
        public string LogoUrl { get; set; }
        public string CoverUrl { get; set; }
        [Required]
        public int CategoryId { get; set; }
        public string AddressAr { get; set; }
        public string AddressEn { get; set; }
        public string UserId { get; set; }
        public bool IsActive { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        public long[] LocationIds { get; set; }
        public int[] GenderIds { get; set; }

    }

    public class AddPackageParameters
    {
        public long Id { get; set; }
        [Required]
        public long ClientId { get; set; }
        [Required]
        public int CategoryId { get; set; }
        public int? SubCategoryId { get; set; }
        [Required]
        public string NameAr { get; set; }
        [Required]
        public string NameEn { get; set; }
        [Required]
        public string DescriptionAr { get; set; }
        [Required]
        public string DescriptionEn { get; set; }
        public int? Duration { get; set; }
        public int? PeriodIndicatorId { get; set; }
        public int? Meals { get; set; }
        public int? RecoverySessions { get; set; }
        public int? CoachDays { get; set; }
        public int? CoachSessions { get; set; }
        public int? CenterDays { get; set; }
        [Required]
        public double Price { get; set; }
        public double? OldPrice { get; set; }
        [Required]
        public bool IsActive { get; set; }
    }

    public class SubscribePackageParameters
    {
        [Required]
        public long ClientId { get; set; }
        [Required]
        public long PackageId { get; set; }
        [Required]
        public int PaymentMethodId { get; set; }
        public int? AddressId { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
    }

}
