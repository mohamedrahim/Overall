﻿using FluentValidation;
using HelperLayer.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Parameters.Clients
{
    public class PackageValidator : AbstractValidator<AddPackageParameters>
    {
        public PackageValidator()
        {
            RuleFor(x => x.PeriodIndicatorId).NotNull().When(x => x.CategoryId == (int)CategoryEnum.Gym);
            RuleFor(x => x.PeriodIndicatorId).NotEqual(0).When(x => x.CategoryId == (int)CategoryEnum.Gym);

            RuleFor(x => x.Duration).NotNull().When(x => x.CategoryId == (int)CategoryEnum.Gym);
            RuleFor(x => x.Duration).NotEqual(0).When(x => x.CategoryId == (int)CategoryEnum.Gym);

            RuleFor(x => x.RecoverySessions).NotNull().When(x => x.CategoryId == (int)CategoryEnum.RecoveryCenter);
            RuleFor(x => x.RecoverySessions).NotEqual(0).When(x => x.CategoryId == (int)CategoryEnum.RecoveryCenter);

            RuleFor(x => x.Meals).NotNull().When(x => x.CategoryId == (int)CategoryEnum.DietitianCenter);
            RuleFor(x => x.Meals).NotEqual(0).When(x => x.CategoryId == (int)CategoryEnum.DietitianCenter);

            RuleFor(x => x.CenterDays).NotNull().When(x => x.CategoryId == (int)CategoryEnum.DietitianCenter);
            RuleFor(x => x.CenterDays).NotEqual(0).When(x => x.CategoryId == (int)CategoryEnum.DietitianCenter);

            RuleFor(x => x.CoachSessions).NotNull().When(x => x.CategoryId == (int)CategoryEnum.Coache);
            RuleFor(x => x.CoachSessions).NotEqual(0).When(x => x.CategoryId == (int)CategoryEnum.Coache);

            RuleFor(x => x.CoachDays).NotNull().When(x => x.CategoryId == (int)CategoryEnum.Coache);
            RuleFor(x => x.CoachDays).NotEqual(0).When(x => x.CategoryId == (int)CategoryEnum.Coache);
        }
    }

}
