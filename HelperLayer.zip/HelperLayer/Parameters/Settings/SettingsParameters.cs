﻿using System.ComponentModel.DataAnnotations;

namespace HelperLayer.Parameters.Settings
{
    public class AboutBM
    {
        public string Lock { get; set; }
        [Required]
        public string AboutAr { get; set; }
        [Required]
        public string AboutEn { get; set; }
    }

    public class HomeBM
    {
        public string Lock { get; set; }

        //[Required]
        public string HomeTextAr { get; set; }
        //[Required]
        public string HomeTextEn { get; set; }
        [Required]
        public string InstagramPageLink { get; set; }
        [Required]
        public string FacebookPageLink { get; set; }
        [Required]
        public string TwiterAccountLink { get; set; }
        [Required]
        public string WhatsAppLink { get; set; }
    }

    public class InfoBM
    {
        public string Lock { get; set; }
        [Required]
        public string GooglePlay { get; set; }
        [Required]
        public string AppStore { get; set; }
        public string LogoUrl { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Phone { get; set; }
        [Required]
        public int? IosVersion { get; set; }
        [Required]
        public int? AndroidVersion { get; set; }
        [Required]
        public string HomeTextAr { get; set; }
        [Required]
        public string HomeTextEn { get; set; }
    }

    public class TermsAndConditionsBM
    {
        public string Lock { get; set; }
        [Required]
        public string TermsAndConditionsAr { get; set; }
        [Required]
        public string TermsAndConditionsEn { get; set; }
    }

    public class PrivacyAndPolicyBM
    {
        public string Lock { get; set; }
        [Required]
        public string PrivacyAndPolicyAr { get; set; }
        [Required]
        public string PrivacyAndPolicyEn { get; set; }
    }

}
