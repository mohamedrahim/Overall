﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Parameters.Notifications
{
    public class NotificationBM
    {
        [Required]
        public string TitleAr { get; set; }
        [Required]
        public string TitleEn { get; set; }
        [Required]
        public string Message { get; set; }
        [Required]
        public string MessageEn { get; set; }
        public string Url { get; set; }
    }

    public class TokenModel
    {
        [Required]
        public string Token { get; set; }
        [Required]
        public string DeviceId { get; set; }
        [Required]
        [Range(1, 2)]
        public int Type { get; set; }
        [Required]
        public string Lang { get; set; }
    }

}
