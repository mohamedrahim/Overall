﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelperLayer.Parameters.Categories
{
    public class CategoryBM
    {
        public int Id { get; set; }
        [Required]
        public string NameAr { get; set; }
        [Required]
        public string NameEn { get; set; }
        public string ImageUrl { get; set; }
        public bool IsActive { get; set; }
        public bool HasSubCategories { get; set; }
        public int? ParentCategoryId { get; set; }
    }
}
