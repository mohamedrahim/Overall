﻿using System;

namespace HelperLayer.Utilities
{
    public class RepositoryActionResult : RepositoryResult, IRepositoryActionResult
    {
        public Exception Exception { get; }
        public RepositoryActionResult(bool success = false, object result = null, Exception exception = null, string message = null)
        {
            Data = result;
            Exception = exception;
            Message = message;
            Success = success;
        }

        public IRepositoryActionResult GetRepositoryActionResult(bool success, object result = null, Exception exception = null, string message = null)
        {
            return new RepositoryActionResult(success: success, result: result, exception: exception, message: message);
        }
    }
}
