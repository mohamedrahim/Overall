﻿using System;

namespace HelperLayer.Utilities
{
    public interface IRepositoryActionResult : IRepositoryResult
    {
        Exception Exception { get; }
        IRepositoryActionResult GetRepositoryActionResult(bool success, object result = null, Exception exception = null, string message = null);
    }
}
