﻿using Business.Services.SettingsSer;
using System;
using System.Net;
using System.Net.Mail;

namespace HelperLayer.Utilities
{
    public class EmailService
    {
        public static bool SendUserConfirmEmail(IAppSettings settings, string to, string Subject, string Body, string url)
        {
            try
            {
                string message = $@"<table style='text-align: center;width: 100%;background: #f1f1f1;padding: 20px;'>
                                <tbody><tr>
                                    <td>
                                            <table style='direction:ltr;max-width: 650px;margin:0 auto;background-color:#ffffff;border-spacing:0;font-size: 16px;border-radius: 20px;padding: 1rem;'><tbody><tr>
                                                <td style='text-align:center'>
                                                    <img src='{url}' style='height:100px;width:auto' alt='logo' class='CToWUd'>
                                                </td>
                                                </tr><tr>
                                                 <td align='center' style='padding-bottom: 1rem;font-size: 24px;'>
                                                    <strong>Confirm your email address</strong>
                                                  </td>
                                                </tr><tr>
                                                <td align='center'>
                                                To confirm your email address, click the button below. <br>The link will self-destruct after one hour.
                                                </td>
                                                </tr><tr>
                                                <td align='center' style='padding: 20px;'>
                                                <table align='center' style='margin:0 auto;' cellpadding='0' cellspacing='0'>
                                                     <tbody><tr>
                                                    <td align='center'>{Body}
                                                </td>
                                              </tr>
                                            </tbody></table>
                                          </td>
                                        </tr><tr>
                                          <td align='center' style=' padding-bottom: 2rem;font-size: 14px; color: #585858;'>
                                          Did you receive this email without signup?<br> this verification link will expire after one hour.</td>
                                      </tr><tr>
                                        <td colspan='2' style='text-align:center;border-top: solid 1px #ddd;padding-top: 14px;'>
                                        <span style='color: #000000;'>Best Regards</span><font color='#888888' style='/* color: #ddd; */'><br>
                                        <span style='color: #d1a976;text-transform: uppercase;letter-spacing: 6px;'>Overall</span></font></td></tr></tbody></table>
                                    </td>
                                    </tr>
                                </tbody></table>";

                var fromAddress = new MailAddress(settings.SenderEmail, "Overall");
                MailMessage mail = new MailMessage();
                mail.From = fromAddress;
                mail.To.Add(new MailAddress(to));

                mail.Subject = Subject;
                mail.Body = message;
                mail.IsBodyHtml = true;

                mail.Priority = MailPriority.High;

                using (SmtpClient smtp = new SmtpClient())
                {
                    smtp.UseDefaultCredentials = false;
                    smtp.Host = settings.SMTPServer;
                    smtp.Port = settings.SMTPPort;
                    smtp.EnableSsl = settings.EnableSSL;
                    smtp.Credentials = new NetworkCredential(settings.SenderEmail, settings.SenderPassword);
                    smtp.Send(mail);
                }
                return true;
            }
            catch (Exception ex)
            {
                LogHelper.LogException(ex);
                return false;
            }
        }

        public static bool SendUserForgetPassword(IAppSettings settings, string to, string Subject, string Body, string url)
        {
            try
            {
                string message = $@"<table style='text-align: center;width: 100%;background: #f1f1f1;padding: 20px;'>
                                <tbody><tr>
                                    <td>
                                         <table style='direction:ltr;max-width: 650px;margin:0 auto;background-color:#ffffff;border-spacing:0;font-size: 16px;border-radius: 20px;padding: 1rem;'><tbody><tr>
                                                <td style='text-align:center'>
                                                    <img src='{url}' style='height:100px;width:auto' alt='logo' class='CToWUd'>
                                                </td>
                                                </tr><tr>
                                                 <td align='center' style='padding-bottom: 1rem;font-size: 24px;'>
                                                    <strong>Forgot your password? <br>It happens to the best of us.</strong>
                                                  </td>
                                                </tr><tr>
                                                <td align='center'>
                                                To reset your password, click the button below. <br>The link will self-destruct after two hours.
                                                </td>
                                                </tr><tr>
                                                <td align='center' style='padding: 20px;'>
                                                <table align='center' style='margin:0 auto;' cellpadding='0' cellspacing='0'>
                                                     <tbody><tr>
                                                    <td align='center'>{Body}
                                                </td>
                                              </tr>
                                            </tbody></table>
                                          </td>
                                        </tr><tr>
                                          <td align='center' style=' padding-bottom: 2rem;font-size: 14px; color: #585858;'>
                                          If you do not want to change your password or didn't request a reset,<br> You can ignore and delete this email.</td>
                                      </tr><tr>
                                        <td colspan='2' style='text-align:center;border-top: solid 1px #ddd;padding-top: 14px;'>
                                        <span style='color: #000000;'>Best Regards</span><font color='#888888' style='/* color: #ddd; */'><br>
                                        <span style='color: #d1a976;text-transform: uppercase;letter-spacing: 6px;'>Overall</span></font></td></tr></tbody></table>
                                    </td>
                                    </tr>
                                </tbody></table>";

                var fromAddress = new MailAddress(settings.SenderEmail, "Overall");
                MailMessage mail = new MailMessage();
                mail.From = fromAddress;
                mail.To.Add(new MailAddress(to));

                mail.Subject = Subject;
                mail.Body = message;
                mail.IsBodyHtml = true;

                mail.Priority = MailPriority.High;

                using (SmtpClient smtp = new SmtpClient())
                {
                    smtp.UseDefaultCredentials = false;
                    smtp.Host = settings.SMTPServer;
                    smtp.Port = settings.SMTPPort;
                    smtp.EnableSsl = settings.EnableSSL;
                    smtp.Credentials = new NetworkCredential(settings.SenderEmail, settings.SenderPassword);
                    smtp.Send(mail);
                }
                return true;
            }
            catch (Exception ex)
            {
                LogHelper.LogException(ex);
                return false;
            }
        }

    }
}
