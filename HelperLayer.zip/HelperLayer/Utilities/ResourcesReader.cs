﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace HelperLayer.Utilities
{
    public class ResourcesReader
    {
        public static bool IsArabic
        {
            get; set;
        }
    }

}
