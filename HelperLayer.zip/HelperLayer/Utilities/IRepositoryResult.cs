﻿using System.Net;
namespace HelperLayer.Utilities
{
    public interface IRepositoryResult
    {
        object Data { get; set; }
        string Message { get; set; }
        bool Success { get; set; }
    }
}
