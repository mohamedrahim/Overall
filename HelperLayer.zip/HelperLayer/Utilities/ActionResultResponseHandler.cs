﻿using System;
using System.Net;

namespace HelperLayer.Utilities
{
    public class ActionResultResponseHandler : IActionResultResponseHandler
    {
        private readonly IRepositoryResult _repositoryResult;

        public ActionResultResponseHandler(IRepositoryResult repositoryResult)
        {
            _repositoryResult = repositoryResult;
        }

        public IRepositoryResult GetResult(IRepositoryActionResult repositoryActionResult)
        {
            _repositoryResult.Success = repositoryActionResult.Success;
            _repositoryResult.Message = repositoryActionResult.Message;
           
            if (!HasError(repositoryActionResult.Exception))
            {
                _repositoryResult.Data = repositoryActionResult.Data;
            }

            return _repositoryResult;
        }

        private bool HasError(Exception exception)
        {
            return exception != null;
        }
    }
}
