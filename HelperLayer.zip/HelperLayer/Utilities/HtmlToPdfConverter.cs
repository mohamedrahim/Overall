﻿using HelperLayer.Dtos.Clients;
using Microsoft.AspNetCore.Mvc;
using SelectPdf;
using System;
using System.IO;

namespace HelperLayer.Utilities
{
    public interface IHtmlToPdfConverter
    {
        FileStreamResult PdfCnverter(string TxtHtmlCode);

        string OrderInvoiceHtml(SubscriptionDto order, string url);

    }

    public class HtmlToPdfConverter : IHtmlToPdfConverter
    {
        public string OrderInvoiceHtml(SubscriptionDto order, string url)
        {
            string serv = "Total Paid to " + order.Client.NameEn;
            int i = 0;

            string body = @"<section style='margin: 40px 0; font-family: Arial, Helvetica, sans-serif; '><div id ='print'style='-webkit-print-color-adjust: exact;'>" +
                         "<div style ='border: solid 1px #000000;overflow: hidden;border-radius:10px;background-color: #FFF;padding: 20px;margin-bottom: 20px;width: 90%;margin: auto;'>" +
                         "<div style ='text-align: center;margin-bottom: 40px;'>  <img style ='width: auto;height: 65px;' alt='Logo' src='" + url + "icon.png" + @"'>" +
                         "</div> <div style='overflow: hidden;'><div style='float: left;width: 49.5%;margin-bottom: 20px;margin-left: 0.5%;'>" +
                         "<p style ='color: #B5B5B5;margin-top: 0;margin-bottom: 0;'> Transaction-id:<span style=' color: #d0a977;font-weight: 600;' > " +
                         order.TransactionId + " </span></p></div><div style='float: left;width: 49.5%;text-align: right;margin-bottom: 20px;margin-" +
                         "right: 0.5%;'><span style='color: #B5B5B5;font-size: 18px;direction:ltr;'>" + order.CreateDate.ToString("dd/MM/yyyy hh:mm tt") + "</span>" +
                         "</div></div><div style= 'background-color: #F6F6F6 !important;padding: 20px;border-radius: 10px;margin-bottom: 20px;overflow: hidden;' >" +
                         "<ul style='list-style: none;padding: 0;margin: 0;'>" +
                         "<li style='float: left;width: 33%;text-align: left;font-weight: 600;color: #d0a977;margin-bottom: 10px;'><span style='color:" +
                         " #797979;font-weight: lighter;display: block;margin-bottom: 5px;'> Name: </span><p style='margin-bottom: 0;'>" +
                         order.User.FirstName + " " + order.User.LastName + "</p> </li><li style='float: left;width: 33%;text-align: left;font-weight: 600;color: #d0a977;margin-bottom:" +
                         " 10px;' ><span style='color: #797979;font-weight: lighter;display: block;margin-bottom: 5px;' > Email: </span><p " +
                         "style='margin-bottom: 0;'>" + order.User.Email + "</p></li><li style='float: left;width: 33%;text-align: left;font-weight: 600;color:" +
                         " #d0a977;margin-bottom: 10px;' > <span style=' color: #797979;font-weight: lighter;display: block;margin-bottom: 5px;' >" +
                         " UserName: </span><p style ='margin-bottom: 0;' >" + order.User.UserName + "</p></li></ul></div>";

            body += "<div style='overflow: hidden;' >" +
             "<div style='float: left;width: 49.5%;margin-left: 0.5%;' >" +
             "<p style='margin-bottom: 0;color: #000;' > " +
             " <span style='font-weight: 600;color: #d0a977;'> " + serv + "</span>" +
             "</p>" +
             "</div>" +
             "<div style='float: left;width: 49.5%;margin-right: 0.5%;text-align: right;'>" +
             "<p style='margin-bottom: 0;color: #000;' > " +
             "<span style='font-weight: 600;color: #d0a977;'> "
                   + order.Price.ToString("#.000") + " KWD" +
            "</span>" +
            "</p>" +
            "</div>" +
            "</div>" +

            "</div></div></section>";
            return body;
        }

        public FileStreamResult PdfCnverter(string TxtHtmlCode)
        {
            // read parameters from the webpage
            PdfPageSize pageSize = (PdfPageSize)Enum.Parse(typeof(PdfPageSize),
                "A4", true);

            PdfPageOrientation pdfOrientation =
                (PdfPageOrientation)Enum.Parse(typeof(PdfPageOrientation),
                "Portrait", true);


            // instantiate a html to pdf converter object
            HtmlToPdf converter = new HtmlToPdf();

            // set converter options
            converter.Options.PdfPageSize = pageSize;
            converter.Options.PdfPageOrientation = pdfOrientation;

            // create a new pdf document converting an url
            PdfDocument doc = converter.ConvertHtmlString(TxtHtmlCode);

            // create memory stream to save PDF
            MemoryStream pdfStream = new MemoryStream();

            // save pdf document into a MemoryStream
            doc.Save(pdfStream);

            // reset stream position
            pdfStream.Position = 0;

            // return resulted pdf document
            FileStreamResult fileResult = new FileStreamResult(pdfStream, "application/pdf");
            fileResult.FileDownloadName = "Document.pdf";

            return fileResult;
        }

    }

}
