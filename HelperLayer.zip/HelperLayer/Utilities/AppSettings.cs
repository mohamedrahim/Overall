﻿using Microsoft.Extensions.Configuration;
using System;

namespace Business.Services.SettingsSer
{
    public class AppSettings : IAppSettings
    {
        public IConfiguration Configuration { get; set; }

        public AppSettings(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Gets or sets Google app ID
        /// </summary>
        public string GoogleAppID
        {
            get
            {
                return Configuration["GoogleAppID"];
            }
        }
        public string SenderID
        {
            get
            {
                return Configuration["SenderID"];
            }
        }

        public string BundleId
        {
            get
            {
                return Configuration["BundleId"];
            }
        }

        public string KeyId
        {
            get
            {
                return Configuration["KeyId"];
            }
        }

        public string TeamId
        {
            get
            {
                return Configuration["TeamId"];
            }
        }

        public string P8FilePath
        {
            get
            {
                return Configuration["P8FilePath"];
            }
        }

        public bool Sandbox
        {
            get
            {
                return Convert.ToBoolean(Configuration["Sandbox"]);
            }
        }

        public bool PrintResult
        {
            get
            {
                return Convert.ToBoolean(Configuration["PrintResult"]);
            }
        }

        public int AndroidNotificationType
        {
            get
            {
                return Convert.ToInt32(Configuration["AndroidNotificationType"]);
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether Sender Email
        /// </summary>
        public string SenderEmail
        {
            get
            {
                return Configuration["Email:SenderEmail"];
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether Sender Password
        /// </summary>
        public string SenderPassword
        {
            get
            {
                return Configuration["Email:SenderPassword"];
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether SMTP Server
        /// </summary>
        public string SMTPServer
        {
            get
            {
                return Configuration["Email:SMTPServer"];
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether SMTP Port
        /// </summary>
        public int SMTPPort
        {
            get
            {
                return int.Parse(Configuration["Email:SMTPPort"]);
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether Enable SSL
        /// </summary>
        public bool EnableSSL
        {
            get
            {
                return bool.Parse(Configuration["Email:EnablSSL"]);
            }
        }

        public string Qpay_GatewayId
        {
            get
            {
                return Configuration["QPay:GatewayId"];
            }
        }

        public string Qpay_SecretKey
        {
            get
            {
                return Configuration["QPay:SecretKey"];
            }
        }

        public string Qpay_Url
        {
            get
            {
                return Configuration["QPay:Url"];
            }
        }

        public string Qpay_Mode
        {
            get
            {
                return Configuration["QPay:Mode"];
            }
        }

        public string Qpay_Response_Url
        {
            get
            {
                return Configuration["QPay:Response_Url"];
            }
        }

        public string BaseUrl
        {
            get
            {
                return Configuration["BaseUrl"];
            }
        }

        public int ProductionState
        {
            get
            {
                return int.Parse(Configuration["ProductionState"]);
            }
        }

        public string Originator
        {
            get
            {
                return Configuration["SMS:Originator"];
            }
        }

        public string CustomerId
        {
            get
            {
                return Configuration["SMS:CustomerId"];
            }
        }

        public string UserName
        {
            get
            {
                return Configuration["SMS:UserName"];
            }
        }

        public string Password
        {
            get
            {
                return Configuration["SMS:Password"];
            }
        }

        public string SmsUrl
        {
            get
            {
                return Configuration["SMS:SmsUrl"];
            }
        }

        public string Hesabe_merchant_Url
        {
            get
            {
                return Configuration["Hesabe:merchant_Url"];
            }
        }

        public string Hesabe_access_code
        {
            get
            {
                return Configuration["Hesabe:access_code"];
            }
        }

        public string Hesabe_merchant_code
        {
            get
            {
                return Configuration["Hesabe:merchant_code"];
            }
        }

        public string Hesabe_merchant_key
        {
            get
            {
                return Configuration["Hesabe:merchant_key"];
            }
        }

        public string Hesabe_merchant_iv
        {
            get
            {
                return Configuration["Hesabe:merchant_iv"];
            }
        }

        public string Hesabe_merchant_return_url
        {
            get
            {
                return Configuration["Hesabe:merchant_return_url"];
            }
        }

        public string Hesabe_merchant_error_url
        {
            get
            {
                return Configuration["Hesabe:merchant_error_url"];
            }
        }

    }
}
