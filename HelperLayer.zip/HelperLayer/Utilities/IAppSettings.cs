﻿namespace Business.Services.SettingsSer
{
    public interface IAppSettings
    {
        string SenderEmail { get; }
        string SenderPassword { get; }
        string SMTPServer { get; }
        int SMTPPort { get; }
        bool EnableSSL { get; }

        string SenderID { get; }
        string GoogleAppID { get; }
        string BundleId { get; }
        string KeyId { get; }
        string TeamId { get; }
        string P8FilePath { get; }
        bool Sandbox { get; }
        bool PrintResult { get; }
        int AndroidNotificationType { get; }

        string BaseUrl { get; }
        int ProductionState { get; }

        string Hesabe_merchant_Url { get; }
        string Hesabe_access_code { get; }
        string Hesabe_merchant_code { get; }
        string Hesabe_merchant_key { get; }
        string Hesabe_merchant_iv { get; }
        string Hesabe_merchant_return_url { get; }
        string Hesabe_merchant_error_url { get; }
    }
}
