﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace HelperLayer.Utilities
{
    public class FileHelper
    {
        public static string CategoryFileUrl = "/Files/Category/";
        public static string ClientFileUrl = "/Files/Client/";
        public static string SliderFileUrl = "/Files/Slider/";
        public static string NoImageFileUrl = "NoImage.png";
        public static string SettingFileUrl = "/Files/Settings/";
        public static string NotificationFileUrl = "/Files/Notification/";
        public static string PaymentFileUrl = "/Files/Payment/";
        public static string BaseFileUrl = "/Images/";

        public static string[] Extensions = new string[] { ".tiff", ".pjp", ".pjpeg", ".jfif", ".tif", ".gif", ".bmp", ".png", ".jpeg", ".jpg", ".webp", ".ico", ".xbm", ".dib" };
        public static string[] VideoExtensions = new string[] { ".mp4" };
        public static string[] FileExtensions = new string[] { ".pdf" };

        public static async Task<string> SaveFile(IFormFile file, IHostingEnvironment _env, string imagePath)
        {
            if (file != null && file.Length > 0)
            {
                var webRoot = _env.WebRootPath;
                var uploadsFolder = Path.Combine(webRoot, imagePath);
                if (!Directory.Exists(uploadsFolder)) { Directory.CreateDirectory(uploadsFolder); }

                var extension = Path.GetExtension(file.FileName);
                var fileName = Guid.NewGuid() + extension;
                string filePath = Path.Combine(uploadsFolder, fileName);

                using (var fileSteam = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(fileSteam);
                }
                return fileName;
            }
            return "";
        }

        public static bool CheckImageExtension(IFormFile file)
        {
            var extension = Path.GetExtension(file.FileName);
            if (Extensions.Contains(extension.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool CheckVideoExtension(IFormFile file)
        {
            var extension = Path.GetExtension(file.FileName);
            if (VideoExtensions.Contains(extension.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool CheckFileExtension(IFormFile file)
        {
            var extension = Path.GetExtension(file.FileName);
            if (FileExtensions.Contains(extension.ToLower()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void DeleteFile(string url)
        {
            if (File.Exists(url))
            {
                File.Delete(url);
            }
        }

    }
}
