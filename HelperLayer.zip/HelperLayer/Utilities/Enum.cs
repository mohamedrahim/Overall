﻿namespace HelperLayer.Utilities
{
    public enum UserTypes
    {
        Admin = 1,
        Client = 2,
        Customer = 3
    }
    public enum PaymentStatus
    {
        Paid = 1,
        NotPaid = 2
    }

    public enum PeriodIndicatior
    {
        Days = 1,
        Weeks = 2,
        Months = 3
    }

    public enum DeviceType
    {
        IPhone = 1,
        Android = 2
    }

    public enum PaymentMethodEnum
    {
        Knet = 1,
        Visa = 2,
        Mastercard = 3
    }

    public enum NotificationEnum
    {
        GeneralNotification = 1,
    }

    public enum CategoryEnum
    {
        Gym = 1,
        RecoveryCenter = 2,
        DietitianCenter = 3,
        Coache = 4,
    }

    public enum ResponseMessages
    {
        Created = 1,
        Updated = 2,
        NotFound = 3,
        Deleted = 4,
        Error = 5,
        ValidationError = 6,
        UserNotFound = 7,
        InvalidEmail = 8,
        DataRetrived = 9,
        PasswordValidLength = 10,
        EmailExist = 11,
        WrongPassword = 12,
        UnAuthorized = 13,
        WrongUserNameOrPassword = 14,
        RecoveryEmail = 15,
        MobileExist = 16
    }

    public enum SortByEnum
    {
        Name = 1,
        Date = 2,
        LowToHighPrices = 3,
        HighToLowPrices = 4
    }

}
