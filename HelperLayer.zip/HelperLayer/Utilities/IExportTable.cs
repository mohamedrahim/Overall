﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace HelperLayer.Utilities
{
    public interface IExportTable
    {
        string ExportData(DataTable result, string fileName);
        string ExportDataWithoutHeader(DataTable result, string fileName);
        string ActulePath(string fileName, out string filePath);
        string ExportDataWithManySheets(List<ExportDto> result, string fileName);
    }

    public class ExportDto
    {
        public DataTable Table { get; set; }
        public string Name { get; set; }
    }
    public class ExportTable : IExportTable
    {
        private readonly IHostingEnvironment _hostingEnvironment;

        public ExportTable(IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }

        public virtual string ExportData(DataTable result, string fileName)
        {
            string filePath;
            using (SpreadsheetDocument ssdocument = SpreadsheetDocument.Create(ActulePath(fileName, out filePath), SpreadsheetDocumentType.Workbook))
            {
                CreateExcelDocument(ssdocument, result);
            }
            return filePath;
        }
        public virtual string ExportDataWithoutHeader(DataTable result, string fileName)
        {
            string filePath;
            using (SpreadsheetDocument ssdocument = SpreadsheetDocument.Create(ActulePath(fileName, out filePath), SpreadsheetDocumentType.Workbook))
            {
                CreateExcelDocument(ssdocument, result, true);
            }
            return filePath;
        }
        public virtual string ExportDataWithManySheets(List<ExportDto> result, string fileName)
        {
            string filePath;
            using (SpreadsheetDocument ssdocument = SpreadsheetDocument.Create(ActulePath(fileName, out filePath), SpreadsheetDocumentType.Workbook))
            {
                CreateExcelDocument(ssdocument, result);
            }
            return filePath;
        }
        public string ActulePath(string fileName, out string filePath)
        {
            var path = _hostingEnvironment.WebRootPath;
            var uploadsFolder = Path.Combine(path, "ExportedFiles");
            if (!Directory.Exists(uploadsFolder)) { Directory.CreateDirectory(uploadsFolder); }

            filePath = "ExportedFiles" + "/" + fileName + " ( " + DateTime.Now.ToString().Replace('/', '-').Replace(':', '-') + " ).xlsx";
            return path + "/" + filePath;
        }
        /// <summary>
        /// Create a basic spreadsheet template 
        /// The structure of OpenXML spreadsheet is something like this from what I can tell:
        ///                        Spreadsheet
        ///                              |         
        ///                         WorkbookPart    
        ///                   /         |             \
        ///           Workbook WorkbookStylesPart WorksheetPart
        ///                 |          |               |
        ///            Sheets     StyleSheet        Worksheet
        ///                |                        /        \       
        ///          (refers to               SheetData        Columns  
        ///           Worksheetparts)            |   
        ///                                     Rows 
        /// 
        /// Obviously this only covers the bits in this class!
        /// </summary>
        /// <returns></returns>
        public virtual void CreateExcelDocument(SpreadsheetDocument document, DataTable result, bool without = false, bool isManySheets = false)
        {
            WorkbookPart workbookPart = document.AddWorkbookPart();
            WorksheetPart worksheetPart = workbookPart.AddNewPart<WorksheetPart>("export");
            GenerateWorkbookPartContent(workbookPart, document, worksheetPart);
            if (without)
            {
                GenerateWorksheetPartContentWithoutHeader(worksheetPart, result);
            }
            else
            {
                GenerateWorksheetPartContent(worksheetPart, result);
            }
        }
        public virtual void CreateExcelDocument(SpreadsheetDocument ssdocument, List<ExportDto> results)
        {
            WorkbookPart workbookPart = ssdocument.AddWorkbookPart();
            //WorksheetPart wsp = wbp.AddNewPart<WorksheetPart>(); // Add worksheet part
            Workbook wb = new Workbook(); // Workbook
            FileVersion fv = new FileVersion();
            fv.ApplicationName = "Wibble Wobble";
            Worksheet ws = new Worksheet(); // Worksheet
            SheetData sd = new SheetData(); // Data on worksheet
                                            // Add stylesheet
                                            // WorkbookStylesPart stylesPart = ssdocument.WorkbookPart.AddNewPart<WorkbookStylesPart>();
                                            //  stylesPart.Stylesheet = GenerateStyleSheet();
                                            //  stylesPart.Stylesheet.Save();
            ws.Append(sd); // Add sheet data to worksheet
            ssdocument.WorkbookPart.Workbook = wb;
            ssdocument.WorkbookPart.Workbook.Save();
            //GenerateWorkbookPartContentMS(workbookPart);
            foreach (var item in results)
            {
                // string partId = GenerateWorkbookPartWorkbookSheets(workbookPart, document, worksheetPart, workbook, sheets,"test"+ i);
                GenerateWorksheetPartContentWithoutHeaderMS(ssdocument, workbookPart, item.Name, item.Table);
            }
        }

        public virtual void GenerateWorkbookPartContent(WorkbookPart workbookPart, SpreadsheetDocument document, WorksheetPart worksheetPart)
        {
            Workbook workbook = new Workbook();
            Sheets sheets = new Sheets();
            Sheet sheet = new Sheet()
            {
                Name = "sheet 1",
                SheetId = (UInt32Value)1U,
                Id = document.WorkbookPart.GetIdOfPart(worksheetPart)
            };
            sheets.Append(sheet);
            workbook.Append(sheets);
            workbookPart.Workbook = workbook;
            workbookPart.Workbook.Save();
        }
        public virtual string GenerateWorkbookPartWorkbookSheets(WorkbookPart workbookPart, SpreadsheetDocument document, WorksheetPart wsp, Workbook workbook, Sheets sheets, string sheetName)
        {
            // WorksheetPart wsp = document.WorkbookPart.AddNewPart<WorksheetPart>();
            wsp.Worksheet = new Worksheet();
            wsp.Worksheet.AppendChild(new SheetData());
            wsp.Worksheet.Save();
            //  Workbook workbook = new Workbook();
            // Sheets sheets = new Sheets();
            // workbookPart.Workbook = workbook;
            UInt32 sheetId;
            // If this is the first sheet, the ID will be 1. If this is not the first sheet, we calculate the ID based on the number of existing
            // sheets + 1.
            if (document.WorkbookPart.Workbook.Sheets == null)
            {
                document.WorkbookPart.Workbook.AppendChild(new Sheets());
                sheetId = 1;
            }
            else
            {
                sheetId = Convert.ToUInt32(document.WorkbookPart.Workbook.Sheets.Count() + 1);
            }
            Sheet sheet = new Sheet()
            {
                Name = sheetName,
                SheetId = sheetId,
                Id = workbookPart.GetIdOfPart(wsp)
            };


            //UInt32 sheetId;
            //// If this is the first sheet, the ID will be 1. If this is not the first sheet, we calculate the ID based on the number of existing
            //// sheets + 1.
            //if (document.WorkbookPart.Workbook.Sheets == null)
            //{
            //    document.WorkbookPart.Workbook.AppendChild(new Sheets());
            //    sheetId = 1;
            //}
            //else
            //{
            //    sheetId = Convert.ToUInt32(document.WorkbookPart.Workbook.Sheets.Count() + 1);
            //}

            //// Create the new sheet and add it to the workbookpart
            //var sheet = new Sheet()
            //{
            //    Id = document.WorkbookPart.GetIdOfPart(wsp),
            //    SheetId = sheetId,
            //    Name = Name
            //};
            //document.WorkbookPart.Workbook.GetFirstChild<Sheets>().AppendChild(sheet );
            //_cols = new Columns(); // Created to allow bespoke width columns
            //// Save our changes

            //return spreadSheet.WorkbookPart.GetIdOfPart(wsp);// wsp;


            //////////////////////

            sheets.Append(sheet);
            //workbook.Append(sheets);
            workbookPart.Workbook.Save();
            document.WorkbookPart.Workbook.Save();
            return sheet.Id;
        }
        public virtual void GenerateWorkbookPartContentMS(WorkbookPart workbookPart)
        {
            Workbook workbook = new Workbook();
            Sheets sheets = new Sheets();
            workbookPart.Workbook = workbook;
            //UInt32 sheetId;
            // If this is the first sheet, the ID will be 1. If this is not the first sheet, we calculate the ID based on the number of existing
            // sheets + 1.
            //if (document.WorkbookPart.Workbook.Sheets == null)
            //{
            //document.WorkbookPart.Workbook.AppendChild(new Sheets());
            // sheetId = 1;
            //}
            //else
            //{
            //    sheetId = Convert.ToUInt32(document.WorkbookPart.Workbook.Sheets.Count() + 1);
            //}
            //Sheet sheet = new Sheet()
            //{
            //    Name = sheetName,
            //    SheetId = sheetId,
            //    Id = document.WorkbookPart.GetIdOfPart(worksheetPart)
            //};
            //  sheets.Append(sheet);
            workbook.Append(sheets);

            workbookPart.Workbook.Save();
        }
        public virtual void GenerateWorksheetPartContent(WorksheetPart worksheetPart, DataTable dataTable)
        {
            Worksheet worksheet = new Worksheet();
            SheetData sheetdata = new SheetData();
            string[] headerColumns = dataTable.Columns.Cast<DataColumn>()
                                 .Select(x => x.ColumnName)
                                 .ToArray();  // GetColumnHeaders(result.Rows[0].GetType());
            Row row = new Row();
            Cell cell = new Cell();
            int RowIndexer = 1;
            int ColumnIndexer = 1;
            row.RowIndex = (UInt32)RowIndexer;
            foreach (var header in headerColumns)
            {
                cell = new Cell();
                cell.CellReference = ColumnAddress(ColumnIndexer) + RowIndexer;
                cell.DataType = CellValues.InlineString;
                cell.InlineString = new InlineString(new Text(header));

                row.AppendChild(cell);
                ColumnIndexer++;
            }
            sheetdata.Append(row);
            RowIndexer = 2;
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                row = new Row();
                row.RowIndex = (UInt32)RowIndexer;
                ColumnIndexer = 1;
                for (int c = 0; c < dataTable.Columns.Count; c++)
                {
                    cell = new Cell();
                    cell.CellReference = ColumnAddress(ColumnIndexer) + RowIndexer;
                    object value = dataTable.Rows[i][c]; // GenericApiUtility.GetPropertyValue(item, header);

                    //int type = (int)ParseString(value.ToString());

                    //if (type == (int)dataType.type_number)
                    //{
                    //    if (value.ToString().Length <= 11)
                    //    {
                    //        cell.DataType = CellValues.Number;
                    //        cell.CellValue = new CellValue(value.ToString());
                    //    }
                    //    else
                    //    {
                    //        cell.DataType = CellValues.InlineString;
                    //        cell.InlineString = new InlineString(new Text(value.ToString()));
                    //    }
                    //}
                    //else
                    //{
                    cell.DataType = CellValues.InlineString;
                    if (value != null)
                    {
                        cell.InlineString = new InlineString(new Text(value.ToString()));
                    }
                    //   }

                    //cell.DataType = CellValues.InlineString;// GetCellDataType(value);
                    //if (value != null)
                    //{
                    //    cell.InlineString = new InlineString(new Text(value.ToString()));
                    //}
                    row.AppendChild(cell);
                    ColumnIndexer++;
                }
                RowIndexer++;
                sheetdata.Append(row);
            }

            worksheet.Append(sheetdata);
            worksheetPart.Worksheet = worksheet;
        }

        public virtual void GenerateWorksheetPartContentWithoutHeaderMS(SpreadsheetDocument ssdocument, WorkbookPart workbookPart2, string sheetName, DataTable dataTable)
        {
            WorksheetPart wsp = ssdocument.WorkbookPart.AddNewPart<WorksheetPart>();

            // workbook.Append(sheets);
            Worksheet worksheet = new Worksheet();
            SheetData sheetdata = new SheetData();
            Row row = new Row();
            Cell cell = new Cell();
            int RowIndexer = 1;
            int ColumnIndexer = 1;
            row.RowIndex = (UInt32)RowIndexer;
            RowIndexer = 2;
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                row = new Row();
                row.RowIndex = (UInt32)RowIndexer;
                ColumnIndexer = 1;
                for (int c = 0; c < dataTable.Columns.Count; c++)
                {
                    cell = new Cell();
                    cell.CellReference = ColumnAddress(ColumnIndexer) + RowIndexer;
                    object value = dataTable.Rows[i][c];

                    //int type = (int)ParseString(value.ToString());

                    //if (type == (int)dataType.type_number)
                    //{
                    //    if (value.ToString().Length <= 11)
                    //    {
                    //        cell.DataType = CellValues.Number;
                    //        cell.CellValue = new CellValue(value.ToString());
                    //    }
                    //    else
                    //    {
                    //        cell.DataType = CellValues.InlineString;
                    //        cell.InlineString = new InlineString(new Text(value.ToString()));
                    //    }
                    //}
                    //else
                    //{
                    cell.DataType = CellValues.InlineString;
                    if (value != null)
                    {
                        cell.InlineString = new InlineString(new Text(value.ToString()));
                    }
                    //    }

                    row.AppendChild(cell);
                    ColumnIndexer++;
                }
                RowIndexer++;
                sheetdata.Append(row);
            }
            worksheet.Append(sheetdata);
            // var wsp = (WorksheetPart)worksheetPart.GetPartById(workbookPart.GetIdOfPart(wsp));
            //   wsp.Worksheet =


            wsp.Worksheet = worksheet;//new Worksheet();
                                      //  wsp.Worksheet.AppendChild(sheetdata);//new SheetData()
            wsp.Worksheet.Save();
            UInt32 sheetId;
            // If this is the first sheet, the ID will be 1. If this is not the first sheet, we calculate the ID based on the number of existing
            // sheets + 1.
            if (ssdocument.WorkbookPart.Workbook.Sheets == null)
            {
                ssdocument.WorkbookPart.Workbook.AppendChild(new Sheets());
                sheetId = 1;
            }
            else
            {
                sheetId = Convert.ToUInt32(ssdocument.WorkbookPart.Workbook.Sheets.Count() + 1);
            }
            Sheet sheet = new Sheet()
            {
                Name = sheetName,
                SheetId = sheetId,
                Id = ssdocument.WorkbookPart.GetIdOfPart(wsp)
            };
            ssdocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().AppendChild(sheet);
            //  _cols = new Columns(); // Created to allow bespoke width columns
            // Save our changes
            ssdocument.WorkbookPart.Workbook.Save();
            //  return ssdocument.WorkbookPart.GetIdOfPart(wsp);// wsp;
        }
        public virtual void GenerateWorksheetPartContentWithoutHeader(WorksheetPart worksheetPart, DataTable dataTable)
        {
            Worksheet worksheet = new Worksheet();
            SheetData sheetdata = new SheetData();
            Row row = new Row();
            Cell cell = new Cell();
            int RowIndexer = 0;
            int ColumnIndexer = 1;
            row.RowIndex = (UInt32)RowIndexer;
            RowIndexer = 1;
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                row = new Row();
                row.RowIndex = (UInt32)RowIndexer;
                ColumnIndexer = 1;
                for (int c = 0; c < dataTable.Columns.Count; c++)
                {
                    cell = new Cell();
                    cell.CellReference = ColumnAddress(ColumnIndexer) + RowIndexer;
                    object value = dataTable.Rows[i][c];

                    //int type = (int)ParseString(value.ToString());

                    //if (type == (int)dataType.type_number)
                    //{
                    //    if (value.ToString().Length <= 11)
                    //    {
                    //        cell.DataType = CellValues.Number;
                    //        cell.CellValue = new CellValue(value.ToString());
                    //    }
                    //    else
                    //    {
                    //        cell.DataType = CellValues.InlineString;
                    //        cell.InlineString = new InlineString(new Text(value.ToString()));
                    //    }
                    //}
                    //else
                    //{
                    cell.DataType = CellValues.InlineString;
                    if (value != null)
                    {
                        cell.InlineString = new InlineString(new Text(value.ToString()));
                    }
                    // }

                    //cell.DataType = CellValues.InlineString;
                    //if (value != null)
                    //{
                    //    cell.InlineString = new InlineString(new Text(value.ToString()));
                    //}

                    row.AppendChild(cell);
                    ColumnIndexer++;
                }
                RowIndexer++;
                sheetdata.Append(row);
            }

            worksheet.Append(sheetdata);
            worksheetPart.Worksheet = worksheet;
        }
        private EnumValue<CellValues> GetCellDataType(object value)
        {
            return CellValues.InlineString;

        }

        private string[] GetColumnHeaders(Type type)
        {
            return type.GetProperties().Where(pi => pi.PropertyType.Namespace == "System").Select(pi => pi.Name).ToArray();
        }

        string ColumnAddress(int index)
        {
            index -= 1; //adjust so it matches 0-indexed array rather than 1-indexed column
            int quotient = index / 26;
            if (quotient > 0)
                return ColumnAddress(quotient) + chars[index % 26].ToString();
            else
                return chars[index % 26].ToString();
        }
        private char[] chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();

        private dataType ParseString(string str)
        {
            Int32 intValue;
            Int64 bigintValue;
            double doubleValue;

            if (Int32.TryParse(str, out intValue))
                return dataType.type_number;
            else if (Int64.TryParse(str, out bigintValue))
                return dataType.type_number;
            else if (double.TryParse(str, out doubleValue))
                return dataType.type_number;
            else return dataType.type_string;
        }

    }

    public enum dataType
    {
        type_number = 1,
        type_date = 2,
        type_string = 3
    }

}
