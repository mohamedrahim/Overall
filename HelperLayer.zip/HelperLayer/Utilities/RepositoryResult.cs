﻿using System.Net;
namespace HelperLayer.Utilities
{
    public class RepositoryResult : IRepositoryResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }
    }
}
