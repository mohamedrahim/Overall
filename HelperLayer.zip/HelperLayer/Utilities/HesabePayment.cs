﻿using Business.Services.SettingsSer;
using HelperLayer.Dtos.Clients;
using HelperLayer.Hesabe;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelperLayer.Utilities
{
    public interface IHesabePaymentV2
    {
        Task<HesabeCheckoutResponse> CreateInvoiceISO_hesabe(PackageDto package, string baselinke, string rf);
    }

    public class HesabePaymentV2 : IHesabePaymentV2
    {

        private readonly IAppSettings _appSettings;
        public HesabePaymentV2(IAppSettings appSettings)
        {
            _appSettings = appSettings;
        }

        public async Task<HesabeCheckoutResponse> CreateInvoiceISO_hesabe(PackageDto package, string baseLinke, string rf)
        {
            var invoiceItems = new List<InvoiceItemsCreate>();
            var url = _appSettings.Hesabe_merchant_Url + "/checkout";

            // Initialize the HesabeCrypt encryption/decryption library using the KEY and IV from the configuration
            var hesabeCrypt = new HesabeCrypt(_appSettings.Hesabe_merchant_key, _appSettings.Hesabe_merchant_iv);

            InvoiceItemsCreate invoiceItem = new InvoiceItemsCreate
            {
                ProductId = null,
                ProductName = package.NameEn,
                Quantity = 1,
                UnitPrice = package.Price
            };

            invoiceItems.Add(invoiceItem);

            //invoiceItems.Add(new InvoiceItemsCreate()
            //{
            //    ProductId = null,
            //    ProductName = "Delivery",
            //    Quantity = 1,
            //    UnitPrice = order.DeliveryFees
            //});

            var totalInvoiceAmount = invoiceItems.Sum(x => x.Quantity * x.UnitPrice);

            HesabeCheckoutData paymentData = new HesabeCheckoutData
            {
                Amount = totalInvoiceAmount,
                MerchantCode = _appSettings.Hesabe_merchant_code,
                FailureUrl = string.Concat(baseLinke, _appSettings.Hesabe_merchant_error_url),
                PaymentType = 0,
                ResponseUrl = string.Concat(baseLinke, _appSettings.Hesabe_merchant_return_url),
                Version = "2.0",
                OrderReferenceNumber = rf
            };

            // Serialize the payment data into JSON string
            var paymentDataJsonSerialized = JsonConvert.SerializeObject(paymentData);

            // Encrypt the JSON Serialized string
            var encryptedPaymentData = hesabeCrypt.Encrypt(paymentDataJsonSerialized);

            // POST the serialized string to the checkout API and recieve back the reponse
            var checkoutApiEncryptedResponse = await HesabeApiHelper.PostCheckoutApi(encryptedPaymentData, url, _appSettings.Hesabe_access_code);

            // Decrypt the response from the checkout API
            var checkoutApiDecryptedResponse = hesabeCrypt.Decrypt(checkoutApiEncryptedResponse);

            // Deserialize the JSON string into an object
            var checkoutApiResponse = JsonConvert.DeserializeObject<HesabeCheckoutResponse>(checkoutApiDecryptedResponse);

            return checkoutApiResponse;
        }

    }
}