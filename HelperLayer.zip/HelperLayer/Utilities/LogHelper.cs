﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace HelperLayer.Utilities
{
    public class LogHelper
    {
        public static void LogException(Exception ex)
        {
            try
            {
                var webRoot = Directory.GetCurrentDirectory();
                var filePath = Path.Combine(webRoot, "wwwroot/log/log_ex.txt");
                FileStream fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("");
                sw.WriteLine("Exception Time :   " + DateTime.Now.ToString("d/M/yyyy hh:mm"));
                sw.WriteLine("");
                sw.WriteLine("Exception Message :   ");
                sw.WriteLine(ex.Message);
                sw.WriteLine("");
                sw.WriteLine("Exception InnerException :   ");
                sw.WriteLine(ex.InnerException);
                sw.WriteLine("");
                sw.WriteLine("Exception StackTrace :   ");
                sw.WriteLine(ex.StackTrace);
                sw.WriteLine("");
                sw.WriteLine("ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ");
                sw.Close();
                sw.Dispose();
                fs.Close();
                fs.Dispose();
            }
            catch
            {
            }
        }

        public static void LogString(string token)
        {
            try
            {
                var webRoot = Directory.GetCurrentDirectory();
                var filePath = Path.Combine(webRoot, "wwwroot/log/log_str.txt");
                FileStream fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("");
                sw.WriteLine(token);
                sw.WriteLine("ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ");
                sw.Close();
                sw.Dispose();
                fs.Close();
                fs.Dispose();
            }
            catch
            {
            }
        }

        public static void LogPushInfo(string message)
        {
            try
            {
                var webRoot = Directory.GetCurrentDirectory();
                var filePath = Path.Combine(webRoot, "wwwroot/log/log_push.txt");
                FileStream fs = new FileStream(filePath, FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("");
                sw.WriteLine("Push Time :   " + DateTime.Now.ToString("d/M/yyyy hh:mm"));
                sw.WriteLine("");
                sw.WriteLine("Push Message :   ");
                sw.WriteLine(message);
                sw.WriteLine("");
                sw.WriteLine("ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ");
                sw.Close();
                sw.Dispose();
                fs.Close();
                fs.Dispose();
            }
            catch
            {
            }
        }

    }
}
