﻿namespace HelperLayer.Utilities
{
    public static class ResponseActionMessages
    {
        public static string GetMesage(ResponseMessages msg)
        {
            if (msg == ResponseMessages.Created) return Created;
            else if (msg == ResponseMessages.Updated) return Updated;
            else if (msg == ResponseMessages.NotFound) return NotFound;
            else if (msg == ResponseMessages.Deleted) return Deleted;
            else if (msg == ResponseMessages.Error) return Error;
            else if (msg == ResponseMessages.DataRetrived) return DataRetrived;
            else if (msg == ResponseMessages.EmailExist) return EmailExist;
            else if (msg == ResponseMessages.PasswordValidLength) return PasswordValidLength;
            else if (msg == ResponseMessages.WrongPassword) return WrongPassword;
            else if (msg == ResponseMessages.UnAuthorized) return UnAuthorized;
            else if (msg == ResponseMessages.UserNotFound) return UserNotFound;
            else if (msg == ResponseMessages.WrongUserNameOrPassword) return WrongUserNameOrPassword;
            else if (msg == ResponseMessages.RecoveryEmail) return RecoveryEmail;
            else if (msg == ResponseMessages.MobileExist) return MobileExist;
            else if (msg == ResponseMessages.ValidationError) return ValidationError;

            return " no message matched";

        }

        public static string DataRetrived { get { return !ResourcesReader.IsArabic ? "" : ""; } }
        public static string Created { get { return !ResourcesReader.IsArabic ? "Data saved successfully" : "تم حفظ البيانات بنجاح"; } }
        public static string Updated { get { return !ResourcesReader.IsArabic ? "Data updated successfully" : "تم تعديل البيانات بنجاح"; } }
        public static string NotFound { get { return !ResourcesReader.IsArabic ? "No data found" : "لا توجد بيانات"; } }
        public static string Deleted { get { return !ResourcesReader.IsArabic ? "Deleted successfully" : "تم الحذف بنجاح"; } }
        public static string Error { get { return !ResourcesReader.IsArabic ? "An error occured please try again later!" : "حدث خطاء برجاء المحاوله في وقت لاحق"; } }
        public static string ValidationError { get { return !ResourcesReader.IsArabic ? "All fileds required!" : "رجاء ملئ كل الحقول المطلوبه"; } }
        public static string EmailExist { get { return !ResourcesReader.IsArabic ? "This email address already exists!" : "البريد الاليكتروني مستخدم بالفعل"; } }
        public static string MobileExist { get { return !ResourcesReader.IsArabic ? "This phone number already exists!" : "الهاتف مستخدم بالفعل"; } }
        public static string PasswordValidLength { get { return !ResourcesReader.IsArabic ? "Invalid password length!" : "يجب ادخال كلمة مرور صالحه"; } }
        public static string WrongPassword { get { return !ResourcesReader.IsArabic ? "Wrong password!" : "كلمة المرور غير صحيحه"; } }
        public static string UnAuthorized { get { return !ResourcesReader.IsArabic ? "UnAuthorized Access!" : "غير مسموح لك بالدخول!"; } }
        public static string UserNotFound { get { return !ResourcesReader.IsArabic ? "No such user exists. Please check details and try again." : "لايوجد مستخدم بهذا البريد، من فضلك راجع البيانات وحاول مجددا"; } }
        public static string WrongUserNameOrPassword { get { return !ResourcesReader.IsArabic ? "Wrong Email/Password!" : "البريد الالكتروني او كلمة المرور غير صحيحة!"; } }
        public static string RecoveryEmail { get { return !ResourcesReader.IsArabic ? "Please check your inbox!" : "يمكنك فحص بريدك الاليكتروني!"; } }

    }
}
