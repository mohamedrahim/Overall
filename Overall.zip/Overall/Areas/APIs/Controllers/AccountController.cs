﻿using Business.Services.UserSer;
using DataLayer.Extensions;
using HelperLayer.Dtos.Account;
using HelperLayer.Parameters.Account;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace Overall.Areas.Apis.Controllers
{
    public class AccountController : BaseController
    {
        IUserBusiness _userService;

        public AccountController(IActionResultResponseHandler responseHandler,
            IConfiguration configuration,
            IUserBusiness userService) : base(responseHandler, configuration)
        {
            _userService = userService;
        }

        /// <summary>
        /// Guest Register
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Guest/Register")]
        [ProducesResponseType(typeof(LoginOutputModel), 200)]
        public async Task<IRepositoryResult> GuestRegister()
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _userService.GuestRegister();
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// Login
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Login")]
        [ProducesResponseType(typeof(LoginOutputModel), 200)]
        public async Task<IRepositoryResult> Login([FromBody] LoginModel loginModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _userService.Login(loginModel);
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// Create customer account
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Register")]
        [AllowAnonymous]
        [ProducesResponseType(typeof(LoginOutputModel), 200)]
        public async Task<IRepositoryResult> Register([FromBody] AddCustomerParameters model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _userService.CreateAccount(model);
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }


        /// <summary>
        /// customer details
        /// </summary>
        /// <remarks></remarks>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet]
        [Route("Details")]
        [ProducesResponseType(typeof(UserDto), 200)]
        public async Task<IRepositoryResult> Details()
        {
            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_userService.UnAuthorized());
                }

                if (ModelState.IsValid)
                {
                    var result = await _userService.AccountDetails(User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// edit customer account
        /// </summary>
        /// <remarks></remarks>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost]
        [Route("EditProfile")]
        public async Task<IRepositoryResult> EditProfile([FromBody] EditCustomerParameters model)
        {
            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_userService.UnAuthorized());
                }

                if (ModelState.IsValid)
                {
                    var result = await _userService.EditAccount(model, User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// change account password
        /// </summary>
        /// <remarks></remarks>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost]
        [Route("ChangePassword")]
        public async Task<IRepositoryResult> ChangePassword([FromBody] ChangePasswordModel model)
        {
            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_userService.UnAuthorized());
                }

                if (ModelState.IsValid)
                {
                    var result = await _userService.ChangePassword(model, User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// logout
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Logout")]
        public async Task<IRepositoryResult> Logout([FromBody] LogoutParameters model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _userService.LogOut(model);
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// reset account password
        /// </summary>
        /// <remarks></remarks>
        [AllowAnonymous]
        [HttpPost]
        [Route("ResetPassword")]
        public async Task<IRepositoryResult> ResetPassword([FromBody] ResetPasswordParameters parameters)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string baseUr = string.Concat(HttpContext.Request.IsHttps ? "https://" : "http://", HttpContext.Request.Host);
                    var result = await _userService.ResetPassword(parameters, baseUr);
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// Delete user
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Delete")]
        public async Task<IRepositoryResult> Delete([FromBody] LogoutParameters model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _userService.Delete(model);
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

    }
}