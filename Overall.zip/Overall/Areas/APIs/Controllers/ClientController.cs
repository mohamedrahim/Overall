﻿using DataLayer.Extensions;
using HelperLayer.Dtos.Clients;
using HelperLayer.Parameters.Clients;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ServiceLayer.Business.Clients;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Overall.Areas.Apis.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ClientController : BaseController
    {
        IClientsBusiness _clientsBusiness;
        private readonly IHostingEnvironment _env;
        public string _filePath = "Files/Payment";
        IHtmlToPdfConverter _htmlToPdfConverter;

        public ClientController(IClientsBusiness clientsBusiness,
            IActionResultResponseHandler responseHandler,
            IHostingEnvironment env,
            IHtmlToPdfConverter htmlToPdfConverter,
            IConfiguration configuration) : base(responseHandler, configuration)
        {
            _clientsBusiness = clientsBusiness;
            _htmlToPdfConverter = htmlToPdfConverter;
            _env = env;
        }

        /// <summary>
        /// clients list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("List")]
        [ProducesResponseType(typeof(List<ClientApiDto>), 200)]
        public async Task<IRepositoryResult> List(int? categoryId, string searchKey, string genders, string locations, int? sortBy, double? priceFrom, double? priceTo, int? packageTypeId, int pageNum = 0)
        {
            try
            {
                var userId = User.GetUserId();

                var result = await _clientsBusiness.GetClientsApi(categoryId, searchKey, genders, locations, sortBy, priceFrom, priceTo, userId, packageTypeId, pageNum);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_clientsBusiness.ServerError());
            }
        }

        /// <summary>
        /// clients list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Details/{id}")]
        [ProducesResponseType(typeof(ClientApiDto), 200)]
        public async Task<IRepositoryResult> List(long id, int? typeId)
        {
            try
            {
                var userId = User.GetUserId();

                var result = await _clientsBusiness.GetDetailsApi(id, typeId, userId);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_clientsBusiness.ServerError());
            }

        }

        /// <summary>
        /// payment methods list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("PaymentMethods")]
        [ProducesResponseType(typeof(List<PaymentMethodDto>), 200)]
        public async Task<IRepositoryResult> PaymentMethods()
        {
            try
            {
                var result = await _clientsBusiness.GetPaymentMethods();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_clientsBusiness.ServerError());
            }
        }

        /// <summary>
        /// subscriptions list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Subscriptions")]
        [ProducesResponseType(typeof(List<SubscriptionDto>), 200)]
        public async Task<IRepositoryResult> Subscriptions(int pageNum = 0)
        {
            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_clientsBusiness.UnAuthorized());
                }

                var userId = User.GetUserId();

                var result = await _clientsBusiness.GetUserSubscriptions(userId, pageNum);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_clientsBusiness.ServerError());
            }
        }

        /// <summary>
        /// subscribe to package
        /// </summary>
        /// <remarks></remarks>
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost]
        [Route("Subscribe")]
        public async Task<IRepositoryResult> Subscribe([FromBody] SubscribePackageParameters model)
        {

            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_clientsBusiness.UnAuthorized());
                }

                if (ModelState.IsValid)
                {
                    string baseUrl = string.Concat(HttpContext.Request.IsHttps ? "https://" : "http://", HttpContext.Request.Host);
                    var result = await _clientsBusiness.Subscribe(model, User.GetUserId(), baseUrl);
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_clientsBusiness.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_clientsBusiness.ServerError());
            }
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet]
        [Route("Subscriptions/Invoice/{orderId}")]
        public async Task<IRepositoryResult> Invoice(long orderId)
        {
            if (!User.IsGuest())
            {
                var order = await _clientsBusiness.GetSubscriptionDetails(orderId);

                var webRoot = _env.WebRootPath;
                var uploadsInvoiceFolder = Path.Combine(webRoot, _filePath);
                var invoiceFile = Path.Combine(uploadsInvoiceFolder, order.Id + ".pdf");
                if (!System.IO.File.Exists(invoiceFile))
                {
                    if (!Directory.Exists(uploadsInvoiceFolder))
                    {
                        Directory.CreateDirectory(uploadsInvoiceFolder);
                    }

                    var url = string.Concat(HttpContext.Request.IsHttps ? "https://" : "http://", HttpContext.Request.Host, FileHelper.BaseFileUrl);
                    string invoice = _htmlToPdfConverter.OrderInvoiceHtml(order, url);
                    var file = _htmlToPdfConverter.PdfCnverter(invoice);
                    var fileName = order.Id + ".pdf";
                    var filePath = Path.Combine(uploadsInvoiceFolder, fileName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.FileStream.CopyToAsync(fileStream);
                    }
                }

                var fileUrl = string.Concat(HttpContext.Request.IsHttps ? "https://" : "http://", HttpContext.Request.Host, FileHelper.PaymentFileUrl, order.Id + ".pdf");

                var result = await _clientsBusiness.GenerateResponse(fileUrl);

                return ResponseHandler.GetResult(result);
            }

            return ResponseHandler.GetResult(_clientsBusiness.UnAuthorized());
        }

    }
}