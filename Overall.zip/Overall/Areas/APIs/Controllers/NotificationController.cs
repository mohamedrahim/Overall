﻿using DataLayer.Extensions;
using HelperLayer.Dtos.Notifications;
using HelperLayer.Parameters.Notifications;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ServiceLayer.Business.Notifications;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Overall.Areas.Apis.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class NotificationController : BaseController
    {
        INotificationBusiness _notificationService;

        public NotificationController(INotificationBusiness notificationService,
            IActionResultResponseHandler responseHandler,
            IConfiguration configuration) : base(responseHandler, configuration)
        {
            _notificationService = notificationService;
        }

        /// <summary>
        /// set your phone device token (iphone:1,android:2) (arabic:"ar",english:"en")
        /// </summary>
        /// <remarks></remarks>
        [HttpPost("SetToken")]
        public async Task<IRepositoryResult> SetFireBaseToken([FromBody] TokenModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _notificationService.AddOrEdit(model, User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_notificationService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_notificationService.ServerError());
            }
        }

        /// <summary>
        /// notifications list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("UserNotifications")]
        [ProducesResponseType(typeof(List<NotificationDetails>), 200)]
        public async Task<IRepositoryResult> UserNotifications(int pageNum = 0)
        {
            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_notificationService.UnAuthorized());
                }

                var userId = User.GetUserId();
                var result = await _notificationService.GetUserNotificationsList(userId, pageNum);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_notificationService.ServerError());
            }
        }

        /// <summary>
        /// notification details
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Details")]
        [ProducesResponseType(typeof(NotificationDetails), 200)]
        public async Task<IRepositoryResult> Details(Guid notificationId)
        {
            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_notificationService.UnAuthorized());
                }

                var result = await _notificationService.GetNotificationDetails(notificationId);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_notificationService.ServerError());
            }
        }

        /// <summary>
        /// notification count
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Count")]
        [ProducesResponseType(typeof(int), 200)]
        public async Task<IRepositoryResult> Count()
        {
            try
            {
                if (User.IsGuest())
                {
                    return ResponseHandler.GetResult(_notificationService.UnAuthorized());
                }

                var userId = User.GetUserId();
                var result = await _notificationService.GetUserNotificationsCount(userId);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_notificationService.ServerError());
            }
        }

    }
}