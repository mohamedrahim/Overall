﻿using DataLayer.Extensions;
using HelperLayer.Dtos.Account;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ServiceLayer.Business.Favorites;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Overall.Areas.Apis.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class FavouriteController : BaseController
    {
        IFavoriteBusiness _favouriteService;

        public FavouriteController(IFavoriteBusiness favouriteService,
            IActionResultResponseHandler responseHandler,
            IConfiguration configuration) : base(responseHandler, configuration)
        {
            _favouriteService = favouriteService;
        }

        /// <summary>
        /// user favorite list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("List")]
        [ProducesResponseType(typeof(List<FavoriteDto>), 200)]
        public async Task<IRepositoryResult> List(int pageNum = 0)
        {
            try
            {
                var result = await _favouriteService.GetFavoriteApi(User.GetUserId(), pageNum);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_favouriteService.ServerError());
            }
        }

        /// <summary>
        /// add to favorite
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Add")]
        public async Task<IRepositoryResult> Add([FromBody] AddClientToFavoriteParameters model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _favouriteService.Add(model.ClientId, User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_favouriteService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_favouriteService.ServerError());
            }
        }

        /// <summary>
        /// Delete Address
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Delete/{id}")]
        public async Task<IRepositoryResult> Delete(long id)
        {
            try
            {
                var result = await _favouriteService.Delete(id);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_favouriteService.ServerError());
            }
        }

    }
}