﻿using Business.Services.UserSer;
using DataLayer.Extensions;
using HelperLayer.Dtos.Clients;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ServiceLayer.Business.Clients;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Overall.Areas.Apis.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class UserController : BaseController
    {
        IUserBusiness _userService;
        IClientsBusiness _clientsBusiness;

        public UserController(IActionResultResponseHandler responseHandler,
            IConfiguration configuration,
            IUserBusiness userService,
            IClientsBusiness clientsBusiness) : base(responseHandler, configuration)
        {
            _userService = userService;
            _clientsBusiness = clientsBusiness;
        }

        /// <summary>
        /// Genders list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Genders")]
        [ProducesResponseType(typeof(List<GenderDto>), 200)]
        public async Task<IRepositoryResult> Genders()
        {
            try
            {
                var result = await _clientsBusiness.GetGenders();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// user addresses list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Addresses")]
        [ProducesResponseType(typeof(List<AddressDto>), 200)]
        public async Task<IRepositoryResult> Addresses()
        {
            try
            {
                //if (User.IsGuest())
                //{
                //    return ResponseHandler.GetResult(_userService.UnAuthorized());
                //}

                var result = await _userService.Addresses(User.GetUserId());
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// add address
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Addresses/Add")]
        public async Task<IRepositoryResult> AddAddress([FromBody] AddAddressParameters model)
        {
            try
            {
                //if (User.IsGuest())
                //{
                //    return ResponseHandler.GetResult(_userService.UnAuthorized());
                //}

                if (ModelState.IsValid)
                {
                    var result = await _userService.AddAddress(model, User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// update address details
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Addresses/Update")]
        public async Task<IRepositoryResult> UpdateAddress([FromBody] UpdateAddressParameters model)
        {
            try
            {
                //if (User.IsGuest())
                //{
                //    return ResponseHandler.GetResult(_userService.UnAuthorized());
                //}

                if (ModelState.IsValid)
                {
                    var result = await _userService.UpdateAddress(model, User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_userService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

        /// <summary>
        /// Delete Address
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Addresses/Delete/{id}")]
        public async Task<IRepositoryResult> DeleteAddress(long id)
        {
            try
            {
                //if (User.IsGuest())
                //{
                //    return ResponseHandler.GetResult(_userService.UnAuthorized());
                //}

                var result = await _userService.DeleteAddress(id, User.GetUserId());
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_userService.ServerError());
            }
        }

    }
}