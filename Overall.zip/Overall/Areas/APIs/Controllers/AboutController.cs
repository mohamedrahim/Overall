﻿using DataLayer.Extensions;
using HelperLayer.Dtos.Faqs;
using HelperLayer.Dtos.Settings;
using HelperLayer.Parameters.Accounts;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ServiceLayer.Business.Account;
using ServiceLayer.Business.Faqs;
using ServiceLayer.Business.Settings;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Overall.Areas.Apis.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class AboutController : BaseController
    {
        ISettingBusiness _settingService;
        IContactusBusiness _contactService;
        IFaqBusiness _faqBusiness;

        public AboutController(ISettingBusiness settingService,
            IContactusBusiness contactService,
            IFaqBusiness faqBusiness,
            IActionResultResponseHandler responseHandler,
            IConfiguration configuration) : base(responseHandler, configuration)
        {
            _settingService = settingService;
            _contactService = contactService;
            _faqBusiness = faqBusiness;
        }

        /// <summary>
        /// about app details
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Aboutus")]
        [ProducesResponseType(typeof(AboutDetails), 200)]
        public async Task<IRepositoryResult> Aboutus()
        {
            try
            {
                var result = await _settingService.Aboutus();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_contactService.ServerError());
            }
        }

        /// <summary>
        /// all faqs
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("FAQs")]
        [ProducesResponseType(typeof(List<FaqDto>), 200)]
        public async Task<IRepositoryResult> FAQs()
        {
            try
            {
                var result = await _faqBusiness.FAQs();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_contactService.ServerError());
            }
        }

        /// <summary>
        /// get app version
        /// </summary>
        /// <remarks></remarks>
        [AllowAnonymous]
        [HttpGet]
        [Route("GetAppVersion")]
        [ProducesResponseType(typeof(AppDetails), 200)]
        public async Task<IRepositoryResult> GetAppVersion()
        {
            try
            {
                var result = await _settingService.GetAppVersion();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_contactService.ServerError());
            }
        }

        /// <summary>
        /// terms and conditions details
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Terms")]
        [ProducesResponseType(typeof(TermsDetails), 200)]
        public async Task<IRepositoryResult> Terms()
        {
            try
            {
                var result = await _settingService.Terms();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_contactService.ServerError());
            }
        }

        /// <summary>
        /// privacy and policy details
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Privacy")]
        [ProducesResponseType(typeof(PrivacyDetails), 200)]
        public async Task<IRepositoryResult> Privacy()
        {
            try
            {
                var result = await _settingService.Privacy();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_contactService.ServerError());
            }
        }

        /// <summary>
        /// contacts details
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("Contactus")]
        [ProducesResponseType(typeof(ContactDetails), 200)]
        public async Task<IRepositoryResult> Contactus()
        {
            try
            {
                var result = await _settingService.Contacts();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_contactService.ServerError());
            }
        }

        /// <summary>
        /// add contactus message
        /// </summary>
        /// <remarks></remarks>
        [HttpPost]
        [Route("Contactus")]
        public async Task<IRepositoryResult> AddMessage([FromBody] ContactusParameters model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _contactService.Add(model, User.GetUserId());
                    return ResponseHandler.GetResult(result);
                }
                else
                {
                    return ResponseHandler.GetResult(_contactService.ValidationErrors());
                }
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_contactService.ServerError());
            }
        }

    }
}