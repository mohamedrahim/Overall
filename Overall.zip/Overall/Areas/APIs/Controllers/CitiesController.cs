﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelperLayer.Dtos.CitiesAndArea;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ServiceLayer.Business.CitiesAndArea;

namespace Overall.Areas.Apis.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class CitiesController : BaseController
    {
        ICityBusiness _cityService;
        IAreaBusiness _areaService;

        public CitiesController(ICityBusiness cityService,
            IAreaBusiness areaService,
            IActionResultResponseHandler responseHandler,
            IConfiguration configuration) : base(responseHandler, configuration)
        {
            _cityService = cityService;
            _areaService = areaService;
        }

        [HttpGet]
        [Route("List")]
        [ProducesResponseType(typeof(List<CityDetails>), 200)]
        public async Task<IRepositoryResult> List()
        {
            try
            {
                var result = await _cityService.GetCitiesList();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_cityService.ServerError());
            }
        }

        [HttpGet]
        [Route("AreaList/{cityId}")]
        [ProducesResponseType(typeof(List<AreaDetails>), 200)]
        public async Task<IRepositoryResult> AreaList(long cityId)
        {
            try
            {
                var result = await _areaService.GetAreasList(cityId);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_cityService.ServerError());
            }
        }

        [HttpGet]
        [Route("CurrentLocation")]
        [ProducesResponseType(typeof(AreaDetails), 200)]
        public async Task<IRepositoryResult> CurrentLocation(string areaName)
        {
            try
            {
                var result = await _areaService.GetCurrentLocation(areaName);
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_cityService.ServerError());
            }
        }

    }
}