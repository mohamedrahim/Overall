﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HelperLayer.Dtos.CategoryDtos;
using HelperLayer.Dtos.Clients;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ServiceLayer.Business.Category;

namespace Overall.Areas.Apis.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class CategoryController : BaseController
    {
        ICategoryBusiness _categoryService;

        public CategoryController(IActionResultResponseHandler responseHandler,
            IConfiguration configuration,
            ICategoryBusiness categoryService) : base(responseHandler, configuration)
        {
            _categoryService = categoryService;
        }

        /// <summary>
        /// Get all categories list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("GetAll")]
        [ProducesResponseType(typeof(List<CategoryDetailsApi>), 200)]
        public async Task<IRepositoryResult> GetAll()
        {
            try
            {
                var result = await _categoryService.GetCategoriesApi();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_categoryService.ServerError());
            }
        }

        /// <summary>
        /// Get all categories list
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("GetPackageType")]
        [ProducesResponseType(typeof(List<PackageCategoryDto>), 200)]
        public async Task<IRepositoryResult> GetPackageType()
        {
            try
            {
                var result = await _categoryService.GetPackageCategoriesApi();
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_categoryService.ServerError());
            }
        }

    }
}