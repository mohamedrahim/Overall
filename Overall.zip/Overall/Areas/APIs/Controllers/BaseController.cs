﻿using HelperLayer.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Overall.Areas.Apis.Attributes;

namespace Overall.Areas.Apis.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [CheckHeaderAttribute]
    public class BaseController : ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        protected readonly IActionResultResponseHandler ResponseHandler;
        private readonly IConfiguration _configuration;

        public BaseController(IActionResultResponseHandler responseHandler, IConfiguration configuration = null)
        {
            ResponseHandler = responseHandler;
            _configuration = configuration;
        }
    }
}