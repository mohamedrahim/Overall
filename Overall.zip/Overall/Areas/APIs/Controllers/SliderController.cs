﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DataLayer.Extensions;
using HelperLayer.Dtos.SliderDto;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ServiceLayer.Business.Sliders;

namespace Overall.Areas.Apis.Controllers
{

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class SliderController : BaseController
    {
        ISliderBusiness _sliderService;

        public SliderController(ISliderBusiness sliderService,
            IActionResultResponseHandler responseHandler,
            IConfiguration configuration) : base(responseHandler, configuration)
        {
            _sliderService = sliderService;
        }

        /// <summary>
        /// slider images
        /// </summary>
        /// <remarks></remarks>
        [HttpGet]
        [Route("List")]
        [ProducesResponseType(typeof(List<SliderApiDto>), 200)]
        public async Task<IRepositoryResult> List()
        {
            try
            {
                var result = await _sliderService.GetSlidersApi(User.GetUserId());
                return ResponseHandler.GetResult(result);
            }
            catch (Exception e)
            {
                LogHelper.LogException(e);
                return ResponseHandler.GetResult(_sliderService.ServerError());
            }
        }

    }
}