﻿using HelperLayer.Utilities;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Overall.Areas.Apis.Attributes
{
    public class CheckHeaderAttribute : ActionFilterAttribute
    {

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var lang = filterContext.HttpContext.Request.Headers["Accept-Language"].ToString();
            ResourcesReader.IsArabic = (lang.ToLower() == "ar" ? true : false);
        }
    }
}
