using Business.Services.SettingsSer;
using Business.Services.UserSer;
using DataLayer.Abstract;
using DataLayer.Models;
using DataLayer.Models.DB;
using DataLayer.SeedData;
using FirebaseAdmin;
using FluentValidation.AspNetCore;
using Google.Apis.Auth.OAuth2;
using HelperLayer.Parameters.Clients;
using HelperLayer.Swagger;
using HelperLayer.Utilities;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using ServiceLayer.Base;
using ServiceLayer.Business.Account;
using ServiceLayer.Business.Category;
using ServiceLayer.Business.CitiesAndArea;
using ServiceLayer.Business.Clients;
using ServiceLayer.Business.Faqs;
using ServiceLayer.Business.Favorites;
using ServiceLayer.Business.Notifications;
using ServiceLayer.Business.Settings;
using ServiceLayer.Business.Sliders;
using Swashbuckle.AspNetCore.SwaggerUI;
using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;

namespace Overall
{
    /// <summary>
    /// start up file to register services and configure requests
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// start up constructor
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration, Microsoft.AspNetCore.Hosting.IHostingEnvironment _env)
        {
            Configuration = configuration;
            env = _env;
        }

        /// <summary>
        /// configuration property
        /// </summary>
        public IConfiguration Configuration { get; }
        public Microsoft.AspNetCore.Hosting.IHostingEnvironment env { get; }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddLocalization(options => options.ResourcesPath = "Resources");

            var arabCulture = new CultureInfo("en-US");
            var enCulture = new CultureInfo("ar-EG");

            var dateFormate = new DateTimeFormatInfo
            {
                LongDatePattern = "dd/MM/yyyy",
                ShortDatePattern = "dd/MM/yyyy"
            };

            arabCulture.DateTimeFormat = dateFormate;
            enCulture.DateTimeFormat = dateFormate;
            services.Configure<RequestLocalizationOptions>(options =>
            {
                var supportedCultures = new[]
                {
                enCulture,
                arabCulture
                };

                options.DefaultRequestCulture = new RequestCulture(culture: "en-US", uiCulture: "en-US");
                options.SupportedCultures = supportedCultures;
                options.SupportedUICultures = supportedCultures;
            });

            services.AddDbContext<OverallDBContext>(
                options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"),
                            Assembly => Assembly.MigrationsAssembly(typeof(OverallDBContext).Assembly.FullName))
                );

            services.AddIdentity<AppUser, AppRole>(config =>
            {
                config.SignIn.RequireConfirmedEmail = false;
                config.User.AllowedUserNameCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._@+%$*";
                config.User.RequireUniqueEmail = false;
                config.Password.RequireDigit = false;
                config.Password.RequiredLength = 3;
                config.Password.RequiredUniqueChars = 0;
                config.Password.RequireUppercase = false;
                config.Password.RequireLowercase = false;
                config.Password.RequireNonAlphanumeric = false;

            }).AddDefaultTokenProviders()
              .AddEntityFrameworkStores<OverallDBContext>();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Tokens:Key"]));
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                         .AddJwtBearer(cfg =>
                         {
                             cfg.RequireHttpsMetadata = false;
                             cfg.SaveToken = true;
                             cfg.TokenValidationParameters = new TokenValidationParameters()
                             {
                                 IssuerSigningKey = key,
                                 ValidateAudience = true,
                                 ValidAudience = this.Configuration["Tokens:Issuer"],
                                 ValidateIssuer = true,
                                 ValidIssuer = this.Configuration["Tokens:Issuer"],
                                 ValidateLifetime = true,
                                 ValidateIssuerSigningKey = true
                             };
                             cfg.Events = new JwtBearerEvents();
                             cfg.Events.OnChallenge = context =>
                             {
                                 // Skip the default logic.
                                 context.HandleResponse();

                                 var payload = new
                                 {
                                     Data = "",
                                     Success = false,
                                     Message = "UnAuthorized Access"
                                 };

                                 context.Response.ContentType = "application/json";
                                 return context.Response.WriteAsync(JsonConvert.SerializeObject(payload, new JsonSerializerSettings
                                 {
                                     ContractResolver = new CamelCasePropertyNamesContractResolver()
                                 }));

                             };
                         });


            services.ConfigureApplicationCookie(options =>
            {
                options.LoginPath = "/Admin/Login";
                options.AccessDeniedPath = "/Admin/Logout";
            });

            services.AddDistributedMemoryCache();
            services.AddSession();

            // include support for CORS
            // More often than not, we will want to specify that our API accepts requests coming from other origins (other domains). When issuing AJAX requests, browsers make preflights to check if a server accepts requests from the domain hosting the web app. If the response for these preflights don't contain at least the Access-Control-Allow-Origin header specifying that accepts requests from the original domain, browsers won't proceed with the real requests (to improve security).
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy-public",
                    builder => builder.AllowAnyOrigin()   //WithOrigins and define a specific origin to be allowed (e.g. https://mydomain.com)
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                .Build());
            });

            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });

            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();

            #region DI

            //services.AddScoped<ISeedData, SeedData>();
            services.AddScoped<DbContext, OverallDBContext>();
            services.AddScoped<IExportTable, ExportTable>();
            services.AddTransient<IAppSettings, AppSettings>();
            services.AddTransient(typeof(IUnitOfWork<>), typeof(UnitOfWork<>));
            services.AddTransient(typeof(IRepository<>), typeof(Repository<>));
            services.AddTransient<IActionResultResponseHandler, ActionResultResponseHandler>();
            services.AddTransient<IRepositoryActionResult, RepositoryActionResult>();
            services.AddTransient<IRepositoryResult, RepositoryResult>();
            services.AddTransient<ISliderBusiness, SliderBusiness>();
            services.AddTransient<IBusinessBaseParameter<Slider>, BusinessBaseParameter<Slider>>();
            services.AddTransient<ICityBusiness, CityBusiness>();
            services.AddTransient<IBusinessBaseParameter<City>, BusinessBaseParameter<City>>();
            services.AddTransient<IAreaBusiness, AreaBusiness>();
            services.AddTransient<IBusinessBaseParameter<Area>, BusinessBaseParameter<Area>>();
            services.AddTransient<ISettingBusiness, SettingBusiness>();
            services.AddTransient<IBusinessBaseParameter<Info>, BusinessBaseParameter<Info>>();
            services.AddTransient<IUserBusiness, UserBusiness>();
            services.AddTransient<IBusinessBaseParameter<AppUser>, BusinessBaseParameter<AppUser>>();
            services.AddTransient<ICategoryBusiness, CategoryBusiness>();
            services.AddTransient<IBusinessBaseParameter<ClientCategory>, BusinessBaseParameter<ClientCategory>>();
            services.AddTransient<IClientsBusiness, ClientsBusiness>();
            services.AddTransient<IBusinessBaseParameter<Client>, BusinessBaseParameter<Client>>();
            services.AddTransient<IContactusBusiness, ContactusBusiness>();
            services.AddTransient<IBusinessBaseParameter<Contactus>, BusinessBaseParameter<Contactus>>();
            services.AddTransient<INotificationBusiness, NotificationBusiness>();
            services.AddTransient<IBusinessBaseParameter<Notification>, BusinessBaseParameter<Notification>>();
            services.AddTransient<IPushNotificationService, PushNotificationService>();
            services.AddTransient<IFaqBusiness, FaqBusiness>();
            services.AddTransient<IBusinessBaseParameter<Faq>, BusinessBaseParameter<Faq>>();
            services.AddTransient<IFavoriteBusiness, FavoriteBusiness>();
            services.AddTransient<IBusinessBaseParameter<Favorite>, BusinessBaseParameter<Favorite>>();
            services.AddScoped<IHtmlToPdfConverter, HtmlToPdfConverter>();
            services.AddScoped<IHesabePaymentV2, HesabePaymentV2>();

            services.AddTransient<IActionResultResponseHandler, ActionResultResponseHandler>();
            services.AddTransient<IRepositoryActionResult, RepositoryActionResult>();
            services.AddTransient<IRepositoryResult, RepositoryResult>();

            #endregion

            services.AddScoped<IUrlHelper>(x =>
            {
                var actionContext = x.GetRequiredService<IActionContextAccessor>().ActionContext;
                var factory = x.GetRequiredService<IUrlHelperFactory>();
                return factory.GetUrlHelper(actionContext);
            });

            services.AddAutoMapper(typeof(Startup));

            services.AddControllersWithViews().AddRazorRuntimeCompilation();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0)
                 .AddFluentValidation(fv => fv.RegisterValidatorsFromAssemblyContaining<PackageValidator>());

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = "Overall API V1", Version = "v1" });

                options.AddSecurityDefinition("bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme.",
                });

                options.OperationFilter<AuthOperationFilter>();
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
            });

            //    var googleCredential = env.ContentRootPath;
            //var filePath = Configuration["GoogleFilePath"];
            //var googleCredential = Path.Combine(AppContext.BaseDirectory, filePath);
            //var credential = GoogleCredential.FromFile(googleCredential);
            //FirebaseApp.Create(new AppOptions()
            //{
            //    Credential = credential
            //});
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        /// <param name="userManager"></param>
        /// <param name="roleManager"></param>
        /// <param name="_db"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, UserManager<AppUser> userManager, RoleManager<AppRole> roleManager, OverallDBContext _db)
        {
            var localizationOption = app.ApplicationServices.GetService<IOptions<RequestLocalizationOptions>>();
            app.UseRequestLocalization(localizationOption.Value);

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseMigrationsEndPoint();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            UpdateDatabase(app); //Run Migration

            //seed data
            ApplicationDbInitializer.SeedUsers(userManager, roleManager, _db);

            app.UseCors("CorsPolicy");
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            var cookiePolicyOptions = new CookiePolicyOptions
            {
                MinimumSameSitePolicy = SameSiteMode.Strict,
                HttpOnly = Microsoft.AspNetCore.CookiePolicy.HttpOnlyPolicy.Always,
                Secure = CookieSecurePolicy.None,
            };
            app.UseCookiePolicy(cookiePolicyOptions);

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseSwagger(c => c.SerializeAsV2 = true);
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "Overall API V1");
                c.DocumentTitle = "Overall Documentation";
                c.DocExpansion(DocExpansion.None);
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
                endpoints.MapRazorPages();
            });
        }

        /// <summary>
        /// Run database migration automatically
        /// </summary>
        /// <param name="app"></param>
        public static void UpdateDatabase(IApplicationBuilder app)
        {
            using (var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<OverallDBContext>();
                context.Database.Migrate();
            }
        }

    }
}
