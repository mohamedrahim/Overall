﻿using System;
using System.Threading.Tasks;

namespace DataLayer.Abstract
{
    public interface IUnitOfWork<T> : IDisposable where T : class
    {
        IRepository<T> Repository { get; }
        Task<int> SaveChanges();
        void StartTransaction();
        void CommitTransaction();
        void Rollback();
        bool HasChanges();
    }
}
