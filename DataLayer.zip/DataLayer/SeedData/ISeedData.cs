﻿using DataLayer.Models;
using DataLayer.Models.DB;

namespace Afaqy.Erp.DataLayer.InitData
{
    public interface ISeedData
    {
        //Screen[] ScreenList();
        AppRole[] RolesList();
        PeriodIndicator[] PeriodIndicatorList();

    }
}