﻿using DataLayer.Models;
using DataLayer.Models.DB;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.SeedData
{
    public static class ApplicationDbInitializer
    {
        public static void SeedUsers(UserManager<AppUser> userManager, RoleManager<AppRole> roleManager, OverallDBContext _db)
        {
            var roleExist = roleManager.RoleExistsAsync("Admin").Result;
            if (!roleExist)
            {
                var role = new AppRole
                {
                    Name = "Admin",
                    NormalizedName = "ADMIN",
                };

                IdentityResult res = roleManager.CreateAsync(role).Result;
            }

            var centerRoleExist = roleManager.RoleExistsAsync("Center").Result;
            if (!centerRoleExist)
            {
                var role = new AppRole
                {
                    Name = "Center",
                    NormalizedName = "CENTER",
                };

                IdentityResult res = roleManager.CreateAsync(role).Result;
            }

            var role2Exist = roleManager.RoleExistsAsync("Moderator").Result;
            if (!role2Exist)
            {
                var role = new AppRole
                {
                    Name = "Moderator",
                    NormalizedName = "MODERATOR",
                };

                IdentityResult res = roleManager.CreateAsync(role).Result;
            }

            var userExist = userManager.FindByNameAsync("admin").Result;
            if (userExist == null)
            {
                AppUser user = new AppUser
                {
                    FirstName = "Super",
                    LastName = "Admin",
                    UserName = "admin",
                    Email = "admin@admin.com",
                    Type = 1,
                    IsActive = true,
                    CreatedOn = DateTime.UtcNow
                };

                IdentityResult result = userManager.CreateAsync(user, "123").Result;

                if (result.Succeeded)
                {
                    userManager.AddToRoleAsync(user, "Admin").Wait();
                }
            }
            else
            {
                userManager.AddToRoleAsync(userExist, "Admin").Wait();
            }

        }
    }
}
