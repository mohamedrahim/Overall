﻿//using System;
//using System.Collections.Generic;
//using DataLayer.Models;
//using DataLayer.Models.DB;

//namespace Afaqy.Erp.DataLayer.InitData
//{
//    public class SeedData : ISeedData
//    {
//        public AppRole[] RolesList()
//        {
//            var roles = new List<AppRole>();
//            roles.AddRange(new[] {
//                new AppRole{ ScreenId =1, Name ="Cities",Id = "9504c27c-6b15-4bd2-b8d7-eb22b115a13f"},
//                new AppRole{ ScreenId =2, Name ="Categories",Id = "7a675ebe-3ed8-4d55-9046-a097addd484b"},
//                new AppRole{ ScreenId =3, Name ="Slider",Id = "3468f2f1-4c15-495f-bcdb-d06b112784b6"},
//                new AppRole{ ScreenId = 4, Name = "Faqs",Id = "bc8eb7e4-2615-4135-9146-ebd3b6196c99"},
//                new AppRole{ ScreenId = 5, Name = "AboutUs",Id = "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b"},
//                new AppRole{ ScreenId = 6, Name = "TermsAndConditions",Id ="191f1dba-e09b-418e-9ac7-30d10218a73a"},
//                new AppRole{ ScreenId = 7, Name = "AppSettings",Id = "a4a2b595-4643-4ff7-a41e-234e0818a9fa"},
//                new AppRole{ ScreenId = 8, Name = "Contacts",Id = "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9"},
//                new AppRole{ ScreenId = 9, Name = "AccessControlList",Id = "5996d5a1-ed94-47cd-b72b-343ff918b7da"},
//                new AppRole{ ScreenId = 10, Name = "Customers",Id = "05e2acfb-6517-4a03-bc4a-a54b85d9aac0"},
//                new AppRole{ ScreenId = 11, Name = "AdminUsers",Id = "7f5992be-4625-4595-b52e-e80db3c6755f"},
//                new AppRole{ ScreenId = 12, Name = "Clients",Id = "be1ef631-c5aa-4962-8047-91bbcb8d2791"},
//               });
//            return roles.ToArray();
//        }

//        public Screen[] ScreenList()
//        {
//            var screens = new List<Screen>();
//            screens.AddRange(new[] {
//                new Screen{ Id =1, Name ="Cities",GroupName="Manage"},
//                new Screen{ Id =2, Name ="Categories",GroupName="Manage"},
//                new Screen{ Id =3, Name ="Slider",GroupName="Manage"},
//                new Screen{ Id = 4, Name = "Faqs",GroupName="Settings"},
//                new Screen{ Id = 5, Name = "About us",GroupName="Settings"},
//                new Screen{ Id = 6, Name = "Terms and Conditions",GroupName="Settings"},
//                new Screen{ Id = 7, Name = "App settings",GroupName="Settings"},
//                new Screen{ Id = 8, Name = "Contacts",GroupName="Settings"},
//                new Screen{ Id = 9, Name = "AccessControlList",GroupName="Users"},
//                new Screen{ Id = 10, Name = "Customers",GroupName="Users"},
//                new Screen{ Id = 11, Name = "AdminUsers",GroupName="Users"},
//                new Screen{ Id = 12, Name = "Clients",GroupName="Users"},
//               });
//            return screens.ToArray();
//        }

//        public PeriodIndicator[] PeriodIndicatorList()
//        {
//            var screens = new List<PeriodIndicator>();
//            screens.AddRange(new[] {
//                new PeriodIndicator{ Id =1, NameAr ="ايام",NameEn="Day/s"},
//                new PeriodIndicator{ Id =2, NameAr ="اسابيع",NameEn="Week/s"},
//                new PeriodIndicator{ Id =3, NameAr ="شهور",NameEn="Month/s"},
//               });
//            return screens.ToArray();
//        }

//    }
//}
