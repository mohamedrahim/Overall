﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models.DB
{
    public class City : BaseEntity
    {
        public City()
        {
            Areas = new HashSet<Area>();
        }

        public string NameAr { get; set; }
        public string NameEn { get; set; }

        public virtual ICollection<Area> Areas { get; set; }
    }

    public class Area : BaseEntity
    {
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public long CityId { get; set; }

        [ForeignKey("CityId")]
        public virtual City City { get; set; }
    }

}
