﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models.DB
{
    public class Address : BaseEntity
    {
        public string AddressTitle { get; set; }
        public string BlockNo { get; set; }
        public string StreetName { get; set; }
        public string BuildNo { get; set; }
        public string Avenue { get; set; }
        public string FloorNo { get; set; }
        public string ApartmentNo { get; set; }
        public string AddressDetails { get; set; }
        public string Mobile { get; set; }
        public long CityId { get; set; }
        public long AreaId { get; set; }
        public string Email { get; set; }
        public string UserId { get; set; }

        [ForeignKey("CityId")]
        public virtual City City { get; set; }

        [ForeignKey("AreaId")]
        public virtual Area Area { get; set; }

        [ForeignKey("UserId")]
        public virtual AppUser User { get; set; }
    }
}
