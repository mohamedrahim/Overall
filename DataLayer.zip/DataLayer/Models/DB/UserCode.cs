﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLayer.Models.DB
{
    public partial class UserCode
    {
        public long Id { get; set; }
        public string UserId { get; set; }
        public string Code { get; set; }
        public DateTime? ValidTo { get; set; }
        public byte? Status { get; set; }

        [ForeignKey("UserId")]
        public virtual AppUser User { get; set; }
    }
}
