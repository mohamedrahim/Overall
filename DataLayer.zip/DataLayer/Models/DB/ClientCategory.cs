﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models.DB
{
    public class ClientCategory : LookupEntity
    {
        public string ImageUrl { get; set; }
        public bool IsActive { get; set; }
        public string ModifyUserId { get; set; }
        public DateTime? ModifyDate { get; set; }
        public bool HasSubCategories { get; set; }
        public int? ParentCategoryId { get; set; }
        public bool IsDeleted { get; set; }
        public string DeleteUserId { get; set; }
        public DateTime? DeleteDate { get; set; }
        
        [ForeignKey("ParentCategoryId")]
        public virtual ClientCategory Parent { get; set; }

        [ForeignKey("ModifyUserId")]
        public virtual AppUser ModifyUser { get; set; }

        [ForeignKey("DeleteUserId")]
        public virtual AppUser DeleteUser { get; set; }
    }

}
