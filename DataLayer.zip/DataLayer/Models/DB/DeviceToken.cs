﻿using System;
using System.Collections.Generic;

namespace DataLayer.Models.DB
{
    public partial class DeviceToken
    {
        public long Id { get; set; }
        public string Token { get; set; }
        public string DeviceId { get; set; }
        public DateTime? Date { get; set; }
        public int? Type { get; set; }
        public string Lang { get; set; }
        public string UserId { get; set; }

        public virtual AppUser User { get; set; }
    }
}
