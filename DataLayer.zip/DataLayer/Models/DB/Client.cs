﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models.DB
{
    public class Client : BaseEntity
    {
        public Client()
        {
            Packages = new HashSet<Package>();
            ClientGenders = new HashSet<ClientGender>();
            ClientLocations = new HashSet<ClientLocation>();
        }

        public int CategoryId { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string DescriptionAr { get; set; }
        public string DescriptionEn { get; set; }
        public string AddressAr { get; set; }
        public string AddressEn { get; set; }
        public string Location { get; set; }
        public string Lat { get; set; }
        public string Lng { get; set; }
        public string LogoUrl { get; set; }
        public string CoverUrl { get; set; }
        public int Views { get; set; }
        public string UserId { get; set; }

        [ForeignKey("CategoryId")]
        public virtual ClientCategory ClientCategory { get; set; }

        [ForeignKey("UserId")]
        public virtual AppUser User { get; set; }

        public virtual ICollection<Package> Packages { get; set; }
        public virtual ICollection<ClientGender> ClientGenders { get; set; }
        public virtual ICollection<ClientLocation> ClientLocations { get; set; }
    }

    public class Package : BaseEntity
    {
        public long ClientId { get; set; }
        public int CategoryId { get; set; }
        public int? SubCategoryId { get; set; }
        public string NameAr { get; set; }
        public string NameEn { get; set; }
        public string DescriptionAr { get; set; }
        public string DescriptionEn { get; set; }
        public int? Duration { get; set; }
        public int? PeriodIndicatorId { get; set; }
        public int? Meals { get; set; }
        public int? Days { get; set; }
        public int? Sessions { get; set; }
        public double Price { get; set; }
        public double? OldPrice { get; set; }

        [ForeignKey("PeriodIndicatorId")]
        public virtual PeriodIndicator PeriodIndicator { get; set; }

        [ForeignKey("CategoryId")]
        public virtual ClientCategory ClientCategory { get; set; }

        [ForeignKey("ClientId")]
        public virtual Client Client { get; set; }
    }

    public class PeriodIndicator : LookupEntity
    {

    }

    public class Gender : LookupEntity
    {

    }

    public class ClientGender
    {
        [Key]
        public long Id { get; set; }
        public long ClientId { get; set; }
        public int GenderId { get; set; }

        [ForeignKey("GenderId")]
        public virtual Gender Gender { get; set; }

        [ForeignKey("ClientId")]
        public virtual Client Client { get; set; }
    }

    public class ClientLocation
    {
        [Key]
        public long Id { get; set; }
        public long ClientId { get; set; }
        public long AreaId { get; set; }

        [ForeignKey("AreaId")]
        public virtual Area Area { get; set; }

        [ForeignKey("ClientId")]
        public virtual Client Client { get; set; }
    }
}
