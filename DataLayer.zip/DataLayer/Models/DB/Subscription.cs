﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLayer.Models.DB
{
    public class Subscription : BaseEntity
    {
        public long ClientId { get; set; }
        public long PackageId { get; set; }
        public int CategoryId { get; set; }
        public double? OldPrice { get; set; }
        public double Price { get; set; }
        public DateTime StartDate { get; set; }
        public long? AddressId { get; set; }
        public int PaymentMethodId { get; set; }
        public bool IsPaid { get; set; }
        public string TransactionId { get; set; }
        public int? Duration { get; set; }
        public int? PeriodIndicatorId { get; set; }
        public int? Meals { get; set; }
        public int? Days { get; set; }
        public int? Sessions { get; set; }
        public string UserId { get; set; }
        public string ResponseId { get; set; }
        public string Auth { get; set; }
        public string PaymentId { get; set; }
        public string RefId { get; set; }
        public string TrankId { get; set; }
        public string Gateway { get; set; }


        [ForeignKey("CategoryId")]
        public virtual ClientCategory ClientCategory { get; set; }

        [ForeignKey("ClientId")]
        public virtual Client Client { get; set; }

        [ForeignKey("PackageId")]
        public virtual Package Package { get; set; }

        [ForeignKey("AddressId")]
        public virtual Address Address { get; set; }

        [ForeignKey("PaymentMethodId")]
        public virtual PaymentMethod PaymentMethod { get; set; }

        [ForeignKey("UserId")]
        public virtual AppUser User { get; set; }

        [ForeignKey("PeriodIndicatorId")]
        public virtual PeriodIndicator PeriodIndicator { get; set; }
    }
}
