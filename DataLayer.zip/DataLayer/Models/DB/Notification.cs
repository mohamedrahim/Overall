﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLayer.Models.DB
{
    public partial class Notification
    {
        public Notification()
        {
            NotificationUsers = new HashSet<NotificationUser>();
        }

        [Key]
        public long Id { get; set; }
        public string TitleAr { get; set; }
        public string TitleEn { get; set; }
        public string MessageAr { get; set; }
        public string MessageEn { get; set; }
        public int Type { get; set; }
        public long? ReferenceId { get; set; }
        public string Url { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }

        [ForeignKey("CreatedBy")]
        public virtual AppUser User { get; set; }

        public ICollection<NotificationUser> NotificationUsers { get; set; }
    }
}
