﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataLayer.Models.DB
{
    public partial class NotificationUser
    {
        [Key]
        public Guid Id { get; set; }
        public long NotificationId { get; set; }
        public bool? IsRead { get; set; }
        public string UserId { get; set; }
        public DateTime CreateDate { get; set; }

        [ForeignKey("UserId")]
        public virtual AppUser User { get; set; }

        [ForeignKey("NotificationId")]
        public virtual Notification Notification { get; set; }
    }
}
