﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace DataLayer.Models.DB
{
    public partial class OverallDBContext : IdentityDbContext<AppUser>
    {
        public IConfiguration _configuration { get; }
        // private readonly ISeedData _seedData;

        public OverallDBContext(IConfiguration configuration/*, ISeedData seedData*/)
        {
            _configuration = configuration;
            //_seedData = seedData;
        }

        public OverallDBContext(DbContextOptions<OverallDBContext> options, IConfiguration configuration)
            : base(options)
        {
            _configuration = configuration;
        }

        public virtual DbSet<AppRole> AspNetRoles { get; set; }
        public virtual DbSet<AppUser> AspNetUsers { get; set; }
        public virtual DbSet<ClientCategory> ClientCategories { get; set; }
        public virtual DbSet<Client> Clients { get; set; }
        public virtual DbSet<Package> Packages { get; set; }
        public virtual DbSet<PeriodIndicator> PeriodIndicators { get; set; }
        public virtual DbSet<PaymentMethod> PaymentMethods { get; set; }
        public virtual DbSet<Faq> Faqs { get; set; }
        public virtual DbSet<Slider> Sliders { get; set; }
        public virtual DbSet<Address> Addresses { get; set; }
        public virtual DbSet<Area> Areas { get; set; }
        public virtual DbSet<City> Cities { get; set; }
        public virtual DbSet<Screen> Screens { get; set; }
        public virtual DbSet<Info> Info { get; set; }
        public virtual DbSet<DeviceToken> DeviceToken { get; set; }
        public virtual DbSet<UserCode> UserCode { get; set; }
        public virtual DbSet<NotificationUser> NotificationUser { get; set; }
        public virtual DbSet<Notification> Notification { get; set; }
        public virtual DbSet<Subscription> Subscription { get; set; }
        public virtual DbSet<Contactus> Contactus { get; set; }
        public virtual DbSet<Favorite> Favorite { get; set; }
        public virtual DbSet<Gender> Gender { get; set; }
        public virtual DbSet<ClientLocation> ClientLocation { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(_configuration.GetConnectionString("DefaultConnection"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            #region Seed Data

            var roles = new List<AppRole>();
            roles.AddRange(new List<AppRole> {
                new AppRole{ ScreenId =1, Name ="Cities",NormalizedName="CITIES",Id = "9504c27c-6b15-4bd2-b8d7-eb22b115a13f"},
                new AppRole{ ScreenId =2, Name ="Categories",NormalizedName="CATEGORIES",Id = "7a675ebe-3ed8-4d55-9046-a097addd484b"},
                new AppRole{ ScreenId =3, Name ="Slider",NormalizedName="SLIDER",Id = "3468f2f1-4c15-495f-bcdb-d06b112784b6"},
                new AppRole{ ScreenId = 4, Name = "Faqs",NormalizedName="FAQS",Id = "bc8eb7e4-2615-4135-9146-ebd3b6196c99"},
                new AppRole{ ScreenId = 5, Name = "AboutUs",NormalizedName="ABOUTUS",Id = "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b"},
                new AppRole{ ScreenId = 6, Name = "TermsAndConditions",NormalizedName="TERMSANDCONDITIONS",Id ="191f1dba-e09b-418e-9ac7-30d10218a73a"},
                new AppRole{ ScreenId = 7, Name = "AppSettings",NormalizedName="APPSETTINGS",Id = "a4a2b595-4643-4ff7-a41e-234e0818a9fa"},
                new AppRole{ ScreenId = 8, Name = "Contacts",NormalizedName="CONTACTS",Id = "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9"},
                new AppRole{ ScreenId = 9, Name = "AccessControlList",NormalizedName="ACCESSCONTROLLIST",Id = "5996d5a1-ed94-47cd-b72b-343ff918b7da"},
                new AppRole{ ScreenId = 10, Name = "Customers",NormalizedName="CUSTOMERS",Id = "05e2acfb-6517-4a03-bc4a-a54b85d9aac0"},
                new AppRole{ ScreenId = 11, Name = "AdminUsers",NormalizedName="ADMINUSERS",Id = "7f5992be-4625-4595-b52e-e80db3c6755f"},
                new AppRole{ ScreenId = 12, Name = "Clients",NormalizedName="CLIENTS",Id = "be1ef631-c5aa-4962-8047-91bbcb8d2791"},
                new AppRole{ ScreenId = 13, Name = "Notification",NormalizedName="NOTIFICATION",Id = "be1ef632-c5aa-4962-8047-91bbcb8d2781"},
                new AppRole{ ScreenId = 14, Name = "UserMessages",NormalizedName="USERMESSAGES",Id = "be1ef631-c5aa-4962-8045-91bbcb8d3791"},
                new AppRole{ ScreenId = 15, Name = "Packages",NormalizedName="PACKAGES",Id = "be1ef631-c5aa-4962-8048-95bbcb8d2791"},
                new AppRole{ ScreenId = 16, Name = "PackageSubscriptions",NormalizedName="PACKAGESUBSCRIPTIONS",Id = "be1ef431-c5aa-4962-8147-97bbcb8d2791"},
               });

            modelBuilder.Entity<AppRole>().HasData(roles);


            var screens = new List<Screen>();
            screens.AddRange(new[] {
                new Screen{ ScreenId = 1, Name ="Cities",GroupName="Manage"},
                new Screen{ ScreenId = 2, Name ="Categories",GroupName="Manage"},
                new Screen{ ScreenId = 3, Name ="Slider",GroupName="Manage"},
                new Screen{ ScreenId = 4, Name = "Faqs",GroupName="Settings"},
                new Screen{ ScreenId = 5, Name = "About us",GroupName="Settings"},
                new Screen{ ScreenId = 6, Name = "Terms and Conditions",GroupName="Settings"},
                new Screen{ ScreenId = 7, Name = "App settings",GroupName="Settings"},
                new Screen{ ScreenId = 8, Name = "Contacts",GroupName="Settings"},
                new Screen{ ScreenId = 9, Name = "AccessControlList",GroupName="Users"},
                new Screen{ ScreenId = 10, Name = "Customers",GroupName="Users"},
                new Screen{ ScreenId = 11, Name = "AdminUsers",GroupName="Users"},
                new Screen{ ScreenId = 12, Name = "Clients",GroupName="Users"},
                new Screen{ ScreenId = 13, Name = "Notification",GroupName="Settings"},
                new Screen{ ScreenId = 14, Name = "User Messages",GroupName="Settings"},
                new Screen{ ScreenId = 15, Name = "Package",GroupName="Manage"},
                new Screen{ ScreenId = 16, Name = "Package Subscription",GroupName="Orders"},
               });

            modelBuilder.Entity<Screen>().HasData(screens);


            var periodIndicators = new List<PeriodIndicator>();
            periodIndicators.AddRange(new[] {
                new PeriodIndicator{ Id =1, NameAr ="ايام",NameEn="Day/s"},
                new PeriodIndicator{ Id =2, NameAr ="اسابيع",NameEn="Week/s"},
                new PeriodIndicator{ Id =3, NameAr ="شهور",NameEn="Month/s"},
               });

            modelBuilder.Entity<PeriodIndicator>().HasData(periodIndicators);

            var genders = new List<Gender>();
            genders.AddRange(new[] {
                new Gender{ Id =1, NameAr ="رجال",NameEn="Men"},
                new Gender{ Id =2, NameAr ="سيدات",NameEn="Women"},
               });

            modelBuilder.Entity<Gender>().HasData(genders);


            var categories = new List<ClientCategory>();
            categories.AddRange(new[] {
                new ClientCategory{ Id =1, NameAr ="Gym",NameEn="Gym",ImageUrl="",IsActive=true},
                new ClientCategory{ Id =2, NameAr ="Recovery Centers",NameEn="Recovery Centers",ImageUrl="",IsActive=true},
                new ClientCategory{ Id =3, NameAr ="Dietitian Centers",NameEn="Dietitian Centers",ImageUrl="",IsActive=true},
                new ClientCategory{ Id =4, NameAr ="Coaches",NameEn="Coaches",ImageUrl="",IsActive=true},
               });

            modelBuilder.Entity<ClientCategory>().HasData(categories);

            var paymentMethods = new List<PaymentMethod>();
            paymentMethods.AddRange(new[] {
                new PaymentMethod{ Id =1, NameAr ="كي نت",NameEn="Knet",ImageUrl="k-net.png",IsActive=true},
                new PaymentMethod{ Id =2, NameAr ="فيزا",NameEn="Visa",ImageUrl="visa.png",IsActive=true},
                new PaymentMethod{ Id =3, NameAr ="ماستر كارد",NameEn="MasterCard",ImageUrl="master.png",IsActive=true},
               });

            modelBuilder.Entity<PaymentMethod>().HasData(paymentMethods);

            #endregion

        }

    }
}
