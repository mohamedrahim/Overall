﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public abstract class BaseEntity
    {
        [Key]
        public long Id { get; set; }
        public string CreateUserId { get; set; }
        public DateTime CreateDate { get; set; }
        public string ModifyUserId { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string DeteleUserId { get; set; }
        public DateTime? DeleteDate { get; set; }
        public bool IsActive { get; set; } = true;
        public bool IsDeleted { get; set; } = false;

        [ForeignKey("CreateUserId")]
        public virtual AppUser CreatedUser { get; set; }

        [ForeignKey("ModifyUserId")]
        public virtual AppUser ModifyUser { get; set; }

        [ForeignKey("DeteleUserId")]
        public virtual AppUser DeteleUser { get; set; }
    }

    public class LookupEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Required]
        [StringLength(256)]
        public string NameEn { get; set; }

        [StringLength(256)]
        public string NameAr { get; set; }
    }

}
