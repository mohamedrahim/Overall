﻿using DataLayer.Models.DB;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class AppRole : IdentityRole
    {
        public int? ScreenId { get; set; }

        [ForeignKey("ScreenId")]
        public virtual Screen Screen { get; set; }
    }
}
