﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class paymentMethods : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contactus",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateUserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifyUserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ModifyDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeteleUserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DeleteDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contactus", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Contactus_AspNetUsers_CreateUserId",
                        column: x => x.CreateUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Contactus_AspNetUsers_DeteleUserId",
                        column: x => x.DeteleUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Contactus_AspNetUsers_ModifyUserId",
                        column: x => x.ModifyUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "71450ccc-7172-4c39-8895-35639b26663d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "a87eea53-1d63-46fa-a40d-06a4a537ad38");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "6cc8d1ed-d09b-48f3-8159-b91ab448d78b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "a09a7e52-8a67-4a64-8762-0c8fc72533f0");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "49c910ae-0951-4c8a-96ca-3811b53ef386");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "c4c7c5cd-8651-41c4-ad9a-e8688b5eb442");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "df673037-0cfc-4d10-85e3-20ea9cbf29db");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "ebdd0f8e-90e0-464a-98e1-385e5ef61897");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "c332316f-c5f8-4560-824d-02e9c83b3770");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "b68b0c1b-d8fe-464a-936e-a6afab61086b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "3c92e5a3-eefd-43e3-b026-d0cb787ce32f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "27e3a6cf-d183-4f5e-a0ba-46db55ed742a");

            migrationBuilder.InsertData(
                table: "PaymentMethods",
                columns: new[] { "Id", "ImageUrl", "IsActive", "NameAr", "NameEn" },
                values: new object[,]
                {
                    { 3, "master.png", true, "ماستر كارد", "MasterCard" },
                    { 2, "visa.png", true, "فيزا", "Visa" },
                    { 1, "k-net.png", true, "كي نت", "Knet" }
                });

            migrationBuilder.InsertData(
                table: "Screens",
                columns: new[] { "ScreenId", "GroupName", "Icon", "Name", "Url" },
                values: new object[,]
                {
                    { 15, "Manage", null, "Package", null },
                    { 14, "Settings", null, "User Messages", null },
                    { 13, "Settings", null, "Notification", null },
                    { 16, "Orders", null, "Package Subscription", null }
                });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Discriminator", "Name", "NormalizedName", "ScreenId" },
                values: new object[,]
                {
                    { "be1ef632-c5aa-4962-8047-91bbcb8d2781", "ab432333-9e3e-4d7f-9554-aa939885ff94", "AppRole", "Notification", "NOTIFICATION", 13 },
                    { "be1ef631-c5aa-4962-8045-91bbcb8d3791", "ecd40f0f-d316-4112-94a9-08c77cc36ba3", "AppRole", "UserMessages", "USERMESSAGES", 14 },
                    { "be1ef631-c5aa-4962-8048-95bbcb8d2791", "9769fc28-e076-42a4-bb13-e7b3ad9317db", "AppRole", "Packages", "PACKAGES", 15 },
                    { "be1ef431-c5aa-4962-8147-97bbcb8d2791", "88c1bd9f-1a0b-46c3-9f11-f7bbe930d6ed", "AppRole", "PackageSubscriptions", "PACKAGESUBSCRIPTION", 16 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contactus_CreateUserId",
                table: "Contactus",
                column: "CreateUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Contactus_DeteleUserId",
                table: "Contactus",
                column: "DeteleUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Contactus_ModifyUserId",
                table: "Contactus",
                column: "ModifyUserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Contactus");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781");

            migrationBuilder.DeleteData(
                table: "PaymentMethods",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "PaymentMethods",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "PaymentMethods",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Screens",
                keyColumn: "ScreenId",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Screens",
                keyColumn: "ScreenId",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Screens",
                keyColumn: "ScreenId",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Screens",
                keyColumn: "ScreenId",
                keyValue: 16);

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "24e04fb8-1d6c-4422-8882-3ea2fd352d1e");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "edd5e7db-68bf-443e-936b-5effdccc0f5a");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "a04c44c8-5803-4c6d-9980-8192e8ac4ca3");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "011552ee-a6bf-4926-9789-79e2688adfe1");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "9def0af1-56c5-4c8b-a82c-7a26791ef07d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "d78addf5-d3ea-48d4-86af-255221b48a49");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "43f20b2c-0b6c-4fa4-8c11-f4be61034c97");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "a8316d15-7bac-483e-b0db-ce2a6853e167");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "0eed6976-76b5-4f79-97d7-90f3509d1bdf");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "bba1b3b3-a252-4ed0-b1fc-5860d6582f8b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "78d6eab3-7609-4c9a-a9b9-2bb3a61b9a1b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "1244e2c7-4b92-4786-9e3b-4c53da26547e");
        }
    }
}
