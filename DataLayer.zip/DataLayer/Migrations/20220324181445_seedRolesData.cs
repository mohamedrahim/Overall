﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class seedRolesData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "9d5f3427-e16a-46a6-ba63-65db644bf4cb", "CUSTOMERS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "9c313a03-4673-40f8-83e7-797f835e3adb", "TERMSANDCONDITIONS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "01fd7de5-60a3-431d-b9ca-b52f087eeda6", "SLIDER" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "29ad255f-c48f-483a-b5de-21991e470955", "ABOUTUS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "a8f96ff3-8bb8-4d77-b2b5-8994c774248c", "ACTIONCONTROLLIST" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "f1da6a2e-5da2-4749-b928-525235654055", "CATEGORIES" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "239e9147-83ca-45bc-91e7-65ade1068748", "ADMINUSERS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "21a09a31-ae3e-405a-a4b1-fb5029dd1575", "CITIES" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "0e2a77bb-51ed-4232-b318-7b71a72dff70", "APPSETTINGS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "6cbafd40-f433-4ce4-a609-cb80f5f3935c", "FAQS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "bd89bf4a-2386-44c8-bd25-916023ce02e9", "CLIENTS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "a12f3690-4be2-442d-876b-512c2e54397e", "CONTACTS" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "10b6ac9b-5f51-41ac-b332-a1813e1ee336", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "b61060bb-dd67-4d73-b45c-2d797ec2af41", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "62743a95-a23f-4f01-8259-f121ad9502ec", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "3c3f206e-e455-41fa-8549-92510f2cf28a", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "63cc208b-3966-473a-bcda-c1a34b0ff298", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "0bfc8794-0e35-4561-b725-73c5f76af442", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "e6db8370-b45c-47ee-938f-a3d5c05e6fed", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "2b1733d1-d403-45b8-9354-a791aeec7898", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "b16402ff-239f-4bde-bc70-282e5d2a3484", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "3be32540-297a-4d3e-9608-eeb55698dbcd", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "c27ddf7e-33f7-41cb-a967-9414bac3e1f9", null });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "70617801-199c-4892-8ba1-f7770b2631be", null });
        }
    }
}
