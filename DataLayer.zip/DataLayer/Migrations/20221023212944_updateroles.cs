﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class updateroles : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "e0a584d7-0fc2-49bc-9f76-20a962501b16");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "c95a1709-f7c1-4c0d-9c4d-f977f7719403");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "deef16fc-efb6-428e-a399-039902992319");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "54bcae21-b590-45f1-91f5-361b6e94ca30");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "044f1adf-1e45-48fd-b73c-ebefe8e500be", "ACCESSCONTROLLIST" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "04021dc2-16b7-47a5-b45c-ff121d0e27fc");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "6545196c-25a8-482d-adab-390b89baf0de");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "836a371e-beac-43f6-8cb2-325a5d902b6f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "de1723e3-85a2-4e2b-b366-009b89dd5f31");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "c2a40641-6abe-434c-ad2d-31aaacb68b2b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "6e9911b0-4378-408d-96d0-e8d0d85f5c50", "PACKAGESUBSCRIPTIONS" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "9e205803-5682-4693-8585-8109ce911bcd");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "540810c8-c86a-4f3b-9697-39a6e385d80d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "a51ca9b2-5ebd-40bc-85e4-eebe6a2465b5");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "50cc3633-1f15-457e-b1d1-538ce84f99a3");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "04504c75-f637-4039-92fa-f8cda2cd3e8c");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "fa408b8e-7c2f-41eb-b190-7df271167381");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "c36c2d80-b120-4288-8ad4-279cf07a8fb4");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "72df35cc-d826-45d6-8359-cb98b74934ef");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "c2933370-d1ec-4e5e-af48-5d3c80a5c5e0");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "67ae4812-df1d-4c7f-8ab2-ddb2e80f2ad2", "ACTIONCONTROLLIST" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "e7cfa727-690e-4018-b90f-f9bd631d8f90");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "814c2aba-c865-451f-9e0d-d43528027066");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "32d462c0-38ef-46b1-a061-a7852a785bd0");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "e38f6ad3-85be-494a-bf34-5eb7c338a34b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "ad12c116-47ed-4c16-b7f0-951e3d6ef42f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                columns: new[] { "ConcurrencyStamp", "NormalizedName" },
                values: new object[] { "6140eca7-669a-41e8-8a8e-cf136345d8ca", "PACKAGESUBSCRIPTION" });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "8aa703c8-df41-46a7-a5f2-675f7973c764");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "df03258b-63df-43ec-9857-9b8cddf961c4");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "2de874df-e591-41af-870d-e8e7b9e01a80");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "2df775f2-931f-48ee-a1fc-8261989c2721");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "7285f73c-1e6d-4625-937f-3781b3eca62e");
        }
    }
}
