﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class addScreens : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Screens",
                columns: table => new
                {
                    ScreenId = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Icon = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Url = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GroupName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Screens", x => x.ScreenId);
                });

            migrationBuilder.InsertData(
                table: "Screens",
                columns: new[] { "ScreenId", "GroupName", "Icon", "Name", "Url" },
                values: new object[,]
                {
                    { 1, "Manage", null, "Cities", null },
                    { 2, "Manage", null, "Categories", null },
                    { 3, "Manage", null, "Slider", null },
                    { 4, "Settings", null, "Faqs", null },
                    { 5, "Settings", null, "About us", null },
                    { 6, "Settings", null, "Terms and Conditions", null },
                    { 7, "Settings", null, "App settings", null },
                    { 8, "Settings", null, "Contacts", null },
                    { 9, "Users", null, "AccessControlList", null },
                    { 10, "Users", null, "Customers", null },
                    { 11, "Users", null, "AdminUsers", null },
                    { 12, "Users", null, "Clients", null }
                });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Discriminator", "Name", "NormalizedName", "ScreenId" },
                values: new object[,]
                {
                    { "9504c27c-6b15-4bd2-b8d7-eb22b115a13f", "1d7457a0-fff5-46aa-9618-6a655d3a18c3", "AppRole", "Cities", null, 1 },
                    { "7a675ebe-3ed8-4d55-9046-a097addd484b", "f1313a8b-2be5-4803-81eb-ca5d32e3f8ba", "AppRole", "Categories", null, 2 },
                    { "3468f2f1-4c15-495f-bcdb-d06b112784b6", "fe22d02e-4133-4d33-9dff-bf842d7ef322", "AppRole", "Slider", null, 3 },
                    { "bc8eb7e4-2615-4135-9146-ebd3b6196c99", "5c5dbec0-8aad-475c-96e6-5d4d6146f182", "AppRole", "Faqs", null, 4 },
                    { "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b", "9d323185-5f58-42ea-99ad-a1ffa68ca115", "AppRole", "AboutUs", null, 5 },
                    { "191f1dba-e09b-418e-9ac7-30d10218a73a", "cf10fadc-17ec-4ca8-89b7-e15647e72616", "AppRole", "TermsAndConditions", null, 6 },
                    { "a4a2b595-4643-4ff7-a41e-234e0818a9fa", "4d872bc4-0e36-47de-a0b5-6699b541522a", "AppRole", "AppSettings", null, 7 },
                    { "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9", "0139f4d5-e52e-4745-9436-3982a09408a3", "AppRole", "Contacts", null, 8 },
                    { "5996d5a1-ed94-47cd-b72b-343ff918b7da", "456f5ab8-336e-426d-b2e7-a46ecb1bf340", "AppRole", "AccessControlList", null, 9 },
                    { "05e2acfb-6517-4a03-bc4a-a54b85d9aac0", "67139fee-84c3-4cee-bc7b-9db1024fea77", "AppRole", "Customers", null, 10 },
                    { "7f5992be-4625-4595-b52e-e80db3c6755f", "a595e123-f7b3-4c3d-875b-02034bdb33a2", "AppRole", "AdminUsers", null, 11 },
                    { "be1ef631-c5aa-4962-8047-91bbcb8d2791", "c4723695-2afe-43bc-91b7-104c696875c2", "AppRole", "Clients", null, 12 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoles_ScreenId",
                table: "AspNetRoles",
                column: "ScreenId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetRoles_Screens_ScreenId",
                table: "AspNetRoles",
                column: "ScreenId",
                principalTable: "Screens",
                principalColumn: "ScreenId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetRoles_Screens_ScreenId",
                table: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "Screens");

            migrationBuilder.DropIndex(
                name: "IX_AspNetRoles_ScreenId",
                table: "AspNetRoles");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9");
        }
    }
}
