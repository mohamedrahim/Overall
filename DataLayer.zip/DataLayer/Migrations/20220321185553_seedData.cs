﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class seedData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetRoles_Screens_ScreenId",
                table: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "Screens");

            migrationBuilder.DropIndex(
                name: "IX_AspNetRoles_ScreenId",
                table: "AspNetRoles");

            migrationBuilder.InsertData(
                table: "PeriodIndicators",
                columns: new[] { "Id", "NameAr", "NameEn" },
                values: new object[] { 1, "ايام", "Day/s" });

            migrationBuilder.InsertData(
                table: "PeriodIndicators",
                columns: new[] { "Id", "NameAr", "NameEn" },
                values: new object[] { 2, "اسابيع", "Week/s" });

            migrationBuilder.InsertData(
                table: "PeriodIndicators",
                columns: new[] { "Id", "NameAr", "NameEn" },
                values: new object[] { 3, "شهور", "Month/s" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "PeriodIndicators",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "PeriodIndicators",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "PeriodIndicators",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.CreateTable(
                name: "Screens",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Icon = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Url = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Screens", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoles_ScreenId",
                table: "AspNetRoles",
                column: "ScreenId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetRoles_Screens_ScreenId",
                table: "AspNetRoles",
                column: "ScreenId",
                principalTable: "Screens",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
