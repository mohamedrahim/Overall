﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class updateSubscriptions : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "e3bc64ed-043b-4821-88a7-3a0bcee31a78");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "90331a28-865f-4e49-abaf-9dcc01e4970f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "7c1bf9af-104c-4cbe-aa17-77fc048512d7");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "1a39bc82-193e-486f-9912-0df498b2b56f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "f2dc7299-b70c-4bd4-bb2e-213be2cfd2ed");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "a4441245-2bbd-4167-b174-85220954c8f1");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "d4504317-002e-46ac-be86-f55c3c614b77");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "b59aefc9-24f3-4ba3-82f6-9a775bce41a6");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "4488ffd2-04fd-417f-90d9-20d72fb0b9f9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "623b0c00-e07c-4355-9853-354a11ebdbde");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "aa2d2b13-37c7-4469-b91b-59d5f58a3304");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "c49643d6-655a-49d0-819b-6fbe2027e015");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "5e17399f-9260-42cd-bedf-bf51dbe95836");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "43ca80bf-5382-4d64-a266-a9f02a5f5094");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "b3b9e153-fc98-4302-a660-c0b3afa64f12");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "1a4cec5d-0c8a-4197-83ee-812b4e6fdebe");

            migrationBuilder.CreateIndex(
                name: "IX_Subscription_PeriodIndicatorId",
                table: "Subscription",
                column: "PeriodIndicatorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Subscription_PeriodIndicators_PeriodIndicatorId",
                table: "Subscription",
                column: "PeriodIndicatorId",
                principalTable: "PeriodIndicators",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Subscription_PeriodIndicators_PeriodIndicatorId",
                table: "Subscription");

            migrationBuilder.DropIndex(
                name: "IX_Subscription_PeriodIndicatorId",
                table: "Subscription");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "71450ccc-7172-4c39-8895-35639b26663d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "a87eea53-1d63-46fa-a40d-06a4a537ad38");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "6cc8d1ed-d09b-48f3-8159-b91ab448d78b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "a09a7e52-8a67-4a64-8762-0c8fc72533f0");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "49c910ae-0951-4c8a-96ca-3811b53ef386");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "c4c7c5cd-8651-41c4-ad9a-e8688b5eb442");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "df673037-0cfc-4d10-85e3-20ea9cbf29db");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "ebdd0f8e-90e0-464a-98e1-385e5ef61897");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "c332316f-c5f8-4560-824d-02e9c83b3770");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "b68b0c1b-d8fe-464a-936e-a6afab61086b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "88c1bd9f-1a0b-46c3-9f11-f7bbe930d6ed");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "ecd40f0f-d316-4112-94a9-08c77cc36ba3");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "3c92e5a3-eefd-43e3-b026-d0cb787ce32f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "9769fc28-e076-42a4-bb13-e7b3ad9317db");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "ab432333-9e3e-4d7f-9554-aa939885ff94");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "27e3a6cf-d183-4f5e-a0ba-46db55ed742a");
        }
    }
}
