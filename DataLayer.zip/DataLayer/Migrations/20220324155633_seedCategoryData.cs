﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class seedCategoryData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "10b6ac9b-5f51-41ac-b332-a1813e1ee336");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "b61060bb-dd67-4d73-b45c-2d797ec2af41");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "62743a95-a23f-4f01-8259-f121ad9502ec");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "3c3f206e-e455-41fa-8549-92510f2cf28a");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "63cc208b-3966-473a-bcda-c1a34b0ff298");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "0bfc8794-0e35-4561-b725-73c5f76af442");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "e6db8370-b45c-47ee-938f-a3d5c05e6fed");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "2b1733d1-d403-45b8-9354-a791aeec7898");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "b16402ff-239f-4bde-bc70-282e5d2a3484");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "3be32540-297a-4d3e-9608-eeb55698dbcd");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "c27ddf7e-33f7-41cb-a967-9414bac3e1f9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "70617801-199c-4892-8ba1-f7770b2631be");

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsActive",
                value: true);

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 4,
                column: "IsActive",
                value: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "f6bd2106-10d6-452e-b9b6-ea7d3b775db4");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "653eb75d-7dec-47b8-9026-af451f6a2030");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "557ef5ab-1120-4dd5-9b21-5453ac465cc4");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "bcf6041b-d995-4ca7-86d1-673c6cd401a9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "3cd58576-7de4-4c2f-b149-314bee0438c9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "9791bdae-aeb6-4c15-b07c-698b8851bccd");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "65e43deb-1201-4e5e-9cfa-8103ad442dc9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "85c8db13-8f3c-4451-9bfd-c752591ad970");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "679a7320-7b7b-483e-9285-5e75376fcf66");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "1e75539e-b0b5-4d33-98f1-28853a4350fa");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "94b56cdb-98e4-46f6-bd98-bc11f7f4430e");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "8b1a37db-3b42-457f-8dab-a2e7256b34a0");

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsActive",
                value: false);

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsActive",
                value: false);

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsActive",
                value: false);

            migrationBuilder.UpdateData(
                table: "ClientCategories",
                keyColumn: "Id",
                keyValue: 4,
                column: "IsActive",
                value: false);
        }
    }
}
