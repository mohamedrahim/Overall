﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class dbNewChanges : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "ClientId",
                table: "Sliders",
                type: "bigint",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AddressAr",
                table: "Clients",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AddressEn",
                table: "Clients",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Addresses",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ClientLocation",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClientId = table.Column<long>(type: "bigint", nullable: false),
                    AreaId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientLocation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClientLocation_Areas_AreaId",
                        column: x => x.AreaId,
                        principalTable: "Areas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClientLocation_Clients_ClientId",
                        column: x => x.ClientId,
                        principalTable: "Clients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Gender",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    NameEn = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    NameAr = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Gender", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ClientGender",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClientId = table.Column<long>(type: "bigint", nullable: false),
                    GenderId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientGender", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClientGender_Clients_ClientId",
                        column: x => x.ClientId,
                        principalTable: "Clients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClientGender_Gender_GenderId",
                        column: x => x.GenderId,
                        principalTable: "Gender",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "d0765ff1-7d12-4ac5-a6d1-45d2b77c0843");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "eeb74b37-b534-43dd-973d-3ee1975bbdd5");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "8af3b853-bc03-4fe0-a727-81cb72aef30e");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "9d7cba7e-23a3-492a-8ec0-ab761fdff515");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "d2401e4a-b0ac-443a-a42a-9dcc21dc3a8a");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "b044f35a-18bd-44b4-9422-5c1c0c0ab1bb");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "9038eadb-139b-4957-ad8c-b5044d69786f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "b39a17c8-de4c-40a9-965e-e48ee97d3ae5");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "ded8a987-02a2-4cff-b24c-929d40a17e4d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "13e05160-44d7-431d-80d6-68cf45c8d0a1");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "e7a39ac3-6f31-4c75-9454-a079f2807cc8");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "83807906-d61b-456a-969c-c90623bbdd43");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "f23f9708-5eaa-47d7-8ecf-200e1b951ac6");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "dcd231db-0b2d-4cb3-9a2d-43b3ba396932");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "908afeb1-96dc-4bef-9450-4aaf343a1536");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "7f55ba2f-3a11-428d-8951-1591a36b8e50");

            migrationBuilder.InsertData(
                table: "Gender",
                columns: new[] { "Id", "NameAr", "NameEn" },
                values: new object[,]
                {
                    { 2, "سيدات", "Women" },
                    { 1, "رجال", "Men" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Sliders_ClientId",
                table: "Sliders",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientGender_ClientId",
                table: "ClientGender",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientGender_GenderId",
                table: "ClientGender",
                column: "GenderId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientLocation_AreaId",
                table: "ClientLocation",
                column: "AreaId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientLocation_ClientId",
                table: "ClientLocation",
                column: "ClientId");

            migrationBuilder.AddForeignKey(
                name: "FK_Sliders_Clients_ClientId",
                table: "Sliders",
                column: "ClientId",
                principalTable: "Clients",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Sliders_Clients_ClientId",
                table: "Sliders");

            migrationBuilder.DropTable(
                name: "ClientGender");

            migrationBuilder.DropTable(
                name: "ClientLocation");

            migrationBuilder.DropTable(
                name: "Gender");

            migrationBuilder.DropIndex(
                name: "IX_Sliders_ClientId",
                table: "Sliders");

            migrationBuilder.DropColumn(
                name: "ClientId",
                table: "Sliders");

            migrationBuilder.DropColumn(
                name: "AddressAr",
                table: "Clients");

            migrationBuilder.DropColumn(
                name: "AddressEn",
                table: "Clients");

            migrationBuilder.DropColumn(
                name: "Email",
                table: "Addresses");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "bd6ea47e-f900-4b67-84b0-281488222dad");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "3dee14ad-c1e1-4302-9262-8cb375606b63");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "53189180-bb20-453d-8ba6-fd0df772e93d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "a6a133b6-4548-4cbc-bd83-63ea2abf85af");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "1d801580-982d-4f3a-835e-878f4235b7f9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "d2d4c419-dce1-4243-bffe-495971825a0f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "2501ea07-4487-46c3-b5e7-d682f3c4e785");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "b2be330f-4ef9-4275-889d-2d27bde46eeb");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "28a0ada7-cb0d-4f8e-ba4d-9383134ce8cd");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "2aa479d3-f888-40c0-a312-98c5e67e769e");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "a178bef4-103d-41d7-943f-fba9b7533f43");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "8a574f2f-beec-4cf5-90a4-0d1fc9ea68ad");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "2d916fa8-58ea-422e-833e-64aeb0b8d016");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "f8e456ba-45d7-4359-bf4a-73987458a79c");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "00e20b85-74dc-46c6-b5ea-235ea7c1e4cc");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "30d76e6a-893f-455c-a04c-4f477ca8f34b");
        }
    }
}
