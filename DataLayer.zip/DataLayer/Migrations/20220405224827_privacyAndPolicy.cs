﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class privacyAndPolicy : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "OldPrice",
                table: "Subscription",
                type: "float",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PrivacyAndPolicyAr",
                table: "Info",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PrivacyAndPolicyEn",
                table: "Info",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "4c25e642-60f5-47eb-b60a-1602559e3f94");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "a839d1ab-72ed-4fff-a007-d4b14406b835");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "6136f46c-eb72-4a25-bab4-5526dbf5635a");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "cf160883-36c8-4e1d-85d1-f078edc9cce1");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "460579f0-8ce3-476d-a360-d871d88b9647");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "c883b3e0-9850-43e7-b9fc-a5abcb908ae9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "f31bc9c1-c072-4442-8bb9-a7f7d158d6ad");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "692ba70e-c323-4bbe-a960-b1f06fd5b2d0");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "6f917be8-fd15-4926-9ac0-8aba3c63f8a5");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "32016128-c402-4f7b-aaef-72644b9c548d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "99b1fa44-920b-47d9-b9c7-7b55affe2c63");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "5ac0f6e1-4318-467c-95bb-398c8f1fdedd");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "a9de7db5-12b2-4681-bacb-a529b2824d2a");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "97aa118f-3d44-473a-a54b-41ff0b7e80da");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "4b8ad8f3-5914-4bfa-a150-7ae6eda08c5c");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "9a538121-fa31-44ac-a9fc-f3afe19bb882");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OldPrice",
                table: "Subscription");

            migrationBuilder.DropColumn(
                name: "PrivacyAndPolicyAr",
                table: "Info");

            migrationBuilder.DropColumn(
                name: "PrivacyAndPolicyEn",
                table: "Info");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "05e2acfb-6517-4a03-bc4a-a54b85d9aac0",
                column: "ConcurrencyStamp",
                value: "e3bc64ed-043b-4821-88a7-3a0bcee31a78");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "191f1dba-e09b-418e-9ac7-30d10218a73a",
                column: "ConcurrencyStamp",
                value: "90331a28-865f-4e49-abaf-9dcc01e4970f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3468f2f1-4c15-495f-bcdb-d06b112784b6",
                column: "ConcurrencyStamp",
                value: "7c1bf9af-104c-4cbe-aa17-77fc048512d7");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "35969c0e-c2a4-4c27-9b05-be0d14cd5b1b",
                column: "ConcurrencyStamp",
                value: "1a39bc82-193e-486f-9912-0df498b2b56f");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "5996d5a1-ed94-47cd-b72b-343ff918b7da",
                column: "ConcurrencyStamp",
                value: "f2dc7299-b70c-4bd4-bb2e-213be2cfd2ed");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7a675ebe-3ed8-4d55-9046-a097addd484b",
                column: "ConcurrencyStamp",
                value: "a4441245-2bbd-4167-b174-85220954c8f1");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "7f5992be-4625-4595-b52e-e80db3c6755f",
                column: "ConcurrencyStamp",
                value: "d4504317-002e-46ac-be86-f55c3c614b77");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "9504c27c-6b15-4bd2-b8d7-eb22b115a13f",
                column: "ConcurrencyStamp",
                value: "b59aefc9-24f3-4ba3-82f6-9a775bce41a6");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a4a2b595-4643-4ff7-a41e-234e0818a9fa",
                column: "ConcurrencyStamp",
                value: "4488ffd2-04fd-417f-90d9-20d72fb0b9f9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "bc8eb7e4-2615-4135-9146-ebd3b6196c99",
                column: "ConcurrencyStamp",
                value: "623b0c00-e07c-4355-9853-354a11ebdbde");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef431-c5aa-4962-8147-97bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "aa2d2b13-37c7-4469-b91b-59d5f58a3304");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8045-91bbcb8d3791",
                column: "ConcurrencyStamp",
                value: "c49643d6-655a-49d0-819b-6fbe2027e015");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8047-91bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "5e17399f-9260-42cd-bedf-bf51dbe95836");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef631-c5aa-4962-8048-95bbcb8d2791",
                column: "ConcurrencyStamp",
                value: "43ca80bf-5382-4d64-a266-a9f02a5f5094");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "be1ef632-c5aa-4962-8047-91bbcb8d2781",
                column: "ConcurrencyStamp",
                value: "b3b9e153-fc98-4302-a660-c0b3afa64f12");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ec07fb7d-2dfb-4c9f-a2e7-307c8a7f26e9",
                column: "ConcurrencyStamp",
                value: "1a4cec5d-0c8a-4197-83ee-812b4e6fdebe");
        }
    }
}
