﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace DataLayer.Extensions
{
    public static class ClaimsPrincipalExtensions
    {
        public static string GetUserId(this ClaimsPrincipal principal)
        {
            if (principal == null)
                return null;

            var loggedInUserId = principal.FindFirstValue(ClaimTypes.NameIdentifier);

            return loggedInUserId;
        }

        public static string GetUserName(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            return principal.FindFirstValue(ClaimTypes.Name);
        }

        public static string GetUserEmail(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            return principal.FindFirstValue(ClaimTypes.Email);
        }

        public static int GetClientId(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            IEnumerable<Claim> claims = principal.Claims;
            var claim = principal.FindFirstValue("clientId");

            if (string.IsNullOrEmpty(claim))
                return 0;

            return int.Parse(claim);
        }
        
        public static bool IsGuest(this ClaimsPrincipal principal)
        {
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            IEnumerable<Claim> claims = principal.Claims;
            var claim = principal.FindFirstValue("isGuest");

            return bool.Parse(claim);
        }

        public static bool IsAdmin(this ClaimsPrincipal principal)
        {
            return principal.IsInRole("Admin");
        }

    }
}
